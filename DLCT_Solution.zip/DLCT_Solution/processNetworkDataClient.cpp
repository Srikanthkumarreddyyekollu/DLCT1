#include "stdafx.h"
#include "soapStub.h"
#include "soapH.h"
#include "resource.h"
#include "cJSON.h"
#include "Structures.h"
#include <sstream>
using namespace std;

extern char EncryptDecryptSignal[StandardBuffer];
char* processNetworkDataRequestJSON(processNetworkDataReqObjStrcture processNetworkDataReqObjStrcturePtr);
processNetworkDataResObjStrcture processNetworkDataResponseObject(char *responseCharPtr);
Logger ProcessNetworkDataClient_cpp =  Logger::getInstance("ProcessNetworkDataClient.cpp");
char * encryption(char *receivedString);
char * decryption(char *ptr);

bool processNetworkDataWS(char *clientIdBuff,char *fileName,int status){

	LOG4CPLUS_INFO(ProcessNetworkDataClient_cpp,"Starting Function processNetworkDataWS()");
	bool success=false;
	int failure=true;
	int soap_call___ns1__processNetworkDataStatus=false;
	ns1__processNetworkData ns1__processNetworkDataObj;
	ns1__processNetworkDataResponse ns1__processNetworkDataResponseObj;
	struct soap *soapObj = soap_new(); 
	char *processNetworkDataRequestJsonPtr;
	char msgBuffer[StandardBuffer];
	processNetworkDataReqObjStrcture processNetworkDataReqObjStrcturePtr;
	processNetworkDataReqObjStrcturePtr.clientID=clientIdBuff;
	processNetworkDataReqObjStrcturePtr.fileName=fileName;
	processNetworkDataReqObjStrcturePtr.status=status;
	
	try{
	LOG4CPLUS_INFO(ProcessNetworkDataClient_cpp, "processNetworkDataRequestJSON, Going to be called");
	//processNetworkDataRequestJSON()
	processNetworkDataRequestJsonPtr=processNetworkDataRequestJSON(processNetworkDataReqObjStrcturePtr);
	LOG4CPLUS_INFO(ProcessNetworkDataClient_cpp, "processNetworkDataRequestJSON, Over");
	if(strcmp(EncryptDecryptSignal,"on")==0)
	processNetworkDataRequestJsonPtr = encryption(processNetworkDataRequestJsonPtr);
	LOG4CPLUS_INFO(ProcessNetworkDataClient_cpp, "processNetworkDataRequestJSON Encryption, Over");
	}catch(...){failure=false;LOG4CPLUS_ERROR(ProcessNetworkDataClient_cpp,"processNetworkDataRequestJSON Results & Encryption- FAILURE");
	LOG4CPLUS_INFO(ProcessNetworkDataClient_cpp,"Function processNetworkDataWS() OVER");
	return success;}
	
	if(failure==true){
	std::string responseJSON;
	std::string requestString (processNetworkDataRequestJsonPtr);
	//std::string requestString (processNetworkDataRequestJsonPtr);

	ns1__processNetworkDataObj.request=&requestString;
	try{
	LOG4CPLUS_INFO(ProcessNetworkDataClient_cpp, "soap_call___ns1__processNetworkData, Going to START");
	if(soap_call___ns1__processNetworkData(soapObj, NULL, NULL,&ns1__processNetworkDataObj,&ns1__processNetworkDataResponseObj)== SOAP_OK ){
	LOG4CPLUS_INFO(ProcessNetworkDataClient_cpp, "soap_call___ns1__processNetworkData SUCCESS, Returned Some Value");
	soap_call___ns1__processNetworkDataStatus=true;	
	}else{
	LOG4CPLUS_WARN(ProcessNetworkDataClient_cpp, "soap_call___ns1__processNetworkData FAILS, Caught at else");
	soap_call___ns1__processNetworkDataStatus=false;
	memset(msgBuffer,false,sizeof(msgBuffer));
    soap_sprint_fault(soapObj, msgBuffer, StandardBuffer);
	msgBuffer[sizeof(msgBuffer) - 1] = '\0';
	LOG4CPLUS_ERROR(ProcessNetworkDataClient_cpp,msgBuffer);
	try{
	soap_end(soapObj);
	soap_free(soapObj); 
	if(processNetworkDataRequestJsonPtr!=NULL)
	free(processNetworkDataRequestJsonPtr);
	}catch(...){ LOG4CPLUS_ERROR(ProcessNetworkDataClient_cpp,"Deleting pointer Problem"); }
	// // // if(clientIdBuff!=NULL)
	// // // free(clientIdBuff);
	// // // if(fileName!=NULL)
	// // // free(fileName);
	LOG4CPLUS_INFO(ProcessNetworkDataClient_cpp,"Function processNetworkDataWS() OVER");
	return success;
	}//else
	}catch(...){ LOG4CPLUS_ERROR(ProcessNetworkDataClient_cpp,"processNetworkDataWsStatus FAILES,Caught exception");
	try{
	soap_call___ns1__processNetworkDataStatus=false;
	soap_end(soapObj);
	soap_free(soapObj); 
	if(processNetworkDataRequestJsonPtr!=NULL)
	free(processNetworkDataRequestJsonPtr);	
	}catch(...){ LOG4CPLUS_ERROR(ProcessNetworkDataClient_cpp,"Deleting Pointer soapObj- Problem"); }
	}//catch
		if(soap_call___ns1__processNetworkDataStatus==true){
		try{
		responseJSON=*ns1__processNetworkDataResponseObj.return_;
		}catch(...){LOG4CPLUS_ERROR(ProcessNetworkDataClient_cpp,"ns1__processNetworkDataResponseObj ,return WS value can't be initialized");	
		try{
		soap_end(soapObj);
		soap_free(soapObj); 
		if(processNetworkDataRequestJsonPtr!=NULL)
		free(processNetworkDataRequestJsonPtr);
		}catch(...){ LOG4CPLUS_ERROR(ProcessNetworkDataClient_cpp,"Deleting Pointer soapObj- Problem"); }	
		LOG4CPLUS_INFO(ProcessNetworkDataClient_cpp,"Function processNetworkDataWS() OVER");
		return success;
		}//catch
		char * responseCharPtr = new char[responseJSON.size() + true]; //kula true->1
		char compareBuffer[StandardBuffer];
		std::copy(responseJSON.begin(), responseJSON.end(), responseCharPtr);
		responseCharPtr[responseJSON.size()] = '\0';
		
		//processNetworkDataResponseObject()
		processNetworkDataResObjStrcture processNetworkDataResObjStrctureObj;
		try{
		LOG4CPLUS_INFO(ProcessNetworkDataClient_cpp, "processNetworkDataResponse Decryption has been Called");
		if(strcmp(EncryptDecryptSignal,"on")==0)
		responseCharPtr=decryption(responseCharPtr);
		////////responseCharPtr[responseJSON.size()] = '\0';//can be removed
		memset(msgBuffer,false,sizeof(msgBuffer));//can be removed
		strcpy(msgBuffer,"Received response is -");//can be removed
		strcat(msgBuffer,responseCharPtr);//can be removed
		// LOG4CPLUS_INFO(ProcessNetworkDataClient_cpp,msgBuffer);//can be removed
		// LOG4CPLUS_INFO(ProcessNetworkDataClient_cpp, "processNetworkDataResponse Decryption has been Over");
		// LOG4CPLUS_INFO(ProcessNetworkDataClient_cpp, "processNetworkDataResponseObject has been Called");
		processNetworkDataResObjStrctureObj=processNetworkDataResponseObject(responseCharPtr);
		// LOG4CPLUS_INFO(ProcessNetworkDataClient_cpp, "processNetworkDataResponseObject SUCCESS");
		memset(compareBuffer,'\0',sizeof(compareBuffer));
		sprintf(compareBuffer,"%s",processNetworkDataResObjStrctureObj.status);
		}catch(...){
		try{
		if(responseCharPtr!=NULL)
		delete [] responseCharPtr;
		if(processNetworkDataRequestJsonPtr!=NULL)
		free(processNetworkDataRequestJsonPtr);
		soap_end(soapObj);
		soap_free(soapObj); 
		}catch(...){LOG4CPLUS_ERROR(ProcessNetworkDataClient_cpp,"Deleting Pointers Problem"); }
		LOG4CPLUS_ERROR(ProcessNetworkDataClient_cpp,"processNetworkDataResObjStrctureObj FAILES in creating a Object of RECEIVED value from SERVER");
		LOG4CPLUS_INFO(ProcessNetworkDataClient_cpp,"Function processNetworkDataWS() OVER");
		return success;
		}
		try{
		if(responseCharPtr!=NULL)
		delete [] responseCharPtr;
		}catch(...){ LOG4CPLUS_ERROR(ProcessNetworkDataClient_cpp,"Deleting Pointers responseCharPtr- Problem"); }
		if(strcmp(compareBuffer,"SUCCESS")==false)
			success=true;
	}//if
	}//if
	try{
	if(processNetworkDataRequestJsonPtr!=NULL)
	free(processNetworkDataRequestJsonPtr);
	if(soapObj!=NULL)
	free(soapObj);
	}catch(...){ LOG4CPLUS_ERROR(ProcessNetworkDataClient_cpp,"Deleting Pointers processNetworkDataRequestJsonPtr- Problem");  }
	// // // if(clientIdBuff!=NULL)
	// // // free(clientIdBuff);
	// // // if(fileName!=NULL)
	// // // free(fileName);
	LOG4CPLUS_INFO(ProcessNetworkDataClient_cpp,"Function processNetworkDataWS() OVER");
	return success;
}