#include "stdafx.h"
#include "Structures.h"
using namespace std;
extern char FtpDirectory[StandardBuffer];
extern char FtpExecutable[StandardBuffer];
extern char LogsDirectory[StandardBuffer];
extern int	UnSuccessfulReturnValue;
extern DWORD waitInterval;
extern HANDLE hIOMutex;
static 	int iterateTime;
static short iterateCount1 = 0; //24 hours dlct suspend time interval count variable
int ClientId;
int returnValueFTP;	
int status;
int contentRetrievalInterval;
bool processNetworkDataSucess;
char scriptBuff[StandardBuffer];
char dupLogNameBuff[StandardBuffer];  //kula added
char originalLogBuff[StandardBuffer];  //kula add
char logsFilePathBuff[StandardBuffer];
char buffer_Temp[StandardBuffer];
char puttyAvilabilityCheck[StandardBuffer];
char clientIdBuff[StandardBuffer];
char finalFtpCommandBuff[StandardBuffer];
char ftpCommandBuff[StandardBuffer];
char puttyAuthenticationBuff[StandardBuffer];
char archiveDirBuff[StandardBuffer];
char setupCommandBuff[StandardBuffer];
char search_data_cFileName[StandardBuffer];
char oldLogFile[StandardBuffer]; //kula addedd: used for compirison with new log file till a new ping happend by user
char clientIdLogBuff[StandardBuffer];
char lcdArchivBuff[StandardBuffer];
char originalLogFiles[StandardBuffer];


//void *threadFailureHandler;
WIN32_FIND_DATA search_data;//dirctory
bool processNetworkDataWS(char *clientIdBuff,char *fileName,int status);
void ProcessFtpNetworkDataIteratively();
void ftpProcess();
void logFileCompression(char* dupLogNameBuff);

Logger FtpFunctions_cpp =  Logger::getInstance("FtpFunctions.cpp");
byte key[50];
byte  iv[50];
SYSTEMTIME st, lt;


std::string exec_cmd(char* cmd) //-----------------------------------------------------------------------------------
{

	//std::cout << "\nkula begine cmd in exec() cmd= : " << cmd<<"\n\n";

	FILE* pipe = _popen(cmd, "r");
	if (!pipe)
	return "ERROR";

	char buffer[128];
    std::string result = "";
	
	while(!feof(pipe))
			{
    		if(fgets(buffer, 128, pipe) != NULL)
    		result += buffer;
			}
	//std::cout << "\nkula end  in exec() result= : " << result << "\n\n";
    _pclose(pipe);
	return result;
}//-------------------------------------------------------------------------------------------------------------------

//ftpNetworkDataIteratively()
void ftpNetworkDataIteratively(void *param)//call-2---------------------------------------------------------------------
{
	LOG4CPLUS_INFO(FtpFunctions_cpp, "Starting Function ftpNetworkDataIteratively()");
	char logDirectoryPathBuff[StandardBuffer];
	//char tempBuff[StandardBuffer];
	//////char scriptFilePSFTPBuff[StandardBuffer];
	char pathFtpServerBuff[StandardBuffer];
	int checkReturn;
	// // // // sprintf(clientIdBuff,"%ld",ClientId);

	//To move files to archive directory
	memset(archiveDirBuff, false, sizeof(archiveDirBuff));
	strcpy(archiveDirBuff,LogsDirectory);
	strcat(archiveDirBuff,"\\Archive");	

	//registerResponseObjStucture *registerResponseObjStucturePtr= (registerResponseObjStucture *)malloc(sizeof(registerResponseObjStucture));

	registerResponseObjStucture *registerResponseObjStucturePtr = (registerResponseObjStucture*) param;

	sprintf(clientIdBuff, "%ld", registerResponseObjStucturePtr->clientID);
	ClientId = registerResponseObjStucturePtr->clientID;
	memset(pathFtpServerBuff,false,sizeof(pathFtpServerBuff));
	sprintf(pathFtpServerBuff, "cd %s", registerResponseObjStucturePtr->ftpPath);

	
	//sprintf(ftpCommandBuff, "echo y | %s\\%s -pw %s %s@%s",FtpDirectory,FtpExecutable,ftpArgumentStrcturePtr->passwordFtpServer,ftpArgumentStrcturePtr->usernameFtpServer,ftpArgumentStrcturePtr->addressFtpServer);
	memset(ftpCommandBuff, false, sizeof(ftpCommandBuff));
	sprintf(ftpCommandBuff, "echo y | %s\\%s -pw %s %s@%s", FtpDirectory, FtpExecutable, registerResponseObjStucturePtr->ftpPassword, registerResponseObjStucturePtr->ftpUsername, registerResponseObjStucturePtr->ftpUrl);

	//cout << "\nftpCommandBuff= : " << ftpCommandBuff << "\n\n";
	
	memset(puttyAvilabilityCheck, false, sizeof(puttyAvilabilityCheck));
	strcpy(puttyAvilabilityCheck,ftpCommandBuff);
	
	memset(logDirectoryPathBuff,false,sizeof(logDirectoryPathBuff));
	sprintf(logDirectoryPathBuff,"lcd %s",LogsDirectory);


	//lcdArchivBuff

	memset(lcdArchivBuff, false, sizeof(lcdArchivBuff));
	sprintf(lcdArchivBuff, "%s\\%s", logDirectoryPathBuff, "Archive");


	memset(logDirectoryPathBuff, false, sizeof(logDirectoryPathBuff));
	sprintf(logDirectoryPathBuff, "lcd %s", LogsDirectory);
	
	memset(puttyAuthenticationBuff, false, sizeof(puttyAuthenticationBuff));
	sprintf(puttyAuthenticationBuff, "| %s\\%s -pw %s %s@%s", FtpDirectory, FtpExecutable, registerResponseObjStucturePtr->ftpPassword, registerResponseObjStucturePtr->ftpUsername, registerResponseObjStucturePtr->ftpUrl);
	
	
	memset(ftpCommandBuff,false,sizeof(ftpCommandBuff));
	sprintf(ftpCommandBuff, "(echo %s & echo %s & echo ", lcdArchivBuff, pathFtpServerBuff);
	
	iterateTime = registerResponseObjStucturePtr->ftpInterval;
	
	memset(setupCommandBuff,false,sizeof(setupCommandBuff));
	sprintf(setupCommandBuff,"mkdir %s" ,archiveDirBuff);

	contentRetrievalInterval = registerResponseObjStucturePtr->contentRetrievalInterval;
	for(int loop = 0; loop < 24 ; loop++)
		key[loop] = registerResponseObjStucturePtr->signKey[loop];
	for(int loop = 0; loop < 8 ; loop++)
		iv[loop] = registerResponseObjStucturePtr->cryptKey[loop];
    //for(int loop = 0; loop < 24 ; loop++)
	//printf("values issss:%02X\n",key[loop]);	
		
	try{
	checkReturn=system(setupCommandBuff);   //Exceptions handling and message printing can be done
	/*setupCommandBuff: mkdir C:\Windows\security\logs\Archive*/
	}catch(...){
	LOG4CPLUS_ERROR(FtpFunctions_cpp, "Unable to create Archive Directory");
	}
	
	try{
	LOG4CPLUS_INFO(FtpFunctions_cpp, "ftpProcess(), Going to be Called");
	ftpProcess();
	LOG4CPLUS_INFO(FtpFunctions_cpp, "ftpProcess(), OVER");

	//add some wait here

	}catch(...){
	LOG4CPLUS_ERROR(FtpFunctions_cpp, "ProcessFtpNetworkDataIteratively(),Fails @ FtpFunctions.cpp by ftpProcess");
	}
	LOG4CPLUS_INFO(FtpFunctions_cpp, "End Function ftpNetworkDataIteratively()");

}//ftpNetworkDataIteratively()-----------------------------------------------------------------------------------------

			
void ftpProcess() //call-3---------------------------------------------------------------------------------------------------- 
{
	try {
		LOG4CPLUS_INFO(FtpFunctions_cpp, "ProcessFtpNetworkDataIteratively(), Going to be Called");
		// call method
		ProcessFtpNetworkDataIteratively();
		LOG4CPLUS_INFO(FtpFunctions_cpp, "ProcessFtpNetworkDataIteratively(), OVER");
		}catch(...) {
		// call ftpProcess
		LOG4CPLUS_ERROR(FtpFunctions_cpp, "ftpProcess(),FAILS @ FtpFunctions.cpp with ProcessFtpNetworkDataIteratively()");
		//ftpProcess();
	}
}//ftpProcess()

	
void ftpThreadInitializer(void *param) //call-1--------------------------------------------------------------------------
{
	//threadFailureHandler=param;
	//LOG4CPLUS_INFO(FtpFunctions_cpp, "REACHED");

	LOG4CPLUS_INFO(FtpFunctions_cpp, "Waiting for ftpLogInitial() Thread to be Complete");
	if(hIOMutex!=NULL){
	WaitForSingleObject( hIOMutex, INFINITE );//Thread started @ DLCT.cpp for ftpLogInitial();, We are waiting here until That ftpLogIntial 
	ReleaseMutex( hIOMutex);
	}

	 registerResponseObjStucture *registerResponseObjStucturePtr= (registerResponseObjStucture *)malloc(sizeof(registerResponseObjStucture));

	registerResponseObjStucturePtr = (registerResponseObjStucture*)param;
	///printf("USER NAME IS:%s\n",registerResponseObjStucturePtr->ftpUsername);
	//for(int loop = 0; loop < 24 ; loop++)
		//key[loop] = registerResponseObjStucturePtr->signKey[loop];
	///	printf("values is:%02X\n",registerResponseObjStucturePtr->signKey[loop]);
	
	LOG4CPLUS_INFO(FtpFunctions_cpp, "Going to call thread _beginthread for ftpNetworkDataIteratively()");
		try{
	ftpNetworkDataIteratively(registerResponseObjStucturePtr);
	}catch(...){
	LOG4CPLUS_ERROR(FtpFunctions_cpp, "Catch Block, ftpThreadInitializer(),Going to be Restart @ FtpFunctions.cpp by ftpThreadInitializer");
	ftpThreadInitializer(param);
	}//catch
}//ftpThreadInitializer()--------------------------------------------------------------------------------------------


void ProcessFtpNetworkDataIteratively()//call-4---------------------------------------------------------------------
{
	HANDLE handle;
	char msgBuffer[StandardBuffer];
	std::string puttyAvilabilityResult;
	int catchExecution=false;
	LOG4CPLUS_INFO(FtpFunctions_cpp, "Starting Function ProcessFtpNetworkDataIteratively()");

	while(true){ //first Infinite loop 
		LOG4CPLUS_INFO(FtpFunctions_cpp, "Looping for FTP'ing Log Files after given INTERVAL");
		
		try{
			
		puttyAvilabilityResult = exec_cmd(puttyAvilabilityCheck);

		}catch(...){ puttyAvilabilityResult.clear(); LOG4CPLUS_WARN(FtpFunctions_cpp, "puttyAvilabilityCheck, fails"); }//returnValueFTP=UnSuccessfulReturnValue;
		
		
		//if (returnValueFTP!=false){
		if (puttyAvilabilityResult.compare("\0")==0)
		{
		LOG4CPLUS_ERROR(FtpFunctions_cpp, "Unable to find Putty Availability, No file will be process");
		}else{
		LOG4CPLUS_INFO(FtpFunctions_cpp, "Putty is available to FTP'ing files");
		memset(&search_data, false, sizeof(WIN32_FIND_DATA));//dirctory

		memset(logsFilePathBuff,false,sizeof(logsFilePathBuff));
		sprintf(logsFilePathBuff,"%s\\DLCT*.log",LogsDirectory);//if log file name changes, We need to change DLCT here
		//HANDLE handle = FindFirstFile("C:\\Windows\\security\\logs\\*.log", &search_data);

		try{
		LOG4CPLUS_INFO(FtpFunctions_cpp, "Going to check last modified file, All available files are sent to server.");
		handle = FindFirstFile(logsFilePathBuff, &search_data);
		}catch(...){LOG4CPLUS_WARN(FtpFunctions_cpp, "FindFirstFile, fails");}

		while(handle != INVALID_HANDLE_VALUE)	//inner while
		{	
			catchExecution=false;


			//LOG4CPLUS_INFO(FtpFunctions_cpp, "While loop for FTP'ing all AVAILABLE Log Files one by one");
			/*kula(30/3/17): Add somthing here for compact file */
							
			Sleep(1000);
/*kula add for log file compress changes-------------------------------------------------*/

			GetLocalTime(&lt);

			if (((lt.wHour == 12) || (lt.wMinute == 0)) && (strcmp(oldLogFile, search_data.cFileName) != 0))
			{
/*oldLogFile: once compar failed assigned to cFilename, then next time it appear will ignore*/
			memset(oldLogFile, false, sizeof(oldLogFile));
			strcpy(oldLogFile, search_data.cFileName);

			memset(dupLogNameBuff, false, sizeof(dupLogNameBuff));
			strcat(dupLogNameBuff, search_data.cFileName);
			memset(search_data_cFileName, false, sizeof(search_data_cFileName));
			strcpy(search_data_cFileName, dupLogNameBuff);

			memset(scriptBuff, false, sizeof(scriptBuff));			
			strcpy(scriptBuff, "COPY ");  
			strcat(scriptBuff, LogsDirectory);  
			strcat(scriptBuff, "\\");
			strcat(scriptBuff, search_data.cFileName); 
			strcat(scriptBuff, " ");
			strcat(scriptBuff, archiveDirBuff);
			strcat(scriptBuff, "\\");
			strcat(scriptBuff, dupLogNameBuff);    //execute command: copy c:\log\dlct.log  c:\log\Archive\dlct.log
			
			LOG4CPLUS_INFO(FtpFunctions_cpp, "Created duplicate copy of DLCTlog file.");
			system(scriptBuff);  // copy command executed


			/*originalLogBuff: del /F C:\Windows\security\logs\DLCT2017071118.log*/

				Sleep(2000);
				
				memset(clientIdLogBuff, false, sizeof(scriptBuff));
				strcpy(clientIdLogBuff, clientIdBuff);  // s
				strcat(clientIdLogBuff, "-");
				strcat(clientIdLogBuff, dupLogNameBuff); //clientIdLogBuff= 123-dlct.log

				memset(scriptBuff, false, sizeof(scriptBuff));
				strcpy(scriptBuff, "put ");
				strcat(scriptBuff, clientIdLogBuff);
				strcat(scriptBuff, " ");
				strcat(scriptBuff, clientIdLogBuff); //scriptBuff= put 123-dlct.log 123-dlct.log

			try{
					memset(setupCommandBuff, false, sizeof(setupCommandBuff));
					sprintf(setupCommandBuff, "%s\\%s", archiveDirBuff, dupLogNameBuff);

					LOG4CPLUS_INFO(FtpFunctions_cpp, "Log file compression going to start.");

					logFileCompression(setupCommandBuff);  //call to LogFileCompression() 

					LOG4CPLUS_INFO(FtpFunctions_cpp, "Log file compression done success.");
				}
				catch (...){ LOG4CPLUS_WARN(FtpFunctions_cpp, "Log file compression failed..!"); }

				try{
					memset(originalLogFiles, false, sizeof(originalLogFiles));
					sprintf(originalLogFiles, "del /F %s\\%s", archiveDirBuff, "DLCT*");
					system(originalLogFiles);
				}

				catch (...){
							LOG4CPLUS_ERROR(FtpFunctions_cpp, "All Original log files deleted form Archive dir after file compression success.");
						  }
				//now attempt to transfer logfile to server
				try{
					memset(finalFtpCommandBuff, false, sizeof(finalFtpCommandBuff));
					sprintf(finalFtpCommandBuff, "%s%s) %s", ftpCommandBuff, scriptBuff, puttyAuthenticationBuff);

					//(echo lcd C:\Windows\security\logs & echo cd Putty/Logs & echo put DLCT2014082015.log 700-DLCT2014082015.log) | C:\Progra~1\DLCT\putty\psftp -pw c9rCu20P gdpftp@151.117.209.168

					//printf("Final is:%d && %s\n",returnValueFTP,finalFtpCommandBuff);
				
					//Sending log file to server 
					system(finalFtpCommandBuff);
					LOG4CPLUS_INFO(FtpFunctions_cpp, "Attempted to ftping all DLCT* log file ...! ", returnStatus);
/*(finalFtpCommandBuff: "echo lcd C:\Windows\security\logs & echo cd Putty/Logs & echo put 44376-DLCT2017071118.log 44376-DLCT2017071118.log) | C:\Progra~1\DLCT\putty\psftp -pw c9rCu20P gdpftp@151.117.209.168"*/
				
				/*add copy of dlct log deletion */
//date: 12 jul, 2017



				}
				catch (...){ LOG4CPLUS_ERROR(FtpFunctions_cpp, "Unable to ftp files, Something wrong with the path"); catchExecution = true; }
				if (catchExecution == true) { break; }
				status = true;
				processNetworkDataSucess = false;

				try{
					//processNetworkDataWS()
					LOG4CPLUS_INFO(FtpFunctions_cpp, "processNetworkDataWS, Going to be called");
					processNetworkDataSucess = processNetworkDataWS(clientIdBuff, search_data.cFileName, status);
					LOG4CPLUS_INFO(FtpFunctions_cpp, "processNetworkDataWS, OVER");
				}
				catch (...){ LOG4CPLUS_ERROR(FtpFunctions_cpp, "processNetworkDataWS FAILS, Problem arrive in Webservice call"); catchExecution = true; }
				if (catchExecution == true) { break; }

				if (processNetworkDataSucess == false){
					//printf("******** processNetworkDataWS FAILS *********\n");
					LOG4CPLUS_WARN(FtpFunctions_cpp, "ProcessNetworkData Result - FAILURE");
				}

//----------------------------i am here, changes required-------------
				if (processNetworkDataSucess == true) //change to ==
				{
					/*
					try{
						memset(msgBuffer, false, sizeof(msgBuffer));
						strcpy(msgBuffer, "Moving file for deletion is -");
						strcat(msgBuffer, clientIdLogBuff);
						LOG4CPLUS_INFO(FtpFunctions_cpp, msgBuffer);
											
						memset(setupCommandBuff, false, sizeof(setupCommandBuff));
						//sprintf(setupCommandBuff,"MOVE /Y %s\\%s %s" ,LogsDirectory,search_data.cFileName,archiveDirBuff); //kula MOVE to COPY

						//kula changed 
						sprintf(setupCommandBuff, "MOVE /Y %s\\%s %s", LogsDirectory, dupLogNameBuff, archiveDirBuff);

						system(setupCommandBuff);
						//Sleep(1000*60);
						
					  }
					catch (...){ LOG4CPLUS_ERROR(FtpFunctions_cpp, "Unable to Move files to archive");
					catchExecution = true; }
					if (catchExecution == true) { break; }
					*/
					try{
						memset(setupCommandBuff, false, sizeof(setupCommandBuff));
						sprintf(setupCommandBuff, "del /F %s\\%s", archiveDirBuff, clientIdLogBuff);
						system(setupCommandBuff);
					}

					catch (...){
						memset(buffer_Temp, false, sizeof(buffer_Temp)); strcpy(buffer_Temp, "Unable To Delete File- ");
						strcat(buffer_Temp, search_data.cFileName);
						LOG4CPLUS_ERROR(FtpFunctions_cpp, buffer_Temp); catchExecution = true;
					}
					if (catchExecution == true) { break; }
				}

			if (FindNextFile(handle, &search_data) == FALSE){
					FindClose(handle);
					break;
				}
				//////}//else
			}//----------------end if --------------
		}//inner while
		}//else, if putty is available
		//intervalForLog will be '-1' as passing parameter, At restart it will be '-1' to send the older logs of previous user  
		
		
		if(iterateTime==UnSuccessfulReturnValue)
		{
			if (puttyAvilabilityResult.compare("\0")==0){
			LOG4CPLUS_ERROR(FtpFunctions_cpp, "FTP'ing Log Files - Initial, Fails");
			}else{
			LOG4CPLUS_INFO(FtpFunctions_cpp, "FTP'ing Log Files - Initial, DONE");
			break;	
			}
		}else{
			//printf("Sleeping for:%d\n",iterateTime);
			LOG4CPLUS_INFO(FtpFunctions_cpp, "FTP'ing Log Files - Periodic");
			try{
			Sleep(iterateTime);
			 }catch(...){memset(buffer_Temp,false,sizeof(buffer_Temp)); strcpy(buffer_Temp,"IterateTime Fails in system call");
			 			LOG4CPLUS_ERROR(FtpFunctions_cpp, buffer_Temp);
						iterateTime=1000000;}

		}
		LOG4CPLUS_INFO(FtpFunctions_cpp, "24 hours waiting time started....iterateCount ");
		Sleep(DLCTwaitInterval); //---Edit kula---Sleep for 24 hour for ProcessNetworkDataIteratively()-----------22/9/2015
			
	}//outer while

}//ProcessFtpNetworkDataIteratively()--------------------------------------------------------------------------------------
	