#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <cctype>
#include <string>
#include <windows.h>
#include <process.h>
#include <ctime>
#define Buff 100 
using namespace std;
string DummyHost;
HANDLE gDoneEvent;

string dest_host_find(string logRecord)
{
	string str11(logRecord);
	string str22("dest_host:");

	int len = str22.size();

	size_t found = str11.find(str22);
	//cout << "\n position at : " << found << endl;

	found = found + len;
	char dest_host[20];

	int i = 0;
	while (str11[found] != ',')
	{
		dest_host[i] = str11[found];
		i++; found++;
	}

	dest_host[i] = '\0';
	//cout << "\n\destination host-----" << dest_host;
	return dest_host;
}

void getLocalTime_call(string logRecord) //second
{
	string str2("action_rule:");
	size_t found = logRecord.find(str2);

	int len = str2.length();
	int action_rule = logRecord[len + found] - '0';
	SYSTEMTIME lt;

	char timeStamp[Buff];
	string  last_line_time = logRecord.substr(11, 19); // assign time stamp value..
	//---------------------------------by 11/7------------

	string dest_host = dest_host_find(logRecord);
	
	//cout << "\n\dest_host-----" << dest_host<< "----";

	//-----------------------------------------------end by 11/7--------
	int TempNumOne = last_line_time.size();

	for (int a = 0; a <= TempNumOne; a++)
	{
		timeStamp[a] = last_line_time[a];
	}
	GetLocalTime(&lt);

	char localTime[Buff]; //store local time value
	sprintf_s(localTime, "%04d.%02d.%02d %02d:%02d:%02d", lt.wYear, lt.wMonth, lt.wDay, lt.wHour, lt.wMinute, lt.wSecond);

	//cout << "\n\nlocalTime: " << localTime << endl;
	//cout << "\ntimeStamp: " << timeStamp << endl;
	
	
	if ((strcmp(localTime, timeStamp) == 0) && (action_rule == 1)) //action_rule=1 means deny rule applied 

		//localtime: your system time, timeStamp: the time when log created by dlct due to deny rule
	{

		if (DummyHost.compare(dest_host) != 0)
		{
			MessageBoxA(HWND_DESKTOP, "Your attempted Access has been restricted by DLCT admin.\n\nPlease contact�DLCT_DEV@CenturyLink.com�if you have any queries.", "DLCT Notification", MB_ICONWARNING);

				DummyHost = dest_host;
		}

		/*char notifyCommand[] = "C:\\Progra~1\\DLCT\\notifu\\notifu.exe /d 10000 /i %SYSTEMROOT%\system32\shell32.dll,43 /m \"Warning: Access restricted by DLCT admin...!\"  /t warn";
			system(notifyCommand);
			//DummyHost = dest_host;
		*/

		else
		{
			//cout << "\n-----------sleep for 2 min.......";
			Sleep(2000);
			MessageBoxA(HWND_DESKTOP, "Your attempted Access has been restricted by DLCT admin.\n\nPlease contact�DLCT_DEV@CenturyLink.com�if you have any queries.", "DLCT Notification", MB_ICONWARNING);
		
		}
	}

}

void ShowNotification(char fileCopy[260]) //first 
{
	string line;
	string last_line;

	char fileTemp[Buff] = "C:\\Windows\\security\\logs\\";

	strcat_s(fileTemp, fileCopy);

	ifstream myfile(fileTemp);
	if (myfile.is_open())
	{
		while (getline(myfile, line)) {
			bool is_empty = true;
			for (int i = 0; i < line.size(); i++) {
				char ch = line[i];
				is_empty = is_empty && isspace(ch);
			}
			if (!is_empty) {
				last_line = line;
			}
		}
		myfile.close();
	}
	else {
		cout << "unable to open last line of log file.";
	}


	//cout << "\n\n File last line:" << last_line << endl;

	//system("pause");

	getLocalTime_call(last_line);
}


