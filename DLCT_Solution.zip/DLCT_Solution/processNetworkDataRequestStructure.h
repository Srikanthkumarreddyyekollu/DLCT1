			typedef struct {
			char *clientID;
			char *fileName;
			int status;
			}processNetworkDataReqObjStrcture;