			typedef struct {
			char *status;
			}processNetworkDataResObjStrcture;