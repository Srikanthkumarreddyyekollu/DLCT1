typedef struct {
	int checksum;
	int subActivityId;
	char status[1000];
}processExecutionResultObjStructure;
