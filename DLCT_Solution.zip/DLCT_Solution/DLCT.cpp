// DLCT.cpp : Defines the entry point for the console application.

#include "stdafx.h" 
#include "resource.h" 
#include "cJSON.h" 
#include "Structures.h" 
#include "LimitSingleInstance.h" 

#include <iomanip>
#include <locale>
#include <sstream>
using namespace std;

char DebugLogFile[StandardBuffer] = "C:\\Progra~1\\DLCT\\client\\logs\\all_msgs.log"; //Dev debug log file path
extern char ConfigDirectory[StandardBuffer];  
extern char LogPropertiesFile[StandardBuffer];
extern char registerFileBuff[StandardBuffer];
extern char ConfigDirectory[StandardBuffer];
void loadProperties();   
bool registerWS(CString request);   
systemPropertiesStructure getSystemProperties();   
char* getRegisterRequestJSON(registerRequestJsonStructure registerRequestJsonStructureObj);
void ftpLogInitial(void *dummy);
void retrieveContentWS(void *dummy);
void notificationThread(void *param);
void MonitorFileChange(void *dummy);
void checkRegistrationValidation();
char currentMachine_IP[20];
bool registerSucess=0;
CString registerRequestCstring;
#define DEFAULT_PROTO SOCK_STREAM
#pragma comment(lib, "ws2_32.lib")
HANDLE hIOMutex;

int _tmain(int argc, _TCHAR* argv[])//main function 
{
  ShowWindow( GetConsoleWindow(), SW_HIDE ); // make commenting for open screen

	CLimitSingleInstance lsi(TEXT("Global\\{6610c7a0-e6ea-4ff9-a3f7-62bdf2043481}")); //kula added
	if (lsi.IsAnotherInstanceRunning())
	{
		//MessageBoxA(HWND_DESKTOP, "DLCT.exe already running in your system. \n\tPress OK to close!", "DLCT Process status", MB_ICONWARNING);
		exit(0);//
	}

	bool threadFinished=false;//We can Extern this to, FtpFuction.cpp, ftpNetworkDataIteratively();
	char logPropertiesFileBuffer[StandardBuffer];
	SetErrorMode(SEM_NOGPFAULTERRORBOX);

	loadProperties();   //call loadProperties() in propertiesloader.cpp from VCR.txt config file
	
	memset(logPropertiesFileBuffer,false,sizeof(logPropertiesFileBuffer));
	strcpy(logPropertiesFileBuffer,ConfigDirectory);
	strcat(logPropertiesFileBuffer,"\\");
	strcat(logPropertiesFileBuffer,LogPropertiesFile);

//------------------------9:32AM 2nov_2017-------------------kula:Added-----------------
	//Objective: clearing debugLogFile everytime dlct get restarted-------------------------
	char DebuglogFileDelete[StandardBuffer];
	memset(DebuglogFileDelete, false, sizeof(DebuglogFileDelete));

	strcpy(DebuglogFileDelete, "DEL /F ");
	strcat(DebuglogFileDelete, DebugLogFile);

	cout << DebuglogFileDelete;
	if(system(DebuglogFileDelete)==0)
	{
		fprintf(stdout, "DLCT_cpp, old Debug %s file deleted.", DebugLogFile);
	}	
//	system("del /f C:\Progra~1\DLCT\client\logs\all_msgs.log");
	
//------------------------9:32AM 2nov_2017-------------------end-----------------

	LogLog::getLogLog()->setInternalDebugging(true);
    Logger root = Logger::getRoot();
  	ConfigureAndWatchThread configureThread(logPropertiesFileBuffer, 5 * 1000);

	systemPropertiesStructure systemPropertiesStructureObj;
	registerRequestJsonStructure registerRequestJsonStructureObj;
	
	char	*registerRequestJson;


	//=======================================================================================================

	LOG4CPLUS_INFO(root,"ftpLogInitial() Initialization going to be called");
	//ftpLogInitial();
	 
	hIOMutex = (HANDLE) _beginthread(ftpLogInitial, 0, NULL); // thread 1


	systemPropertiesStructureObj=getSystemProperties();

	registerRequestJsonStructureObj.cuid=systemPropertiesStructureObj.cuid;
	registerRequestJsonStructureObj.ipAddress=systemPropertiesStructureObj.ipAddress;

	strcpy(currentMachine_IP, systemPropertiesStructureObj.ipAddress);
	registerRequestJsonStructureObj.machineName=systemPropertiesStructureObj.machineName;
	try{
	//getRegisterRequestJSON()
	registerRequestJson=getRegisterRequestJSON(registerRequestJsonStructureObj);     
	}
	catch (...){//-LOG4CPLUS_FATAL(root,"Unable To Create Register Request JSON, Stoping PROCESS EXE");
		exit(false);}

		registerRequestCstring = CString(registerRequestJson);

//*******kula added: 26oct 2017******************REGISTRATION**************************************************
		
		//checkRegistrationValidation(); uncomment this line and comment below code if you want to skip registration if Register file exit 


		//registerWS()
		LOG4CPLUS_INFO(root, "Client Registartion Method Calling");
		//registerRequestCstring = CString(registerRequestJson);
		registerSucess = registerWS(registerRequestCstring); //Client Register Method
		LOG4CPLUS_INFO(root, "Client Registartion Completed");
		LOG4CPLUS_INFO(root, "Retrive Content Method is Calling");
		_beginthread(retrieveContentWS, 0, NULL);
		LOG4CPLUS_INFO(root, "Retrive Content Method Completed");

		if (registerSucess == false){
			LOG4CPLUS_ERROR(root, "Register Result - FAILURE");
			// TO-DO: print error 
		}
		registerSucess = 1;
		//cout << registerSucess;

//***************************************************************************

		//LOG4CPLUS_INFO(root,"Initializing RetrieveContent Thread");
		// retrieveContentWS()
		//_beginthread(retrieveContentWS, 0, NULL); // // thread 2 --ok

		//=======================================================================================================
		
		if (registerSucess)
		{
			Sleep(1);
			_beginthread(MonitorFileChange, 0, NULL);  // // thread 3
		
		}
		//MonitorFileChange();
//========================kula: added===============================================================================
		//URL notification 
		LOG4CPLUS_INFO(root, "Initializing URL notification thread");
		_beginthread(notificationThread, 0, NULL); // // thread 4
//=======================================================================================================

		LOG4CPLUS_INFO(root,"DLCT Initialization Completed");

		while (!threadFinished)
		{
			int i;
			for (i = 0; i < 90000000; i++);  
			Sleep(threadWait);
			//cout << "MAIN Thread" << endl;
		}


	
	return false;
}







void checkRegistrationValidation()
{
	LogLog::getLogLog()->setInternalDebugging(true);
	Logger root = Logger::getRoot();
	char *lpStr;
	lpStr = registerFileBuff; //extern char registerFileBuff[StandardBuffer]; holding register path.

	// Return value from "file PathFileExists".
	int retval;

	// Search for the presence of a file with a true result.
	retval = PathFileExists(lpStr); //system function for check existing path

	//char current_IP[20]; //getfrom registerRequestCstring
	char IPFilePath[StandardBuffer];
	char registerFile_IP[20];


	memset(IPFilePath, '\0', strlen(IPFilePath));
	strcpy(IPFilePath, ConfigDirectory);
	strcat(IPFilePath, "\\");
	strcat(IPFilePath, "registerFile_IPbuff.txt");



	if (retval == 1) //if register file exist
	{
		FILE *fp = fopen(IPFilePath, "r");
		fscanf(fp, "%s", registerFile_IP);

		if (strcmp(registerFile_IP, currentMachine_IP) == 0) //file exist and same user login
		{
			//skip registration
			LOG4CPLUS_INFO(root, "Register file already exist..! Skipping re-registration.");
			_beginthread(retrieveContentWS, 0, NULL);
		}
		else//file exist but new user login
		{

			LOG4CPLUS_INFO(root, "Register file exist, calling registerWS() for new user registration.");
			registerSucess = registerWS(registerRequestCstring); //register()
			_beginthread(retrieveContentWS, 0, NULL);
			FILE *fp = fopen(IPFilePath, "w");
			fprintf(fp, "%s", currentMachine_IP);// writing to ip buffer
			fclose(fp);

		}
	}


	else// if no file register file exist 
	{
		FILE *fp = fopen(IPFilePath, "w");
		if (fp == NULL)
		{
			LOG4CPLUS_INFO(root, "error creating registerFile_IPbuff.txt file");
		}
		else
		{
			LOG4CPLUS_INFO(root, "registerFile_IPbuff.txt file created for storing current Host IP.");

			fprintf(fp, "%s", currentMachine_IP);// writing to ip buffer
			fclose(fp);
		}
		LOG4CPLUS_INFO(root, "Register file not exist, calling registerWS() for new registration.");
		registerSucess = registerWS(registerRequestCstring); //register()
		_beginthread(retrieveContentWS, 0, NULL);

	}

	if (registerSucess == false)
	{
		LOG4CPLUS_ERROR(root, "Register Result - FAILURE");
		// TO-DO: print error 
	}
	registerSucess = 1;
	//cout << registerSucess;
}
