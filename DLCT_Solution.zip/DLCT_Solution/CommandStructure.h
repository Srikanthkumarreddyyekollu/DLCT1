#include "stdafx.h"

struct commandStruct{
		char *deviceCommand[200];
		char *firewallCommand[200];
		int	 requestId;
	};
typedef struct commandStruct commandStructure;