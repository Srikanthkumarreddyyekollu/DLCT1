#include "stdafx.h"
static int iterateCount = 0;  //used for only two cycle then dlct will pause for 24 hours.
void suspendDLCT();

void supendDLCT()
{
	if (iterateCount < 3)
		iterateCount++;
	else
		Sleep(DLCTwaitInterval); //---kula---Sleep for 24 hour for ProcessNetworkDataIteratively()-----------15/9/2015
}