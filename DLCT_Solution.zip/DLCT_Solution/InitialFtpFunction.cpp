#include "stdafx.h"
#include "Structures.h"

extern int	UnSuccessfulReturnValue;
extern HANDLE hIOMutex;


void ftpNetworkDataIteratively(void *param);
registerResponseObjStucture extractRegistrationDetails();
Logger InitialFtpFunction_cpp =  Logger::getInstance("InitialFtpFunction.cpp");
int interval=UnSuccessfulReturnValue;
using namespace std;

		void ftpLogInitial(void *dummy){ //thread-1 defination
		LOG4CPLUS_INFO(InitialFtpFunction_cpp,"Starting Function ftpLogInitial()");	
		registerResponseObjStucture registerResponseObjStuctureObject;
		registerResponseObjStucture *registerResponseObjStucturePtr;
		interval=UnSuccessfulReturnValue;
		try{
		//extractRegistrationDetails();
		registerResponseObjStuctureObject=extractRegistrationDetails();
		}catch(...){LOG4CPLUS_ERROR(InitialFtpFunction_cpp,"extractRegistrationDetails() FAILES"); interval=false;}	
		
		if(registerResponseObjStuctureObject.ftpInterval!=UnSuccessfulReturnValue){
		LOG4CPLUS_INFO(InitialFtpFunction_cpp,"Received Information from a file for older client to process older logs");	

		registerResponseObjStucturePtr = (registerResponseObjStucture *)malloc(sizeof(registerResponseObjStucture));
		registerResponseObjStucturePtr->ftpUsername = registerResponseObjStuctureObject.ftpUsername;
		registerResponseObjStucturePtr->ftpPassword = registerResponseObjStuctureObject.ftpPassword;
		registerResponseObjStucturePtr->ftpUrl = registerResponseObjStuctureObject.ftpUrl;
		registerResponseObjStucturePtr->ftpPath = registerResponseObjStuctureObject.ftpPath;
		registerResponseObjStucturePtr->ftpInterval = interval;
		registerResponseObjStucturePtr->clientID = registerResponseObjStuctureObject.clientID;
		registerResponseObjStucturePtr->contentRetrievalInterval = registerResponseObjStuctureObject.contentRetrievalInterval;
		for (int loop = 0; loop < 24; loop++)
			registerResponseObjStucturePtr->signKey[loop] = registerResponseObjStuctureObject.signKey[loop];
		for (int loop = 0; loop < 8; loop++)
			registerResponseObjStucturePtr->cryptKey[loop]=registerResponseObjStuctureObject.cryptKey[loop];

		try{
		//ftpNetworkDataIteratively
		ftpNetworkDataIteratively(registerResponseObjStucturePtr);

		// if(ftpArgumentStrcturePtr!=NULL)
		// delete [] ftpArgumentStrcturePtr;
		}catch(...){
		LOG4CPLUS_ERROR(InitialFtpFunction_cpp,"ftpNetworkDataIteratively() FAILES");
		}//catch
	}//if

	LOG4CPLUS_INFO(InitialFtpFunction_cpp,"Function ftpLogInitial() is OVER");
	hIOMutex=NULL;
	// CloseHandle(hIOMutex);
	}//ftpLogInitial()