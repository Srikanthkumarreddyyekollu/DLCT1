struct registerRequestJsonStruct{
char *ipAddress;
char *machineName;
char *cuid;
};
typedef struct registerRequestJsonStruct registerRequestJsonStructure;


struct registerRequestObjStructure{
char *ipAddress;
char *machineName;
char *cuid;
};
typedef struct registerRequestObjStructure registerRequestObjStructure;

