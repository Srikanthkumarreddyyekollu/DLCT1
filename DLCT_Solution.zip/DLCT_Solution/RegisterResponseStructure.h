struct registerResponseObjStruct{
	int clientID;
	char cryptKey[50];
	char signKey[50];
	char *ftpUsername;
	char *ftpPassword;
	char *ftpUrl;
	char *ftpPath;
	int ftpInterval;
	int contentRetrievalInterval;
};
typedef struct registerResponseObjStruct registerResponseObjStucture;

struct registerResponseJsonStruct{
	int clientId;
	char *cryptkey;
	char *signkey;
};
typedef struct registerResponseJsonStruct registerResponseJsonStucture;




struct rulesObjStruct{
	char *rule1;
	char *rule2;
	char *rule3;
};
typedef struct rulesObjStruct rulesObjStucture;