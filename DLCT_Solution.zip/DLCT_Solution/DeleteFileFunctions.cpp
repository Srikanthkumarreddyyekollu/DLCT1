#include "stdafx.h"
#include <stdio.h>
#include "commandLinkedList.h"
extern char ConfigDirectory[StandardBuffer];
extern commandHandler *head;

//deleteTempFile()
void deleteTempFile(char *fileNameBuffer){
	Logger DeleteFileFunctions_cpp =  Logger::getInstance("DeleteFileFunctions.cpp");
	char tempCommandBuffer[StandardBuffer];
	memset(tempCommandBuffer,'\0',sizeof(tempCommandBuffer));
	strcpy(tempCommandBuffer,"DEL /F ");
	strcat(tempCommandBuffer,ConfigDirectory);
	strcat(tempCommandBuffer,"\\temp");
	strcat(tempCommandBuffer,fileNameBuffer);
	//printf("DeleteFiles.cpp Command is:%s\n",tempCommandBuffer);
	LOG4CPLUS_INFO(DeleteFileFunctions_cpp,"Just for security reason if tempfiles still exist at fresh run, just delete it");
	try{
	system(tempCommandBuffer);
	} catch(...) { 
	if(fileNameBuffer!=NULL)
	free(fileNameBuffer);
	LOG4CPLUS_ERROR(DeleteFileFunctions_cpp, "Enable to Delete Temp files, System call failed");
	}
	if(fileNameBuffer!=NULL)
	free(fileNameBuffer);
	}
	
	/////////////////////////////////////////////////////////////////////////////////////
	//deleteFile()
void deleteFile(char *fileNameBuffer){
	char tempCommandBuffer[StandardBuffer];
	Logger DeleteFileFunctions_cpp =  Logger::getInstance("DeleteFileFunctions.cpp");
	memset(tempCommandBuffer,'\0',sizeof(tempCommandBuffer));
	strcpy(tempCommandBuffer,"DEL /F ");
	strcat(tempCommandBuffer,ConfigDirectory);
	strcat(tempCommandBuffer,"\\");
	strcat(tempCommandBuffer,fileNameBuffer);
	//printf("DeleteFiles.cpp Command is:%s\n",tempCommandBuffer);
	try{
	system(tempCommandBuffer);
	}catch(...){
	if(fileNameBuffer!=NULL)
	free(fileNameBuffer);
	LOG4CPLUS_ERROR(DeleteFileFunctions_cpp, "Enable to Delete files, System call failed");
	}
	if(fileNameBuffer!=NULL)
	free(fileNameBuffer);
	}

	/////////////////////////////////////////////////////////////////////////////////////
	//deleteLinkedList()
void deleteLinkedList(){
//commandHandler item=head;
    while (head)
    {
        commandHandler* old = head;
        head = head->next;
        delete old;
    }
	head=NULL;

}