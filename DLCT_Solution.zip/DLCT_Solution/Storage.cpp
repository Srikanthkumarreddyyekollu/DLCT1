#include "stdafx.h"
#include "Structures.h"
#include <stdio.h>

extern char ConfigDirectory[StandardBuffer];
extern char RegisteredInfoFile[StandardBuffer];
registerResponseObjStucture getRegisterResponseObject(char *response);
extern int	UnSuccessfulReturnValue;
char registerFileBuff[StandardBuffer];
Logger Storage_cpp =  Logger::getInstance("Storage.cpp");

	//extractRegistrationDetails()
	registerResponseObjStucture extractRegistrationDetails(){
	LOG4CPLUS_INFO(Storage_cpp,"Starting Function extractRegistrationDetails()");	
	char fileBuffer[StandardBuffer];
	char pointerToReceivedBuff[StandardBuffer];
	memset(fileBuffer,'\0',sizeof(fileBuffer));
	memset(pointerToReceivedBuff,'\0',sizeof(pointerToReceivedBuff));
	registerResponseObjStucture registerResponseObjStuctureObj;
	registerResponseObjStuctureObj.ftpInterval=UnSuccessfulReturnValue;//to check whether reading from file is pass or fail.

	strcpy(fileBuffer,ConfigDirectory);
	strcat(fileBuffer,"\\");
	strcat(fileBuffer,RegisteredInfoFile);

	
	//copy fo registerBuff
	strcpy(registerFileBuff, fileBuffer);
	//printf("\nRegister path : %s", registerFileBuff);

	FILE *outputFile = fopen(fileBuffer, "r");

	if(outputFile!=NULL){
	fscanf(outputFile, "%s\n", pointerToReceivedBuff);
	fclose(outputFile);
	//getRegisterResponseObject()
	try{
	registerResponseObjStuctureObj=getRegisterResponseObject(pointerToReceivedBuff);
	}catch(...){LOG4CPLUS_ERROR(Storage_cpp,"Unable To Parse Register File Data");
				registerResponseObjStuctureObj.ftpInterval=UnSuccessfulReturnValue;
				}
	}else{
	char MesgBuffer[StandardBuffer]="No permission to read Register File Data Or file doesn't exist- ";
	strcat(MesgBuffer,fileBuffer);
	LOG4CPLUS_ERROR(Storage_cpp,MesgBuffer);
	}
	//printf("PATH:%s\n", registerResponseObjStuctureObj.ftpPath);
	return registerResponseObjStuctureObj;
}

	//=========================================================================================================
	//storeRegistrationDetails()
	bool storeRegistrationDetails(char *pointerToReceivedBuff){	

	char ftpdataBufferToFile[StandardBuffer];
	strcpy(ftpdataBufferToFile,ConfigDirectory);
	strcat(ftpdataBufferToFile,"\\");
	strcat(ftpdataBufferToFile,RegisteredInfoFile);
	FILE *outputFile = fopen(ftpdataBufferToFile, "w");
	if(outputFile==NULL){
	LOG4CPLUS_ERROR(Storage_cpp, "Unable To Store Registration Data");
	return false;
	}else{
	fprintf(outputFile, "%s\n", pointerToReceivedBuff);// return of this also not able to catch, Exception handling is difficult here
	}
	if(outputFile!=NULL)
	fclose(outputFile);

	return true;
	}//storeRegistrationDetails()