#include "stdafx.h"

#include "commandLinkedList.h"
using namespace std;
extern int	UnSuccessfulReturnValue;
extern char BlockUsbRegistryUsbCommand[buffSizePropertiesNameFromPropertiesFile];
extern char UnBlockUsbRegistryUsbCommand[buffSizePropertiesNameFromPropertiesFile];
extern char BLOCKCDROM[buffSizePropertiesNameFromPropertiesFile];
extern char UNBLOCKCDROM[buffSizePropertiesNameFromPropertiesFile];
extern commandHandler *head; //commandLinkedList.h
commandHandler *monitoringDevice=NULL;
Logger DeviceCommandExecutable_cpp =  Logger::getInstance("DeviceCommandExecutable.cpp");

//std::string exec(char* cmd);
	//runDeviceCommand()
	int runDeviceCommand(char *tempDeviceCommandBuff){
	char deviceCommandBuff[StandardBuffer];
	int returnValue=true;
	memset(deviceCommandBuff,0,sizeof(deviceCommandBuff));
	strcpy(deviceCommandBuff,tempDeviceCommandBuff);

	if( strcmp(deviceCommandBuff,"BLOCKUSB") == 0 ){
	//char *cmd=BlockUsbRegistryUsbCommand;
	memset(deviceCommandBuff,0,sizeof(deviceCommandBuff));
	strcpy(deviceCommandBuff,BlockUsbRegistryUsbCommand);
		// std::string puttyAvilabilityResult=exec(BlockUsbRegistryUsbCommand);
		// if (puttyAvilabilityResult.compare("\0")==0){
		// cout << "FailURE- BLOCKUSB" << endl;
		// }else{
		// returnValue=false;
		// cout << "HEY: SUCCESS- BLOCKUSB" << endl;
		// }
	}else if( strcmp(deviceCommandBuff,"UNBLOCKUSB") == 0 ){
	memset(deviceCommandBuff,0,sizeof(deviceCommandBuff));
	strcpy(deviceCommandBuff,UnBlockUsbRegistryUsbCommand);
		// std::string puttyAvilabilityResult = exec(UnBlockUsbRegistryUsbCommand);
		// if (puttyAvilabilityResult.compare("\0")==0){
		// cout << "FailURE- UNBLOCKUSB" << endl;
		// }else{
		// returnValue=false;
		// cout << "HEY: SUCCESS- UNBLOCKUSB" << endl;
		// }
	
	}else if( strcmp(deviceCommandBuff,"BLOCKCDROM") == 0 ){
	memset(deviceCommandBuff,0,sizeof(deviceCommandBuff));
	strcpy(deviceCommandBuff,BLOCKCDROM);
	
	}else if( strcmp(deviceCommandBuff,"UNBLOCKCDROM") == 0 ){
	memset(deviceCommandBuff,0,sizeof(deviceCommandBuff));
	strcpy(deviceCommandBuff,UNBLOCKCDROM);
	}
	
	try{
	// cout << "DEVICE COMMAND IS: " << deviceCommandBuff  << endl;
	returnValue=system(deviceCommandBuff);
	////cout << "Received Device Commad is:::::::: "  <<  returnValue << endl;	
	//returnValue=system(deviceCommandBuff);
	}catch(...){LOG4CPLUS_FATAL(DeviceCommandExecutable_cpp,"runDeviceCommand(), fails, to run device commands");
				int returnValue=UnSuccessfulReturnValue;
			}
	try{
	if(tempDeviceCommandBuff!=NULL)
	free(tempDeviceCommandBuff);
	}catch(...){/* LOG4CPLUS_ERROR(DeviceCommandExecutable_cpp,"Deleting Pointer- Problem"); */}
	return returnValue;
	}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	int deviceCommandsTesting(std::string pointerToReceivedBuff){	
	commandHandler *curr; //commandLinkedList.h
	const char *receivedBuffer;
	try{
	int returnValue=UnSuccessfulReturnValue;
	char tempDeviceCommandBuff[StandardBuffer];
	receivedBuffer = pointerToReceivedBuff.c_str();
	
	curr = (commandHandler *)malloc(sizeof(commandHandler));	
	strcpy(curr->command,receivedBuffer);
	curr->next = NULL;
	if(head==NULL){
	head=curr;
	monitoringDevice=curr;
	}else{
	monitoringDevice->next=curr;
	monitoringDevice=curr;
	}

	memset(tempDeviceCommandBuff,0,sizeof(tempDeviceCommandBuff));
	sprintf(tempDeviceCommandBuff,"%s",receivedBuffer);
	for(int i=0; tempDeviceCommandBuff[i]!='\0' ;i++)
	tempDeviceCommandBuff[i]=tempDeviceCommandBuff[i+1];
	int length=strlen(tempDeviceCommandBuff);
	tempDeviceCommandBuff[length-1]='\0';
	// /*int length=strlen(tempDeviceCommandBuff);
	// tempDeviceCommandBuff[length]='\0';
	
	//runFirewallCommand
	returnValue=runDeviceCommand(tempDeviceCommandBuff);
	//monitoringDevice=NULL; curr=NULL;//WRONG
	return returnValue;
	}catch(...){LOG4CPLUS_FATAL(DeviceCommandExecutable_cpp,"DeviceCommandsTesting(), fails, May be no permission to write to file at this directory");
				int returnValue=UnSuccessfulReturnValue;

				return returnValue;
				}
	}
	