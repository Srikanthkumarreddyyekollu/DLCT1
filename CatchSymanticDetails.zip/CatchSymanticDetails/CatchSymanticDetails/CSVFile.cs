﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using System.Data.OleDb;
using System.Globalization;

namespace CatchSymanticDetails
{
    class CSVFile
    {
        static void Main()
        {
            string csvPath = "C:/Users/ab78690/Desktop/NonCRAccounts_InCRServers_MonthlyReport-2018-04-16.csv";
            CSVFile obj = new CSVFile();
            bool head = true;
            DataTable dt = obj.GetDataTableFromCsv(csvPath, head);
        }

        public DataTable GetDataTableFromCsv(string path, bool isFirstRowHeader)
        {
            string header = isFirstRowHeader ? "Yes" : "No";
            string pathOnly = Path.GetDirectoryName(path);
            string fileName = Path.GetFileName(path);
            string sql = @"SELECT * FROM [" + fileName + "]";
            using (OleDbConnection connection = new OleDbConnection(
                      @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + pathOnly +
                      ";Extended Properties=\"Text;HDR=" + header + "\""))
            using (OleDbCommand command = new OleDbCommand(sql, connection))                
            using (OleDbDataAdapter adapter = new OleDbDataAdapter(command))
            {
                DataTable dataTable = new DataTable();
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                dataTable.Locale = CultureInfo.CurrentCulture;
                adapter.Fill(dataTable);
                return dataTable;
            }
        }
    }
}
