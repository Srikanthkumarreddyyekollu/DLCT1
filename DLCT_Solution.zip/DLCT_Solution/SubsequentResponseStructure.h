struct subSequentResponseJsonStruct{
	char *status;
	int subActivityId;
	};
typedef struct subSequentResponseJsonStruct subSequentResponseJsonStucture;

struct subSequentResponseObjStruct{
	char *status;
	int subActivityId;
};
typedef struct subSequentResponseObjStruct subSequentResponseObjStucture;