#include "stdafx.h"
#include "commandLinkedList.h"
using namespace std;
extern char FirewallDirectory[StandardBuffer];
extern char FirewallExecutable[StandardBuffer];
extern int	UnSuccessfulReturnValue;

//commandHandler *curr, *head=NULL, *monitoring=NULL; //commandLinkedList.h
extern commandHandler *head; //commandLinkedList.h
commandHandler *monitoringFirewall=NULL;
Logger FirewallCommandExecutable_cpp =  Logger::getInstance("FirewallCommandExecutable.cpp");
	//runFirewallCommand()
	int runFirewallCommand(char *firewallCommad){
//cout<< "START LLL " << endl;
	char firewallCommandBuff[StandardBuffer];
	int returnValue;
	memset(firewallCommandBuff,0,sizeof(firewallCommandBuff));
	strcpy(firewallCommandBuff,FirewallDirectory);
	strcat(firewallCommandBuff,"\\");
	strcat(firewallCommandBuff,FirewallExecutable);
	strcat(firewallCommandBuff," ");
	strcat(firewallCommandBuff,firewallCommad);
	//cout << "FINAL: " << firewallCommandBuff  << endl;
	
	//LOG4CPLUS_INFO(FirewallCommandExecutable_cpp, "kula fce " << firewallCommandBuff);
	try{
	returnValue=system(firewallCommandBuff);

	}catch(...){LOG4CPLUS_FATAL(FirewallCommandExecutable_cpp,"runFirewallCommand(), fails, Unable to run firewallcommand");
				int returnValue=UnSuccessfulReturnValue;
				}
	try{
	if(firewallCommad!=NULL)
	free(firewallCommad);
	}catch(...){ /*LOG4CPLUS_ERROR(FirewallCommandExecutable_cpp,"Deleting Pointer- Problem");*/ }
	return returnValue;
	}
	//////////////////////////////////////////////////////////////////////////////////

	//firewallCommandsTesting()
	int firewallCommandsTesting(std::string pointerToReceivedBuff){	
	commandHandler *curr; //commandLinkedList.h
	const char *receivedBuffer;
	try{
	int returnValue=UnSuccessfulReturnValue;
	char tempFirewallCommandBuff[StandardBuffer];
	receivedBuffer = pointerToReceivedBuff.c_str();
	//cout << "Received buffer: " << receivedBuffer << endl;
	curr = (commandHandler *)malloc(sizeof(commandHandler));	
	strcpy(curr->command,receivedBuffer);
	curr->next = NULL;
	if(head==NULL){
	head=curr;
	monitoringFirewall=curr;
	}else{
	monitoringFirewall->next=curr;
	monitoringFirewall=curr;
	}

	memset(tempFirewallCommandBuff,0,sizeof(tempFirewallCommandBuff));
	sprintf(tempFirewallCommandBuff,"%s",receivedBuffer);
	for(int i=0; tempFirewallCommandBuff[i]!='\0' ;i++)
	tempFirewallCommandBuff[i]=tempFirewallCommandBuff[i+1];
	int length=strlen(tempFirewallCommandBuff);
	tempFirewallCommandBuff[length-1]='\0';
	//cout << "Received buffer22222222222: " << tempFirewallCommandBuff << endl;
	//runFirewallCommand
	returnValue=runFirewallCommand(tempFirewallCommandBuff);
	//monitoringFirewall=NULL; curr=NULL;//WRONG
	return returnValue;
	}catch(...){LOG4CPLUS_FATAL(FirewallCommandExecutable_cpp,"firewallCommandsTesting(), fails, May be no permission to write to file at this directory");
				int returnValue=UnSuccessfulReturnValue;
				//monitoringFirewall=NULL; curr=NULL;//WRONG
				return returnValue;
				}
	}
	///////////////////////////////////////////////////////////////////////////////////////
	