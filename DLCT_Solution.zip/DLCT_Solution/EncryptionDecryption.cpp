// cryptoPLUS_PLUS.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "modes.h"
#include "des.h"
#include "hex.h"
#include <iostream>
#include <time.h>
#include <windows.h>

USING_NAMESPACE(CryptoPP)
USING_NAMESPACE(std)
char *encryptedDecryptedString;
extern byte key[50];
extern byte  iv[50];

// char * encryption(char *buffer, keyParam, ivParam){
char * encryption(char *buffer){
//cout << "IN to encrypting is " << endl;

	unsigned int outputLength;	
	//byte plaintext[] = "{\"machineName\":}";// \"XIN009ODTRN6\"}";
	//char *buffer = "{\"machineName\": \"XIN009ODTRN6\", \"ipAddress\": \"10.140.1.227\", \"cuid\": \"svij\"}";
	int buffLength=strlen(buffer);
	byte *plaintext = new byte[buffLength+1];
	memcpy(plaintext,buffer,buffLength);
	plaintext[buffLength]='\0';
	byte * ciphertext;
	HexEncoder hexEncoderTemp;
	CBC_Mode<DES_EDE3>::Encryption ecbEncryption(key,DES_EDE3::DEFAULT_KEYLENGTH, iv);
	StreamTransformationFilter encryptor(ecbEncryption, NULL,StreamTransformationFilter::ZEROS_PADDING);
	//encryptor.Put(plaintext, sizeof(plaintext));
	encryptor.Put(plaintext, buffLength);
	encryptor.MessageEnd();
	outputLength = encryptor.MaxRetrievable(); 	
	ciphertext = new byte[outputLength];
	encryptor.Get(ciphertext, outputLength);	

	hexEncoderTemp.Put(ciphertext, outputLength);
	hexEncoderTemp.MessageEnd();

	byte *encodedData = new byte[outputLength*2];
	hexEncoderTemp.Get(encodedData, outputLength*2);

	/*int j=0;
	cout << "Encrypted Data is: ";
	for (j=0; j<(outputLength*2); j++) {
	cout << encodedData[j];
	}
	cout << endl;*/
	//str *p = (str*)malloc(sizeof(str));
	//char *s = (char *) malloc(outputLength*sizeof(char)+2); //= *char malloc[k];
	encryptedDecryptedString = new char [outputLength*sizeof(char)*2+1];
	memcpy(encryptedDecryptedString, encodedData, outputLength*2);
	encryptedDecryptedString[(outputLength*2)] = '\0';
	//cout << "Encrypted DATA is: "<< encryptedDecryptedString << endl;
	try{
	if(ciphertext!=NULL)
	free( ciphertext );
	if(encodedData!=NULL)
	delete [] encodedData;
	if(plaintext!=NULL)
	delete [] plaintext;
	}catch(...){ //cout << "POINTER ERROR" << endl;
	}
	return encryptedDecryptedString;
}

char * decryption(char *ptr){
//cout << "IN to Decrypting is " << endl;
	unsigned int outputLength;
	HexDecoder hexDecoderTemp;

	byte * result;
	byte *test = new byte[strlen(ptr)+1];
	memcpy(test,ptr,strlen(ptr));
	test[strlen(ptr)]='\0';	
	outputLength = strlen(ptr);
	hexDecoderTemp.Put(test, outputLength);//*2
	hexDecoderTemp.MessageEnd();
	hexDecoderTemp.MaxRetrievable(); 
	byte *ciphertext = new byte[outputLength];

	hexDecoderTemp.Get(ciphertext, outputLength);

	CBC_Mode<DES_EDE3>::Decryption ecbDecryption(key,DES_EDE3::DEFAULT_KEYLENGTH, iv);
	StreamTransformationFilter decryptor(ecbDecryption, NULL,StreamTransformationFilter::ZEROS_PADDING);
	decryptor.Put(ciphertext, outputLength);
	decryptor.MessageEnd();

	outputLength = decryptor.MaxRetrievable();
	result = new byte[outputLength];
	decryptor.Get(result, outputLength);
	//cout << "recovered plaintext is " << result << endl;

	encryptedDecryptedString = new char [outputLength*sizeof(char)*2+1];
	memcpy(encryptedDecryptedString, result, outputLength*2);
	encryptedDecryptedString[(outputLength*2)] = '\0';
	try{
	if(ciphertext!=NULL)
	delete [] ciphertext;
	if(result!=NULL)
	delete [] result;
	if(test!=NULL)
	delete [] test;
	// if(ptr!=NULL)
	// free(ptr);
	}catch(...){ //cout << "POINTER ERROR -222" << endl; 
	}
return encryptedDecryptedString;
}



