#include "stdafx.h"
#include "soapStub.h"
#include "soapH.h"
#include "resource.h"
#include "cJSON.h"
#include "Structures.h"

extern char FireWallRulesFile[StandardBuffer];
extern char DeviceRulesFile[StandardBuffer];
extern char EncryptDecryptSignal[StandardBuffer];
extern int RegisterInterval;
using namespace std;
ns1__register ns1__registerObj;
ns1__registerResponse ns1__registerResponseObj;
char * encryption(char *receivedString);
char * decryption(char *ptr);
registerResponseObjStucture getRegisterResponseObject(char *response);
bool storeRegistrationDetails(char *pointerToReceivedBuff);
//void ftpThreadInitializer(char usernameFtpServer[StandardBuffer],char passwordFtpServer[StandardBuffer],char addressFtpServer[StandardBuffer],char remoteDirPath[StandardBuffer],int interval);//void *param
void ftpThreadInitializer(void *param);
void deleteFile(char *fileNameBuffer);
void runStoredCommands();
struct soap *soapObj = soap_new(); 
bool success;
int failure;
int soap_call___ns1__registerStatus;
char errorMsg[StandardBuffer];
char errorMsgBuffer[StandardBuffer];
int jump=false;

bool registerWS(CString request){
	
	Logger RegisterClient_cpp =  Logger::getInstance("RegisterClient.cpp");
	LOG4CPLUS_INFO(RegisterClient_cpp,"Starting Function registerWS()");

	int rulesRegWSFails=false;
	int returnValue;

	CT2A requestCT2A(request);  // uses LPCTSTR conversion operator for CString and CT2A constructor
	//const char * requestCharPtr = requestCT2A; // uses LPSTR conversion operator for CT2A// ORIGINAL
	char * requestCharPtr = requestCT2A; // uses LPSTR conversion operator for CT2A
	//if(strcmp(EncryptDecryptSignal,"on")==0)//for register webservice we are not encrypting or decrypting
	//requestCharPtr = encryption(requestCharPtr);//for register webservice we are not encrypting or decrypting
	std::string requestString (requestCharPtr); // ues std::string constructor 
	std::string responseJSON;

	success=false;
	failure=false;
	soap_call___ns1__registerStatus=false;
////cout << "DATA IS: " << requestString << endl;
	ns1__registerObj.request=&requestString;
	//ns1__registerObj.request=&requestString;
	registerResponseObjStucture registerResponseObjStuctureObj;
	registerResponseObjStucture *registerResponseObjStucturePtr;
	while(true){ //infinite loop from method register() (dlct.cpp)
		//soap_call___ns1__register();
		try{
			int soap_ReturnVal = soap_call___ns1__register(soapObj, NULL, NULL, &ns1__registerObj, &ns1__registerResponseObj) ;
			LOG4CPLUS_INFO(RegisterClient_cpp, "soap_ReturnVal for register  :" << soap_ReturnVal); //kulaFlag= 404 error

			if (soap_ReturnVal == SOAP_OK)  //Srikanth - only if success
		{ 
					
			try{
		soap_call___ns1__registerStatus=true;
		responseJSON=*ns1__registerResponseObj.return_;
		LOG4CPLUS_INFO(RegisterClient_cpp,"soap_call___ns1__register - SUCCESS");
				}catch(...){ LOG4CPLUS_ERROR(RegisterClient_cpp,"return Value by soap_call___ns1__register(), can't be initialized"); soap_call___ns1__registerStatus=false; }
		//cout << "CHECK POINT LOOP, RegisterClient.cpp:" << responseJSON << endl;
		
		} 
			else{
		LOG4CPLUS_ERROR(RegisterClient_cpp,"soap_call___ns1__register- FAILURE, into else part"); 
		//char *code = ( char *) malloc(1000 * sizeof(char));
		memset(errorMsg,false,sizeof(errorMsg));
        soap_sprint_fault(soapObj, errorMsg, StandardBuffer);
		errorMsg[sizeof(errorMsg) - 1] = '\0';

		//LOG4CPLUS_INFO(RegisterClient_cpp, " kula log outputfile error mmessage: " << errorMsg);
		//LOG4CPLUS_INFO(RegisterClient_cpp, " kula log outputfile soapObj : " << soapObj);

		LOG4CPLUS_ERROR(RegisterClient_cpp,errorMsg);
		// // soap_end(soapObj);
		// // soap_free(soapObj); 
		try{
		responseJSON=*ns1__registerResponseObj.return_;
		jump=true;
		}catch(...){ LOG4CPLUS_ERROR(RegisterClient_cpp,"return Value by soap_call___ns1__register(), can't be initialized"); jump=false; }
		
		if(jump==true){
		LOG4CPLUS_ERROR(RegisterClient_cpp,"DATA RECEIVED IS : ");
		

		memset(errorMsg,false,sizeof(errorMsg));
		strncpy(errorMsg, responseJSON.c_str(), sizeof(errorMsg));
		errorMsg[sizeof(errorMsg) - 1] = 0;
		
		memset(errorMsgBuffer,false,sizeof(errorMsgBuffer));
		strcpy(errorMsgBuffer,"Received Register Response is -");
		strcat(errorMsgBuffer,errorMsg);
		LOG4CPLUS_ERROR(RegisterClient_cpp,errorMsgBuffer);

		}
		jump=true;
		soap_call___ns1__registerStatus=false;
		}//else
		}catch(...){soap_call___ns1__registerStatus=false; 
		LOG4CPLUS_ERROR(RegisterClient_cpp,"register - FAILURE, exception Caught"); }
		if(soap_call___ns1__registerStatus==true){
			failure=true;
			char * responseCharPtr = new char[responseJSON.size() + true];

			std::copy(responseJSON.begin(), responseJSON.end(), responseCharPtr);
			responseCharPtr[responseJSON.size()] = '\0';
			try{
			//storeRegistrationDetails();
			LOG4CPLUS_INFO(RegisterClient_cpp,"Storing Registration Details to file");
			if(responseCharPtr!=NULL){
			//if(strcmp(EncryptDecryptSignal,"on")==0)////for register webservice we are not encrypting or decrypting
			//responseCharPtr=decryption(responseCharPtr);////for register webservice we are not encrypting or decrypting
			returnValue=storeRegistrationDetails(responseCharPtr);/////////writing to file
			}
			if(returnValue==false){
			failure=false;
			LOG4CPLUS_ERROR(RegisterClient_cpp,"storeRegistrationDetails() FAILES, Problem in writing to file");
			}//if
			}catch(...){LOG4CPLUS_ERROR(RegisterClient_cpp,"Exception Caught, StoreRegistrationDetails() FAILES, Problem in writing to file");
			responseCharPtr==NULL;failure=false;}
			try{
			//getRegisterResponseObject();
			if(responseCharPtr!=NULL){
			//printf("HELLO\n");
			LOG4CPLUS_INFO(RegisterClient_cpp,"getRegisterResponseObject() going to be called for parsing");
			//Sleep(1000000);
			registerResponseObjStuctureObj=getRegisterResponseObject(responseCharPtr);//responseCharPtr Pointer getting free in 
			}
			}catch(...){failure=false;LOG4CPLUS_FATAL(RegisterClient_cpp,"Unable To Parse Register Response JSON");}

			if(failure==true){
			try{
			LOG4CPLUS_INFO(RegisterClient_cpp,"ftpThreadInitializer() going to be called from RegisterClient.cpp")

			registerResponseObjStucturePtr = (registerResponseObjStucture *)malloc(sizeof(registerResponseObjStucture));

			registerResponseObjStucturePtr->ftpUsername = registerResponseObjStuctureObj.ftpUsername;
			registerResponseObjStucturePtr->ftpPassword = registerResponseObjStuctureObj.ftpPassword;
			registerResponseObjStucturePtr->ftpUrl = registerResponseObjStuctureObj.ftpUrl;
			registerResponseObjStucturePtr->ftpPath = registerResponseObjStuctureObj.ftpPath;
			registerResponseObjStucturePtr->ftpInterval = registerResponseObjStuctureObj.ftpInterval;
			registerResponseObjStucturePtr->clientID = registerResponseObjStuctureObj.clientID;
			registerResponseObjStucturePtr->contentRetrievalInterval = registerResponseObjStuctureObj.contentRetrievalInterval;
			for (int loop=0; loop < 24; loop++)
				registerResponseObjStucturePtr->signKey[loop] = registerResponseObjStuctureObj.signKey[loop];
			for (int loop=0; loop < 8; loop++)
				registerResponseObjStucturePtr->cryptKey[loop] = registerResponseObjStuctureObj.cryptKey[loop];

//for (int loop=0; loop < 24; loop++)
//printf("values getting storeddddddddddddd is:%02X\n",registerResponseObjStucturePtr->signKey[loop]);
			try{
			HANDLE handleValue = (HANDLE) _beginthread( ftpThreadInitializer, false, (void*) registerResponseObjStucturePtr);
			}catch(...){
			LOG4CPLUS_ERROR(RegisterClient_cpp,"Thread- ftpThreadInitializer() going to restart,NEED TO REMOVE THIS ERROR");
			HANDLE handleValue = (HANDLE) _beginthread( ftpThreadInitializer, false, (void*) registerResponseObjStucturePtr);
			}
			
			/////////////////////////////////////////////////////////////////////////////////////////////////////////////////	//ftpThreadInitializer(registerResponseObjStuctureObj.ftpUsername,registerResponseObjStuctureObj.ftpPassword,registerResponseObjStuctureObj.ftpUrl,registerResponseObjStuctureObj.ftpPath,registerResponseObjStuctureObj.ftpInterval);
			}catch(...){failure=false;LOG4CPLUS_FATAL(RegisterClient_cpp,"Unable To Initialize FTP Thread");}
			}//if(failure==false)
			// if(responseCharPtr!=NULL)//getting Error HERE , Future Enhancement
			// delete [] responseCharPtr;

		}

		if(failure==false){
			if(rulesRegWSFails==false){
				rulesRegWSFails=true;
			try{
				LOG4CPLUS_ERROR(RegisterClient_cpp,"Loading Stored Commands");
				//runStoredCommands()
				runStoredCommands();
				}catch(...){LOG4CPLUS_ERROR(RegisterClient_cpp,"Unable To Run Stored Commands");rulesRegWSFails=false;}
			}
			LOG4CPLUS_INFO(RegisterClient_cpp,"Sleeping for RegisterInterval time, mentioned in property file");//srikanth - currently 24 hours
			Sleep(RegisterInterval);
		}else{
			success=true;
			break;
			}

		Sleep(threadWait);
	}//while
	
	if(success==true){
	LOG4CPLUS_INFO(RegisterClient_cpp,"Registering client Successful");
	LOG4CPLUS_INFO(RegisterClient_cpp,"Deleting old commands file");
		//deleteFile()
		deleteFile(FireWallRulesFile);
		deleteFile(DeviceRulesFile);
	}
		try{
		if(requestCharPtr!=NULL)
		free(requestCharPtr);
		soap_end(soapObj);
		soap_free(soapObj); 
		}catch(...){ LOG4CPLUS_ERROR(RegisterClient_cpp,"*** ERROR in dleting pointer requestCharPtr & soapObj ***"); }

	return success;

}