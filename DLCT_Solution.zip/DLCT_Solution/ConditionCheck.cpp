#include "stdafx.h"
//#include <stdio.h>
using namespace std;
extern char FirewallDirectory[StandardBuffer];
extern int FirewallCheckDelay;
extern int FirewallCheckCount;
extern char FirewallExecutable[StandardBuffer];
Logger ConditionCheck_cpp =  Logger::getInstance("ConditionCheck.cpp");

 int isFirewallAvailable(){
	LOG4CPLUS_INFO(ConditionCheck_cpp,"Starting Fuction isFirewallAvailable()");
	int returnValue;
	int count=false;
	int returnStatus=false;
	char firewallCheckbuff[StandardBuffer];
	sprintf(firewallCheckbuff,"%s\\%s list" ,FirewallDirectory,FirewallExecutable);

	while(true){
	try{
	//cout << "Checkin is: " << firewallCheckbuff << endl;
	returnValue=system(firewallCheckbuff);
	}catch(...){ LOG4CPLUS_ERROR(ConditionCheck_cpp,"Exception Caught, in to catch block, Fails in to checking firewall status"); }
	if(returnValue!=0){
		LOG4CPLUS_ERROR(ConditionCheck_cpp,"Firewall is not available");
		if(count!=FirewallCheckCount){
		count++;
		
		(FirewallCheckDelay);
		}else{
		returnStatus=false;
		break;
		}//else
	}else{
	LOG4CPLUS_INFO(ConditionCheck_cpp,"Firewall available, Returning TRUE");
	returnStatus=true;
	break;
	}
	Sleep(threadWait); //kula add----
	}//while
 return returnStatus;
 }
 