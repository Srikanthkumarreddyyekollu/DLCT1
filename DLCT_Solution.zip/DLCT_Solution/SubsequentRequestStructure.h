struct subSequentRequestJsonStruct{
	char *status;
	int subActivityId;
	char *checksum;
};
typedef struct subSequentRequestJsonStruct subSequentRequestJsonStucture;

struct subSequentRequestObjStruct{
	char *status;
	int subActivityId;
	char *checksum;
};
typedef struct subSequentRequestObjStruct subSequentRequestObjStucture;