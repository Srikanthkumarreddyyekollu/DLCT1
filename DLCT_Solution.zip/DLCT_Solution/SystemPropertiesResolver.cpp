#include "stdafx.h"
#include "Structures.h" 

using namespace std;
char hostName[hostNameBuff];
systemPropertiesStructure getSystemProperties();
	Logger SystemPropertiesResolver_cpp = Logger::getInstance("SystemPropertiesResolver.cpp");	
	//===============================================================================
	//getUsername()
	void getUsername(systemPropertiesStructure *systemPropertiesStructureObj){
	    // // char acUserName[100];
		// // DWORD nUserName = sizeof(acUserName);
		// // if (GetUserName(acUserName, &nUserName)){ 
		// // systemPropertiesStructureObj->cuid=acUserName;
		// // }else{
		// // LOG4CPLUS_FATAL(SystemPropertiesResolver_cpp, "Error into finding Username");
		// // throw;
		// // }
		
	 char *username=getenv("USERNAME");
	 systemPropertiesStructureObj->cuid=username;
	}//getUsername()
	
	//================================================================================
	//getHostName()
	int getHostName(systemPropertiesStructure *systemPropertiesStructureObj){
	if( gethostname ( hostName, sizeof(hostName)) == false){
		systemPropertiesStructureObj->machineName=hostName;
		return false;
	}else{
		return true;
	}
	}//getHostName()
	
	//================================================================================
	//getIpAddress_HostName(){
	void getIpAddress_HostName(systemPropertiesStructure *systemPropertiesStructureObj){

	WORD wVersionRequested;
	WSADATA wsaData;
	CString ip;
	PHOSTENT hostInfo;
	char ipstring[StandardBuffer];
	wVersionRequested = MAKEWORD( two, false );

	if ( WSAStartup( wVersionRequested, &wsaData ) == false )
	{
		//getHostName()
		int i=getHostName(systemPropertiesStructureObj);
		{
			if((hostInfo = gethostbyname(hostName)) != NULL)
			{
				ip = inet_ntoa (*(struct in_addr *)*hostInfo->h_addr_list);
				string ipaddress = string(CT2CA(ip));
				const char *ipAddress = ipaddress.c_str();
				char *pointer;
				strcpy (ipstring,ipAddress );
				pointer=ipstring;
				systemPropertiesStructureObj->ipAddress=pointer;
			}											
		}

		WSACleanup( );
	} 
	}//getIpAddress_HostName()
	
	//====================================================================================
	//getSystemProperties()
	systemPropertiesStructure getSystemProperties(){

	try{
	systemPropertiesStructure systemPropertiesStructureObj;
	getUsername(&systemPropertiesStructureObj);
	getIpAddress_HostName(&systemPropertiesStructureObj);
	return systemPropertiesStructureObj;
	}catch (...){ LOG4CPLUS_FATAL(SystemPropertiesResolver_cpp, "Unable To Determine System Properties"); exit(false); }
	}//getSystemProperties()
	//=====================================================================================