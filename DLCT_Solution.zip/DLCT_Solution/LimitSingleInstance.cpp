
#include "LimitSingleInstance.h" 
#include "stdafx.h" 
void LimitSingleInstance()
{

	CLimitSingleInstance lsi(TEXT("Global\\{6610c7a0-e6ea-4ff9-a3f7-62bdf2043481}"));

	/*We can generate a GUID in many ways. Visual Studio has a GUID generator, or go here:
	http://www.guidgenerator.com/online-guid-generator.aspx */

	if (lsi.IsAnotherInstanceRunning())
	{
		MessageBoxA(HWND_DESKTOP, "DLCT.exe already running in your system. \n\tPress OK to close!", "DLCT Process status", MB_ICONWARNING);

		//cout<<"There's another DLCT window already open!";
		exit(0);
	}

}