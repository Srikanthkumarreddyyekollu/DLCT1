typedef struct {
		char *signKey;
		int subActivityId;
		std::string firewallCommands[1000];
		std::string deviceCommands[1000];
		}retrieveContentResponseStucture;