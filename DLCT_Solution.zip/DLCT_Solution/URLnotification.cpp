#include "stdafx.h"

void notificationThread(void *param);
void ShowNotification(char fileCopy[260]);
void notificationCall(char fileCopy[260]);
using namespace std;

Logger URLnotification_cpp = Logger::getInstance("URLnotification.cpp");

void lastLogfile(void)
{
	WIN32_FIND_DATAW ffd;
	wchar_t const* directory = L"C:\\Windows\\security\\logs"; //LogsDirectory
	wchar_t currentFile[MAX_PATH], lastModifiedFilename[MAX_PATH];
	FILETIME currentModifiedTime, lastModified;
	HANDLE hFile;
	bool first_file = true;

	HANDLE hFind = FindFirstFileW(L"C:\\Windows\\security\\logs\\DLCT*.log", &ffd);
	memset(currentFile, '\0', MAX_PATH);

	if (INVALID_HANDLE_VALUE == hFind)
	{
		return;
	}

	do
	{
		if (!(ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
		{
			wcscpy_s(currentFile, directory);
			wcscat_s(currentFile, ffd.cFileName);
			// open file to read it's last modified time
			hFile = CreateFileW(currentFile, GENERIC_READ, FILE_SHARE_READ, NULL,
				OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
			if (INVALID_HANDLE_VALUE != hFile)
			{
				// get it's last write time
				if (GetFileTime(hFile, NULL, NULL, &currentModifiedTime) != 0)
				{
					if (first_file)
					{
						lastModified = currentModifiedTime;
						wcscpy_s(lastModifiedFilename, ffd.cFileName);
						first_file = false;
					}
					else
					{
						// First file time is earlier than second file time.
						if (CompareFileTime(&lastModified, &currentModifiedTime) == -1)
						{
							lastModified = currentModifiedTime;
							wcscpy_s(lastModifiedFilename, ffd.cFileName);
						}
					}
				}
				CloseHandle(hFile);
			}
		}
	} while (FindNextFileW(hFind, &ffd) != 0);

	FindClose(hFind);

	//------------------------------------------------------------------------------------------------------------------------
	char fileCopy[260];
	char DefChar = ' ';
	WideCharToMultiByte(CP_ACP, 0, ffd.cFileName, -1, fileCopy, 260, &DefChar, NULL);

	string ss(fileCopy);

	//cout << "fileCopy: " << fileCopy << endl << endl;
	if (fileCopy)
	{
	//LOG4CPLUS_INFO(URLnotification_cpp, "Last modified DLCTclinet log file: ");
	}
	else{
		Sleep(1000);
		LOG4CPLUS_WARN(URLnotification_cpp, "No DLCTclient log file found..!");
		}
	ShowNotification(fileCopy);
}



void notificationThread(void *param)
{
	while (true)
	{

			//Sleep(1000);
		lastLogfile();
		Sleep(threadWait); //kula add
		
	}
}

