#include <string>
string dummyHost;