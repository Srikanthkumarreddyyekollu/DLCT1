#include "stdafx.h"
#include "soapStub.h"
#include "soapH.h"
#include "resource.h"
#include "cJSON.h"
#include "Structures.h"
#include "commandLinkedList.h"
//#include "SuspendDLCT.h"
#include <sstream>

using namespace std;
int subActivityId;
extern char FireWallRulesFile[StandardBuffer];
extern char DeviceRulesFile[StandardBuffer];
extern int	UnSuccessfulReturnValue;
extern char EncryptDecryptSignal[StandardBuffer];
extern int ClientId;//FtpFunctions.cpp
extern int NewCID;
extern int contentRetrievalInterval;
static short iterateCount2 = 0;

commandHandler *head;//linkedList

retrieveContentResponseStucture getRetrieveContentObj(char *pointerToReceivedBuff);
int firewallCommandsTesting(std::string firewallCommands);
int deviceCommandsTesting(std::string deviceCommands);
int writeCommandsTOFile(char *fileNamePointer, int type);
int retrieveContentWsStatus;
int tillSynchronizedResponse,ClientIdError;
int ABORT=UnSuccessfulReturnValue;
int firewallSuccessValue=true;
int deviceSuccessValue=true;
int returnCheck;
std::string responseJSON;
std::string requestString;
std::string SYNCHRONIZED;
ns1__retrieveContent ns1__retrieveContentObj;
ns1__retrieveContentResponse ns1__retrieveContentResponseObj;
retrieveContentResponseStucture retrieveContentResponseStuctureObj;
void deleteTempFile(char *fileNameBuffer);
char* getRetrieveContentJSON(int clientId);
void processExecutionResultWS(int status);
int isFirewallAvailable();
void deleteLinkedList();
void processRetrieveContentWS();
char * encryption(char *receivedString);
char * decryption(char *ptr);
Logger RetrieveContentClient_cpp =  Logger::getInstance("RetrieveContentClient.cpp");

	//retrieveContentWS()
	void retrieveContentWS(void *dummy) //thread-2 from DLCT.cpp file
	{
	try {
		LOG4CPLUS_INFO(RetrieveContentClient_cpp,"processRetrieveContentWS(), Getting Called");
		// call processRetrieveContentWS()
		processRetrieveContentWS();
		LOG4CPLUS_INFO(RetrieveContentClient_cpp,"processRetrieveContentWS(), OVER ");
		} catch(...) {
		// call retrieveContentWS()
			LOG4CPLUS_ERROR(RetrieveContentClient_cpp, "retrieveContentWS(),Restarted @ RetrieveContentClient.cpp with processRetrieveContentWS()");
		retrieveContentWS(NULL);
					}	
	
	}//retrieveContentWS()

	//===========================================================================================================
	//processRetrieveContentWS()
	void processRetrieveContentWS()
	{
	int initializedReturnValue = true;
	int firewallAvailbilityStatus=false;
	int	RetrieveContentObjStatus=true;
	char errorMsg[StandardBuffer];
	char errorMsgBuffer[StandardBuffer];
	int jump=false;
	int catchExecution=false;
	char * responseCharPtr;

	while(true){ //infinite loop for retriveContent()
		initializedReturnValue = true;
		LOG4CPLUS_INFO(RetrieveContentClient_cpp,"processRetrieveContentWS(), While LOOP starts");
		retrieveContentWsStatus=false;
		tillSynchronizedResponse=false;
		ClientIdError=true;
		struct soap *soapObj = soap_new();

		char *retrieveContentJsonPtr;

		try{
		LOG4CPLUS_INFO(RetrieveContentClient_cpp,"getRetrieveContentJSON, Going to starts");
		//getRetrieveContentJSON()
		
		retrieveContentJsonPtr=getRetrieveContentJSON(ClientId);

		//retrieveContentJsonPtr = getRetrieveContentJSON(NewCID); Samarendra
		
		
		
		//cout << "sending request is:" << retrieveContentJsonPtr << endl;
		LOG4CPLUS_INFO(RetrieveContentClient_cpp,"getRetrieveContentJSON, OVER");
		if(strcmp(EncryptDecryptSignal,"on")==0)
		retrieveContentJsonPtr = encryption(retrieveContentJsonPtr);
		}catch(...){
					ClientIdError=false;
					LOG4CPLUS_FATAL(RetrieveContentClient_cpp,"Unable To Create RetrieveContent Request JSON");
				   }

		if(ClientIdError==true){
		requestString = retrieveContentJsonPtr;
		SYNCHRONIZED = "SYNCHRONIZED";
		ns1__retrieveContentObj.request=&requestString;
		try{
		if(soap_call___ns1__retrieveContent(soapObj,NULL, NULL, &ns1__retrieveContentObj, &ns1__retrieveContentResponseObj) == SOAP_OK){
		retrieveContentWsStatus=true;
		LOG4CPLUS_INFO(RetrieveContentClient_cpp,"soap_call___ns1__retrieveContent, SUCCESS, Received some value");
		}else{
				
		LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"soap_call___ns1__retrieveContent -ERROR, into else part");
		//soap_print_fault(soapObj, stderr);
		//char *code = malloc(1000 * sizeof(char));
		//int length=1000;
		memset(errorMsg,false,sizeof(errorMsg));
        soap_sprint_fault(soapObj, errorMsg, StandardBuffer);
		errorMsg[sizeof(errorMsg) - 1] = '\0';
		LOG4CPLUS_ERROR(RetrieveContentClient_cpp,errorMsg);
		//cout << "Error: ANIL" << errorBuff << endl;
		try{
		soap_end(soapObj);
		soap_free(soapObj);
		}catch(...)	{ LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"Deleting soapobj- Problem"); }	
		retrieveContentWsStatus=false;
		
			try{
			responseJSON=*ns1__retrieveContentResponseObj.return_;
			jump=true;
			//cout << "RECEIVED DATA IS RCC.cpp: " << responseJSON  << endl;
			}catch(...){LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"soap_call___ns1__retrieveContent,Received value can't be initialized");
			jump=false;
			soap_print_fault(soapObj, stderr);
			// // soap_end(soapObj);
			// // soap_free(soapObj); 
			}//catch
			if(jump==true){
			responseCharPtr = new char[responseJSON.size() + true];
			std::copy(responseJSON.begin(), responseJSON.end(), responseCharPtr);
			responseCharPtr[responseJSON.size()] = '\0';
			if(strcmp(EncryptDecryptSignal,"on")==0)
			responseCharPtr=decryption(responseCharPtr); 
			 cout << "Received String is: " << responseCharPtr << endl;
			 Sleep(40000);
			memset(errorMsg,false,sizeof(errorMsg));
			strncpy(errorMsg, responseCharPtr, sizeof(responseCharPtr));
			errorMsg[sizeof(errorMsg) - 1] = '\0';
		
			memset(errorMsgBuffer,false,strlen(errorMsgBuffer));
			strcpy(errorMsgBuffer,"It will reflect the previous received message, i.e.- ");
			strcat(errorMsgBuffer,errorMsg);
			LOG4CPLUS_ERROR(RetrieveContentClient_cpp,errorMsgBuffer);
			}//if	
		
		}//else
		//LOG4CPLUS_INFO(RetrieveContentClient_cpp,"soap_call___ns1__retrieveContent, Success");
		}catch(...){LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"Exception Caught, soap_call___ns1__retrieveContent FAILES"); 
		retrieveContentWsStatus=false; }
		}//if
		//if(soap_call___ns1__retrieveContent(soapObj,NULL, NULL, &ns1__retrieveContentObj, &ns1__retrieveContentResponseObj) == SOAP_OK){
			if(retrieveContentWsStatus==true && ClientIdError==true){
			try{
			responseJSON=*ns1__retrieveContentResponseObj.return_;
			responseCharPtr = new char[responseJSON.size() + true];
			std::copy(responseJSON.begin(), responseJSON.end(), responseCharPtr);
			responseCharPtr[responseJSON.size()] = '\0';
			if(strcmp(EncryptDecryptSignal,"on")==0)
			responseCharPtr=decryption(responseCharPtr);
			// cout << "Received String123 is: " << responseCharPtr << endl;
			// Sleep(40000);
			/////////responseCharPtr[responseJSON.size()] = '\0';
			//cout << "Received string is:" << responseCharPtr << endl;
			}catch(...){
				LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"soap_call___ns1__retrieveContent,Received value can't be initialized");
			initializedReturnValue = false;
			}//catch
			//if (responseJSON!=SYNCHRONIZED && initializedReturnValue==true){
			if (strcmp(responseCharPtr,"SYNCHRONIZED")!=0 && initializedReturnValue==true){
			// // // char * responseCharPtr = new char[responseJSON.size() + true];
			// // // std::copy(responseJSON.begin(), responseJSON.end(), responseCharPtr);
			// // // responseCharPtr[responseJSON.size()] = '\0';
			///////////char * pointerToReceivedBuff = responseCharPtr;
			//just for security reason if tempfile still exist, just delete it
			// try{
			// deleteTempFile(FireWallRulesFile);
			// deleteTempFile(DeviceRulesFile);
			// }catch(...){LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"Deleting Temp file Initialy, is failed");}
			ABORT=UnSuccessfulReturnValue;
			firewallSuccessValue=true;
			deviceSuccessValue=true;
			firewallAvailbilityStatus=false;
			RetrieveContentObjStatus=true;
			
			try{
			LOG4CPLUS_INFO(RetrieveContentClient_cpp,"getRetrieveContentObj, Going to be called");
			//	getRetrieveContentObj() 
			retrieveContentResponseStuctureObj=getRetrieveContentObj(responseCharPtr);
			LOG4CPLUS_INFO(RetrieveContentClient_cpp,"getRetrieveContentObj, OVER");
			}   catch(...){RetrieveContentObjStatus=false;		tillSynchronizedResponse=true;
			LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"getRetrieveContentObj(), Json failed");}
			if(RetrieveContentObjStatus==true){
			try{
			LOG4CPLUS_INFO(RetrieveContentClient_cpp,"isFirewallAvailable, Going to be called");
			firewallAvailbilityStatus=isFirewallAvailable();
			LOG4CPLUS_INFO(RetrieveContentClient_cpp,"isFirewallAvailable, OVER");
			}catch(...)
			
			{
				LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"Unable To Determine If Firewall Is Available");
				
				firewallAvailbilityStatus=false;
			}
			if( firewallAvailbilityStatus==true )
			{
			LOG4CPLUS_INFO(RetrieveContentClient_cpp,"firewallCommandsTesting, Going to be called");
			head=NULL;//if by any chance Linkedlist pointer is pointing to wrong address
			catchExecution=false;
			for(int forLoop = false; retrieveContentResponseStuctureObj.firewallCommands[forLoop]!="\0"; forLoop++){		
			try{
			//LOG4CPLUS_INFO(RetrieveContentClient_cpp,"firewallCommandsTesting, Going to be called");
			//firewallCommandsToTempFile()
			firewallSuccessValue=firewallCommandsTesting(retrieveContentResponseStuctureObj.firewallCommands[forLoop]);
			//LOG4CPLUS_INFO(RetrieveContentClient_cpp,"firewallCommandsTesting, OVER");
			}catch(...){LOG4CPLUS_WARN(RetrieveContentClient_cpp,"firewallCommandsTesting, Exception Caught");}

				if(firewallSuccessValue!=false){
				//deleteLinkedList()
				try{
				catchExecution=true;
				LOG4CPLUS_INFO(RetrieveContentClient_cpp,"Deleting Linked List, Firewall commands are not executed");
				deleteLinkedList();
				}catch(...){LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"Deleting LinkedList is failed"); }
				if(catchExecution==true){ break; }//for loop break
				}
				}//for
				}//if
				
				if (firewallSuccessValue==false ){
				try{
					LOG4CPLUS_INFO(RetrieveContentClient_cpp,"writeCommandsTOFile, Going to start-Firewall");
					returnCheck=writeCommandsTOFile(FireWallRulesFile,false);
					if(returnCheck==true){
					LOG4CPLUS_INFO(RetrieveContentClient_cpp,"writeCommandsTOFile Success");
					}else{
					LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"writeCommandsTOFile FAILS");					
					}//else
					}catch(...){LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"writeCommandsTOFile is failed, Exception Caught");}
					try{
					LOG4CPLUS_INFO(RetrieveContentClient_cpp,"Deleting Linked List, Firewall commands are executed");
					deleteLinkedList();
					}catch(...){LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"Deleting LinkedList is failed, at firewall success");}
				//printf("Return value Firewall in retrieveContent.cpp is:%d\n",returnCheck);
				}

				head=NULL;//if by any chance Linkedlist pointer is pointing to wrong address
				catchExecution=false;
				/*check retrive content data for clinet*/
				for(int forLoop = false; retrieveContentResponseStuctureObj.deviceCommands[forLoop]!="\0"; forLoop++){
				try{
				//deviceCommandsToTempFile()
				LOG4CPLUS_INFO(RetrieveContentClient_cpp,"deviceCommands testing, Going to be called");
				deviceSuccessValue=deviceCommandsTesting(retrieveContentResponseStuctureObj.deviceCommands[forLoop]);
				LOG4CPLUS_INFO(RetrieveContentClient_cpp,"deviceCommands testing, OVER");
				}catch(...){LOG4CPLUS_WARN(RetrieveContentClient_cpp,"deviceCommandsToTempFile, Exception Caught");}
				if(deviceSuccessValue!=false){
				try{
				///////////////////deleteTempFile(DeviceRulesFile);
				catchExecution=true;
				LOG4CPLUS_INFO(RetrieveContentClient_cpp,"Deleting Linked List, Firewall commands are not executed");
				deleteLinkedList();
				}catch(...){ LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"Deleting DeviceTemp file is failed"); }
				if(catchExecution==true){ break; }//for loop break
				
				}//if
				}//for
				if( deviceSuccessValue==false ){
				try{
				LOG4CPLUS_INFO(RetrieveContentClient_cpp,"writeCommandsTOFile, Going to start-Device");
				returnCheck=writeCommandsTOFile(DeviceRulesFile,true);
				//printf("Return DEvice value in retrieveContent.cpp is:%d\n",returnCheck);
				if(returnCheck==true){
					LOG4CPLUS_INFO(RetrieveContentClient_cpp,"writeCommandsTOFile Success");
					}else{
					LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"writeCommandsTOFile FAILS");					
					}//else
					}catch(...){LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"writeCommandsTOFile is failed, Exception Caught");}
					try{
					LOG4CPLUS_INFO(RetrieveContentClient_cpp,"Deleting Linked List, Device commands are executed");
					deleteLinkedList();
					}catch(...){LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"Deleting LinkedList is failed, at device execution success");}
				}//if

				try{
				subActivityId=retrieveContentResponseStuctureObj.subActivityId;
					}catch(...){LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"Unable To Determine subActivityId");}
				if( (deviceSuccessValue==false && firewallSuccessValue==false) || ( deviceSuccessValue==true && firewallSuccessValue==false ) || ( deviceSuccessValue==false && firewallSuccessValue==true ) || ( deviceSuccessValue==true && firewallSuccessValue==true ) ){
							if(firewallAvailbilityStatus==true){
							//processExecutionResultWS()
							try{
							LOG4CPLUS_INFO(RetrieveContentClient_cpp,"processExecutionResultWS, Going to be start FOR true Value");
							processExecutionResultWS(true);
							LOG4CPLUS_INFO(RetrieveContentClient_cpp,"processExecutionResultWS, over");
							}catch(...){LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"processExecutionResultWS, for TRUE is fail");}
							}else{
							try{
							tillSynchronizedResponse=true;
							LOG4CPLUS_INFO(RetrieveContentClient_cpp,"processExecutionResultWS, Going to be start FOR ABORT Value");
							processExecutionResultWS(ABORT);
							LOG4CPLUS_INFO(RetrieveContentClient_cpp,"processExecutionResultWS, over");
							}catch(...){LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"processExecutionResultWS, for ABORT is fail");}
							}

				}else{
				//processExecutionResultWS()
				try{
				LOG4CPLUS_INFO(RetrieveContentClient_cpp,"processExecutionResultWS, Going to be start FOR false Value");
				processExecutionResultWS(true);
				LOG4CPLUS_INFO(RetrieveContentClient_cpp,"processExecutionResultWS, over");
				}catch(...){LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"processExecutionResultWS, is fail");}
				}
				
				try{
				if(responseCharPtr!=NULL)
				free(responseCharPtr);
				// if(pointerToReceivedBuff!=NULL)
				// free(pointerToReceivedBuff);
				}catch(...){ LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"Error in deleteing pointer responseCharPtr & pointerToReceivedBuff "); } 

			}//if
			}else{
			tillSynchronizedResponse=true;
			if(initializedReturnValue == false){
			LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"Problem with return Value of WS,soap_call___ns1__retrieveContent");
				}else{
			//printf("Received SYNCHRONIZED\n");
			LOG4CPLUS_INFO(RetrieveContentClient_cpp,"RetrieveContent Result - SYNCHRONIZED");
				}//else
			}

		}else{
		tillSynchronizedResponse=true;
		LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"RetrieveContent Result - FAILURE");
		}//else
		
		if (tillSynchronizedResponse==true){
		try{
		Sleep(contentRetrievalInterval); //before-- 60 minute time to wait, 24hr--server now
		}catch(...){ contentRetrievalInterval=10000;
		LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"contentRetrievalInterval - FAILURE"); }
		}//if

		try{
		soap_end(soapObj);
		soap_free(soapObj); 
		}catch(...){LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"Unable to clear soapObj pointer");}
	
		if(retrieveContentJsonPtr!=NULL){
		try{
		free(retrieveContentJsonPtr);
		}catch(...){LOG4CPLUS_ERROR(RetrieveContentClient_cpp,"Unable to clear retrieveContentJsonPtr pointer");}
		}
		/////////return success;

		LOG4CPLUS_INFO(RetrieveContentClient_cpp, "24 hours waiting time started....iterateCount= ", iterateCount);

		Sleep(DLCTwaitInterval); //---kula---Sleep for 24 hour
					
	}//Infinite loop while end
	}//processRetrieveContentWS()

