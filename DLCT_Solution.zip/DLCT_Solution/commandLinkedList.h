struct list_el {
	char command[1024];
	struct list_el * next;
};
typedef struct list_el commandHandler;