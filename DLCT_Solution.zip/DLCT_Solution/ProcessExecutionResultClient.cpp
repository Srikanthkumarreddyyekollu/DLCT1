#include "stdafx.h"
#include "soapStub.h"
#include "soapH.h"
#include "resource.h"
#include "cJSON.h"
#include "Structures.h"
#include <sstream>
using namespace std;
extern int subActivityId;
extern int	UnSuccessfulReturnValue;
extern char EncryptDecryptSignal[StandardBuffer];
char* getProcessExecutionJSON(processExecutionResultObjStructure processExecutionResultObjStructureObj);
char * encryption(char *receivedString);
char * decryption(char *ptr);

void processExecutionResultWS(int status){
	char msgBuffer[StandardBuffer];
	int checksum=400;
	int failure=false;
	int soap_call___ns1__processExecutionResultStatus=false;
	char *ProcessExecutionJSONPtr;
	processExecutionResultObjStructure processExecutionResultObjStructureObj;
	ns1__processExecutionResult ns1__processExecutionResultObj;
	ns1__processExecutionResultResponse ns1__processExecutionResultResponseObj;
	Logger ProcessExecutionResultClient_cpp =  Logger::getInstance("ProcessExecutionResultClient.cpp");
	std::string responseJSON;
	struct soap *soapObj = soap_new();

	processExecutionResultObjStructureObj.subActivityId=subActivityId;
	processExecutionResultObjStructureObj.checksum=checksum;

	if(status==true){
		strcpy(processExecutionResultObjStructureObj.status,"SUCCESS");
		LOG4CPLUS_INFO(ProcessExecutionResultClient_cpp, "ProcessExecutionResult - SUCCESS");	
		}
	else if(status==false){
		strcpy(processExecutionResultObjStructureObj.status,"FALSE");
		LOG4CPLUS_ERROR(ProcessExecutionResultClient_cpp, "ProcessExecutionResult - FALSE");
		}
	else if(status==UnSuccessfulReturnValue){
		strcpy(processExecutionResultObjStructureObj.status,"ABORT");	
		LOG4CPLUS_ERROR(ProcessExecutionResultClient_cpp, "ProcessExecutionResult - ABORT");
		}
	
	try{
	LOG4CPLUS_INFO(ProcessExecutionResultClient_cpp, "getProcessExecutionJSON - getting called");
	ProcessExecutionJSONPtr=getProcessExecutionJSON(processExecutionResultObjStructureObj);
	LOG4CPLUS_INFO(ProcessExecutionResultClient_cpp, "getProcessExecutionJSON - OVER");
	if(strcmp(EncryptDecryptSignal,"on")==0)
	ProcessExecutionJSONPtr = encryption(ProcessExecutionJSONPtr);
	LOG4CPLUS_INFO(ProcessExecutionResultClient_cpp, "getProcessExecutionJSON, Encryption- OVER");
	}catch(...){failure=true;LOG4CPLUS_FATAL(ProcessExecutionResultClient_cpp, "Unable To Create getProcessExecution Request JSON");}
	if(failure==false){
	std::string requestString (ProcessExecutionJSONPtr);	

	ns1__processExecutionResultObj.request=&requestString;

	try{
	if(soap_call___ns1__processExecutionResult(soapObj,NULL, NULL, &ns1__processExecutionResultObj, &ns1__processExecutionResultResponseObj) == SOAP_OK){
	soap_call___ns1__processExecutionResultStatus=true;
	}else{
	soap_call___ns1__processExecutionResultStatus=false;
	memset(msgBuffer,false,sizeof(msgBuffer));
    soap_sprint_fault(soapObj, msgBuffer, StandardBuffer);
	msgBuffer[sizeof(msgBuffer) - 1] = '\0';
	LOG4CPLUS_ERROR(ProcessExecutionResultClient_cpp,msgBuffer);
	
	try{
	soap_end(soapObj);
	soap_free(soapObj);
	}catch(...){ LOG4CPLUS_ERROR(ProcessExecutionResultClient_cpp, "**** ERROR in dleting pointer soapObj ****");}
	
	}//else
	}catch(...){LOG4CPLUS_ERROR(ProcessExecutionResultClient_cpp, "processExecutionResultWS - FAILS"); soap_call___ns1__processExecutionResultStatus=false;}
	
	if(soap_call___ns1__processExecutionResultStatus==true){

		// responseJSON=*ns1__processExecutionResultResponseObj.return_;
		// // printf("ns1__processExecutionResultClient.cpp, Response string is:");
		// // cout <<  responseJSON << endl;

	}else{
	LOG4CPLUS_ERROR(ProcessExecutionResultClient_cpp, "********* processExecutionResultWS FAILS ***********");
	}//else
	
	try{
	if(soapObj!=NULL)
	free(soapObj);
	if(ProcessExecutionJSONPtr!=NULL)
	free(ProcessExecutionJSONPtr);
	}catch(...){ LOG4CPLUS_ERROR(ProcessExecutionResultClient_cpp, "**** ERROR in dleting pointer ProcessExecutionJSONPtr & soapObj ****"); }
	
	}//if

}
