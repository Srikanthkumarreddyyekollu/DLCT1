
#ifndef DlctNotification_H
#define DlctNotification_H

extern int notifu_count;

#endif