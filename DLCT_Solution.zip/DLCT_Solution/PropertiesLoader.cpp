#include "stdafx.h"
#include <stdlib.h>


using namespace std;
int	UnSuccessfulReturnValue=-1;
int	StandardBuffSize=1024; 
char BlockUsbRegistryUsbCommand[buffSizePropertiesNameFromPropertiesFile];
char UnBlockUsbRegistryUsbCommand[buffSizePropertiesNameFromPropertiesFile];
char BLOCKCDROM[buffSizePropertiesNameFromPropertiesFile];
char UNBLOCKCDROM[buffSizePropertiesNameFromPropertiesFile];
char SoapURL[StandardBuffer];
char FtpExecutable[StandardBuffer];
char FirewallDirectory[StandardBuffer];
char FtpDirectory[StandardBuffer];
char ConfigDirectory[StandardBuffer];
char LogsDirectory[StandardBuffer];
char FireWallRulesFile[StandardBuffer];
char DeviceRulesFile[StandardBuffer];
char RegisteredInfoFile[StandardBuffer];
char LogPropertiesFile[StandardBuffer];
char FirewallExecutable[StandardBuffer];
char NotificationDirectory[StandardBuffer];
char NotificationExecutable[StandardBuffer];
char NotificationSignal[StandardBuffer];
char EncryptDecryptSignal[StandardBuffer];
char EncryptDecryptPublicKey[StandardBuffer];
char EncryptDecryptPrivateKey[StandardBuffer];
char bufferE1[StandardBuffer];
char bufferE2[StandardBuffer];
int RegisterInterval;
int FirewallCheckDelay;
int FirewallCheckCount;
int	counter=false;

//char * getCurrentDirectory();
string getExecutablePath();

void loadProperties(){

	Logger PropertiesLoader_cpp =  Logger::getInstance("PropertiesLoader.cpp");
	LOG4CPLUS_INFO(PropertiesLoader_cpp, "Starting Function loadProperties()");
	FILE *filePointer;
	//structure for reading file content , Properties name should not be more then 50 char{}
	struct readfile{
		//char numericValue[buffSizePropertiesNameFromPropertiesFile];
		char numericValue[5000];
		char variable[buffSizePropertiesNameFromPropertiesFile];
	}fileRead;

	char lineRead[5000];
	//char lineRead[buffSizePropertiesNameFromPropertiesFile];
	char *pointer,*encryptionPointer;
	int length=0,i1=0;
	int numberOfValuesInLine=0;
	char configPath[StandardBuffer];
	string currentDirectoryPath;

	//getExecutablePath() : C:\DLCT_kula\DLCT_CODE\Release;
	currentDirectoryPath=getExecutablePath();
 	strcpy(configPath, currentDirectoryPath.c_str());
	strcat(configPath,"\\VCR.txt");	
	filePointer = fopen(configPath, "r");	//Open VCR.txt configuration file

	if (filePointer == NULL)  //check if it is not NULL
	{
	char buffer[StandardBuffer]="Going to kill Process EXE because File doesn't exist-";
	strcat(buffer,configPath);
	LOG4CPLUS_FATAL(PropertiesLoader_cpp, buffer);
	exit(false);
	}//if
	counter=false;

	// while(fgets(lineRead,buffSizePropertiesNameFromPropertiesFile,filePointer)!=NULL){
	while(fgets(lineRead,5000,filePointer)!=NULL){
		counter++;
		numberOfValuesInLine=0;

		pointer=strtok(lineRead,"=");  //strtok() for separate token when '='

		memset(fileRead.variable,NULL,buffSizePropertiesNameFromPropertiesFile);
		memset(fileRead.numericValue,NULL,buffSizePropertiesNameFromPropertiesFile);
		
		while(pointer!=NULL)
		{
			numberOfValuesInLine++;
			if(numberOfValuesInLine==1){
				strcpy(fileRead.variable,pointer);
			}else if(numberOfValuesInLine==2){
				strcpy(fileRead.numericValue,pointer);
			}
			pointer=strtok(NULL,"=");
		}
		if(numberOfValuesInLine!=2){
			// TO-DO: print error 
		}

		if(strcmp(fileRead.variable,"BlockUsbRegistryUsbCommand")==false){
			memset(BlockUsbRegistryUsbCommand,'\0',sizeof(BlockUsbRegistryUsbCommand));
			strcpy(BlockUsbRegistryUsbCommand,fileRead.numericValue);
			length=strlen(BlockUsbRegistryUsbCommand);
			BlockUsbRegistryUsbCommand[length-1]='\0';//To avoide extra new line characters.
			counter--;
		}else if(strcmp(fileRead.variable,"UnBlockUsbRegistryUsbCommand")==false){
			memset(UnBlockUsbRegistryUsbCommand,'\0',sizeof(UnBlockUsbRegistryUsbCommand));
			strcpy(UnBlockUsbRegistryUsbCommand,fileRead.numericValue);
			length=strlen(UnBlockUsbRegistryUsbCommand);
			UnBlockUsbRegistryUsbCommand[length-1]='\0';//To avoide extra new line characters.
			counter--;
		}else if(strcmp(fileRead.variable,"BLOCKCDROM")==false){
			memset(BLOCKCDROM,'\0',sizeof(BLOCKCDROM));
			strcpy(BLOCKCDROM,fileRead.numericValue);
			length=strlen(BLOCKCDROM);
			BLOCKCDROM[length-1]='\0';//To avoide extra new line characters.
			counter--;
		}else if(strcmp(fileRead.variable,"UNBLOCKCDROM")==false){
			memset(UNBLOCKCDROM,'\0',sizeof(UNBLOCKCDROM));
			strcpy(UNBLOCKCDROM,fileRead.numericValue);
			length=strlen(UNBLOCKCDROM);
			UNBLOCKCDROM[length-1]='\0';//To avoide extra new line characters.
			counter--;
		}else if(strcmp(fileRead.variable,"SoapURL")==false){
			memset(SoapURL,'\0',sizeof(SoapURL));
			strcpy(SoapURL,fileRead.numericValue);
			length=strlen(SoapURL);
			SoapURL[length-1]='\0';//To avoide extra new line characters.
			counter--;
		}else if(strcmp(fileRead.variable,"FirewallDirectory")==false){
			memset(FirewallDirectory,'\0',sizeof(FirewallDirectory));
			strcpy(FirewallDirectory,fileRead.numericValue);
			length=strlen(FirewallDirectory);
			FirewallDirectory[length-1]='\0';//To avoide extra new line characters.
			counter--;
		}else if(strcmp(fileRead.variable,"FtpDirectory")==false){
			memset(FtpDirectory,'\0',sizeof(FtpDirectory));
			strcpy(FtpDirectory,fileRead.numericValue);
			length=strlen(FtpDirectory);
			FtpDirectory[length-1]='\0';//To avoide extra new line characters.
			counter--;
		}else if(strcmp(fileRead.variable,"ConfigDirectory")==false){
			memset(ConfigDirectory,'\0',sizeof(ConfigDirectory));
			strcpy(ConfigDirectory,fileRead.numericValue);
			length=strlen(ConfigDirectory);
			ConfigDirectory[length-1]='\0';//To avoide extra new line characters.
			counter--;
		}else if(strcmp(fileRead.variable,"LogsDirectory")==false){
			memset(LogsDirectory,'\0',sizeof(LogsDirectory));
			strcpy(LogsDirectory,fileRead.numericValue);
			length=strlen(LogsDirectory);
			LogsDirectory[length-1]='\0';//To avoide extra new line characters.
			counter--;
		}else if(strcmp(fileRead.variable,"FireWallRulesFile")==false){
			memset(FireWallRulesFile,'\0',sizeof(FireWallRulesFile));
			strcpy(FireWallRulesFile,fileRead.numericValue);
			length=strlen(FireWallRulesFile);
			FireWallRulesFile[length-1]='\0';//To avoide extra new line characters.
			counter--;
		}else if(strcmp(fileRead.variable,"DeviceRulesFile")==false){
			memset(DeviceRulesFile,'\0',sizeof(DeviceRulesFile));
			strcpy(DeviceRulesFile,fileRead.numericValue);
			length=strlen(DeviceRulesFile);
			DeviceRulesFile[length-1]='\0';//To avoide extra new line characters.
			counter--;
		}else if(strcmp(fileRead.variable,"RegisteredInfoFile")==false){
			memset(RegisteredInfoFile,'\0',sizeof(RegisteredInfoFile));
			strcpy(RegisteredInfoFile,fileRead.numericValue);
			length=strlen(RegisteredInfoFile);
			RegisteredInfoFile[length-1]='\0';//To avoide extra new line characters.
			counter--;
		}else if(strcmp(fileRead.variable,"LogPropertiesFile")==false){
			memset(LogPropertiesFile,'\0',sizeof(LogPropertiesFile));
			strcpy(LogPropertiesFile,fileRead.numericValue);
			length=strlen(LogPropertiesFile);
			LogPropertiesFile[length-1]='\0';//To avoide extra new line characters.
			counter--;
		}else if(strcmp(fileRead.variable,"FtpExecutable")==false){
			memset(FtpExecutable,'\0',sizeof(FtpExecutable));
			strcpy(FtpExecutable,fileRead.numericValue);
			length=strlen(FtpExecutable);
			FtpExecutable[length-1]='\0';//To avoide extra new line characters.
			counter--;
		}else if(strcmp(fileRead.variable,"FirewallExecutable")==false){
			memset(FirewallExecutable,'\0',sizeof(FirewallExecutable));
			strcpy(FirewallExecutable,fileRead.numericValue);
			length=strlen(FirewallExecutable);
			FirewallExecutable[length-1]='\0';//To avoide extra new line characters.
			counter--;
		}else if(strcmp(fileRead.variable,"NotificationDirectory")==false){
			memset(NotificationDirectory,'\0',sizeof(NotificationDirectory));
			strcpy(NotificationDirectory,fileRead.numericValue);
			length=strlen(NotificationDirectory);
			NotificationDirectory[length-1]='\0';//To avoide extra new line characters.
			counter--;
		}
		else if (strcmp(fileRead.variable, "NotificationExecutable") == false){
			memset(NotificationExecutable, '\0', sizeof(NotificationExecutable));
			strcpy(NotificationExecutable, fileRead.numericValue);
			length = strlen(NotificationExecutable);
			NotificationExecutable[length - 1] = '\0';//To avoide extra new line characters.
			counter--;
		}else if(strcmp(fileRead.variable,"NotificationSignal")==false){
			memset(NotificationSignal,'\0',sizeof(NotificationSignal));
			strcpy(NotificationSignal,fileRead.numericValue);
			length=strlen(NotificationSignal);
			NotificationSignal[length-1]='\0';//To avoide extra new line characters.
			counter--;
		}else if(strcmp(fileRead.variable,"EncryptDecryptSignal")==false){
			memset(EncryptDecryptSignal,'\0',sizeof(EncryptDecryptSignal));
			strcpy(EncryptDecryptSignal,fileRead.numericValue);
			length=strlen(EncryptDecryptSignal);
			EncryptDecryptSignal[length-1]='\0';//To avoide extra new line characters.
			counter--;
		}else if(strcmp(fileRead.variable,"EncryptDecryptPublicKey")==false){
			memset(EncryptDecryptPublicKey,'\0',sizeof(EncryptDecryptPublicKey));
			strcpy(EncryptDecryptPublicKey,fileRead.numericValue);
			length=strlen(EncryptDecryptPublicKey);
			EncryptDecryptPublicKey[length-1]='\0';//To avoide extra new line characters.
			counter--;
			

			i1=0;
			encryptionPointer=strtok(EncryptDecryptPublicKey,",");
			while(encryptionPointer!=NULL){
			//if(i1==0){
			strcpy(bufferE1,encryptionPointer);
			//printf("String values is:%s\n",bufferE1);

			//}
			//strcat(bufferE1,encryptionPointer);
			//i1++;
			encryptionPointer=strtok(NULL,",");
			}//while
			
		}else if(strcmp(fileRead.variable,"EncryptDecryptPrivateKey")==false){
			memset(EncryptDecryptPrivateKey,'\0',sizeof(EncryptDecryptPrivateKey));
			strcpy(EncryptDecryptPrivateKey,fileRead.numericValue);
			length=strlen(EncryptDecryptPrivateKey);
			EncryptDecryptPrivateKey[length-1]='\0';//To avoide extra new line characters.
			counter--;	
			
			

			encryptionPointer=strtok(EncryptDecryptPrivateKey,", ");
			while(encryptionPointer!=NULL){
			strcpy(bufferE2,encryptionPointer);
			encryptionPointer=strtok(NULL,", ");
			}//while
			
		}else if(strcmp(fileRead.variable,"RegisterInterval")==false){
			RegisterInterval=atoi(fileRead.numericValue);
			counter--;
		}else if(strcmp(fileRead.variable,"FirewallCheckDelay")==false){
			FirewallCheckDelay=atoi(fileRead.numericValue);
			counter--;
		}else if(strcmp(fileRead.variable,"FirewallCheckCount")==false){
			FirewallCheckCount=atoi(fileRead.numericValue);
			counter--;
		}//else if
	}//while

	//printf("properties are: UnSuccessfulReturnValue:%d , StandardBuffSize:%d , NotificationExecutable:%s , NotificationSignal:%s , SoapURL:%s , FirewallDirectory:%s , FtpDirectory:%s, ConfigDirectory:%s and NotificationDirectory:%s\n",UnSuccessfulReturnValue,StandardBuffSize,NotificationExecutable,NotificationSignal,SoapURL,FirewallDirectory,FtpDirectory,ConfigDirectory,NotificationDirectory);
	//printf("counter value is:%d ,UnSuccessfulReturnValue:%d,StandardBuffSize:%d\n",counter,UnSuccessfulReturnValue,StandardBuffSize);




	if ( counter!=false )
	{
		char buffer[StandardBuffer]="Unable To Parse Property File-";
		strcat(buffer,configPath);
		LOG4CPLUS_FATAL(PropertiesLoader_cpp, buffer);
		exit (false);
	}//if

	fclose(filePointer);
	
	LOG4CPLUS_INFO(PropertiesLoader_cpp, "End Function loadProperties()");
	
}
