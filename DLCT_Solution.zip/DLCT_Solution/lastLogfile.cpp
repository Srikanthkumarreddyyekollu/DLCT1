#include "stdafx.h"
#include <iostream>

void ShowNotification(char fileCopy[260]);
void notificationCall(char fileCopy[260]);
using namespace std;
void lastLogfile(void *param)
{
	Logger lastLogfile_cpp = Logger::getInstance("lastLogfile.cpp");
	LOG4CPLUS_INFO(lastLogfile_cpp, "Starting Function last log file()");

	WIN32_FIND_DATAW ffd;
	wchar_t const* directory = L"C:\\Windows\\security\\logs"; //D:\\My_GRB_Files\\ C:\Windows\security\logs
	wchar_t currentFile[MAX_PATH], lastModifiedFilename[MAX_PATH];
	FILETIME currentModifiedTime, lastModified;
	HANDLE hFile;
	bool first_file = true;

	HANDLE hFind = FindFirstFileW(L"C:\\Windows\\security\\logs\\DLCT*.log", &ffd); //"D:\\My_GRB_Files\\*.grb2"
	//DLCT*.log: only DLCT generated log file will be catched 
	//FindFirstFileW() will look up the last modified files in directory 
	memset(currentFile, '\0', MAX_PATH);

	if (INVALID_HANDLE_VALUE == hFind)
	{
		LOG4CPLUS_ERROR(lastLogfile_cpp, "\nerror in DLCT log file handle ");
		return;
	}

	do
	{
		if (!(ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
		{
			wcscpy_s(currentFile, directory);
			wcscat_s(currentFile, ffd.cFileName);
			// open file to read it's last modified time
			hFile = CreateFileW(currentFile, GENERIC_READ, FILE_SHARE_READ, NULL,
				OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
			if (INVALID_HANDLE_VALUE != hFile)
			{
				// get it's last write time
				if (GetFileTime(hFile, NULL, NULL, &currentModifiedTime) != 0)
				{
					if (first_file)
					{
						lastModified = currentModifiedTime;
						wcscpy_s(lastModifiedFilename, ffd.cFileName);
						first_file = false;
					}
					else
					{
						// First file time is earlier than second file time.
						if (CompareFileTime(&lastModified, &currentModifiedTime) == -1)
						{
							lastModified = currentModifiedTime;
							wcscpy_s(lastModifiedFilename, ffd.cFileName);
						}
					}
				}
				CloseHandle(hFile);
			}
		}
	} while (FindNextFileW(hFind, &ffd) != 0);

	FindClose(hFind);

	//------------------------------------------------------------------------------------------------------------------------
	LOG4CPLUS_INFO(lastLogfile_cpp, "DLCT last modified log file " << ffd.cFileName);
	char fileCopy[260];
	char DefChar = ' ';
	WideCharToMultiByte(CP_ACP, 0, ffd.cFileName, -1, fileCopy, 260, &DefChar, NULL);

	string ss(fileCopy);

	LOG4CPLUS_INFO(lastLogfile_cpp, "ShowNotification() going to called.");

	//ShowNotification(fileCopy); //call showNotification () 
	notificationCall(fileCopy);
	//Sleep(1000);
	//while end

}

void notificationCall(char fileCopy[260])
{
	ShowNotification(fileCopy);
	notificationCall(fileCopy);
}