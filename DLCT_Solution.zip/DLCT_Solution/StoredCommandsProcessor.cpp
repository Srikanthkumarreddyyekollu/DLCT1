#include "stdafx.h"
#include <stdio.h>

extern char FireWallRulesFile[StandardBuffer];
extern char DeviceRulesFile[StandardBuffer];
extern char ConfigDirectory[StandardBuffer];
extern char FirewallDirectory[StandardBuffer];
extern char FirewallExecutable[StandardBuffer];
extern char BlockUsbRegistryUsbCommand[buffSizePropertiesNameFromPropertiesFile];
extern char UnBlockUsbRegistryUsbCommand[buffSizePropertiesNameFromPropertiesFile];
extern char BLOCKCDROM[buffSizePropertiesNameFromPropertiesFile];
extern char UNBLOCKCDROM[buffSizePropertiesNameFromPropertiesFile];

std::string exec(char* cmd);
using namespace std;
void runCommands(char *pointerFileName,char action[StandardBuffer]){

	char rulesToBeRun[StandardBuffer];
	char fileNameBuffer[StandardBuffer];
	memset(fileNameBuffer,'0',sizeof(fileNameBuffer));
	strcpy(fileNameBuffer,ConfigDirectory);
	strcat(fileNameBuffer,"\\");
	strcat(fileNameBuffer,pointerFileName);
	FILE *file = fopen ( fileNameBuffer, "r" );
	Logger StoredCommandsProcessor_cpp =  Logger::getInstance("StoredCommandsProcessor.cpp");

	if ( file != NULL )
	{
		char line [ StandardBuffer ]; 

		while ( fgets ( line, sizeof line, file ) != NULL ) /* read a line */
		{

			for(int i=false; line[i]!='\0' ;i++)
				line[i]=line[i+true];
			int length=strlen(line);
			line[length-2]='\0';

			memset(rulesToBeRun,0,sizeof(rulesToBeRun));
			if(strcmp(action,"firewall")==false){
				strcpy(rulesToBeRun,FirewallDirectory);
				strcat(rulesToBeRun,"\\");
				strcat(rulesToBeRun,FirewallExecutable);
				strcat(rulesToBeRun," ");
				strcat(rulesToBeRun,line);
			}else if(strcmp(action,"device")==false){//Need to improve
				strcpy(rulesToBeRun,line);
				if( strcmp(rulesToBeRun,"BLOCKUSB") == 0 ){
				//cout << "HERE- BLOCKUSB" << endl;
				memset(rulesToBeRun,0,sizeof(rulesToBeRun));
				strcpy(rulesToBeRun,BlockUsbRegistryUsbCommand);
				//cout << "HERE- BLOCKUSB" << rulesToBeRun << endl;
				/*
				cout << "HERE- BLOCKUSB" << endl;
				//char *cmd=BlockUsbRegistryUsbCommand;
				std::string puttyAvilabilityResult=exec(BlockUsbRegistryUsbCommand);
				if (puttyAvilabilityResult.compare("\0")==0){
				cout << "FailURE- BLOCKUSB" << endl;
				}else{
				cout << "HEY: SUCCESS- BLOCKUSB" << endl;
				}*/
				}else if( strcmp(rulesToBeRun,"UNBLOCKUSB") == 0 ){
				//cout << "HERE- UNBLOCKUSB" << endl;
				memset(rulesToBeRun,0,sizeof(rulesToBeRun));
				strcpy(rulesToBeRun,UnBlockUsbRegistryUsbCommand);
				//cout << "HERE- UNBLOCKUSB" << rulesToBeRun << endl;
				/*
				std::string puttyAvilabilityResult = exec(UnBlockUsbRegistryUsbCommand);
				if (puttyAvilabilityResult.compare("\0")==0){
				cout << "FailURE- UNBLOCKUSB" << endl;
				}else{
				cout << "HEY: SUCCESS- UNBLOCKUSB" << endl;
				}*/
		
				}else if( strcmp(rulesToBeRun,"BLOCKCDROM") == 0 ){
				//cout << "HERE- BLOCKCDROM" << endl;
				memset(rulesToBeRun,0,sizeof(rulesToBeRun));
				strcpy(rulesToBeRun,BLOCKCDROM);
				//cout << "HERE- BLOCKCDROM" << rulesToBeRun << endl;
		
				}else if( strcmp(rulesToBeRun,"UNBLOCKCDROM") == 0 ){
				//cout << "HERE- UNBLOCKCDROM" << endl;
				memset(rulesToBeRun,0,sizeof(rulesToBeRun));
				strcpy(rulesToBeRun,UNBLOCKCDROM);
				//cout << "HERE- UNBLOCKCDROM" << rulesToBeRun << endl;
				}
			}
			try{
			system(rulesToBeRun);
			}catch(...){LOG4CPLUS_ERROR(StoredCommandsProcessor_cpp,"Exception Caught, Unable to run STORED commands, May be problem with ipfw PATH");}
		}
		if ( file != NULL )
			fclose ( file );
	}
	else
	{
	char fileBuffer[StandardBuffer];
	memset(fileBuffer,'\0',sizeof(fileBuffer));
	strcpy(fileBuffer,"No Stored Commands Found To Execute in- ");
	strcat(fileBuffer,fileNameBuffer);
	LOG4CPLUS_WARN(StoredCommandsProcessor_cpp,fileBuffer);
		//perror ( fileNameBuffer ); /* why didn't the file open? */
	}
	try{
	if(pointerFileName!=NULL)
	free(pointerFileName);
	}catch(...) { LOG4CPLUS_ERROR(StoredCommandsProcessor_cpp,"Deleting Pointer pointerFileName- Problem"); }
}

	//==========================================================================================================
	//runStoredCommands()
	void runStoredCommands(){
	char firewallAction[StandardBuffer]="firewall";
	char deviceAction[StandardBuffer]="device";
	runCommands(FireWallRulesFile,firewallAction);
	runCommands(DeviceRulesFile,deviceAction);
	}//runStoredCommands()