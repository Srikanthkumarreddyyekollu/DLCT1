struct systemPropertiesStruct{
char *ipAddress;
char *machineName;
char *cuid;
///////////////long port;
};
typedef struct systemPropertiesStruct systemPropertiesStructure;
