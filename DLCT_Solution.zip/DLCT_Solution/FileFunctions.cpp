/*#include "stdafx.h"
#include <stdio.h>
#include <direct.h>
#include <windows.h>
#include "Structures.h"
#include "commandLinkedList.h"
extern char ConfigDirectory[StandardBuffer];
extern char FirewallDirectory[StandardBuffer];
extern char FireWallRulesFile[StandardBuffer];
extern char DeviceRulesFile[StandardBuffer];
extern char FirewallExecutable[StandardBuffer];
extern int	UnSuccessfulReturnValue;
extern char BlockUsbRegistryUsbCommand[buffSizePropertiesNameFromPropertiesFile];
extern char UnBlockUsbRegistryUsbCommand[buffSizePropertiesNameFromPropertiesFile];
extern char BLOCKCDROM[buffSizePropertiesNameFromPropertiesFile];
extern char UNBLOCKCDROM[buffSizePropertiesNameFromPropertiesFile];

std::string exec(char* cmd);
//bool appendCommandToFile(char *pointerToFileName);
using namespace std;
Logger FileFunction_cpp =  Logger::getInstance("FileFunction.cpp");
commandHandler *curr, *head=NULL, *monitoring=NULL, *tempCommandHandler=NULL; //commandLinkedList.h

const char *receivedBuffer;
///////////////////////////////////////////////////////////////////////////
char * getCurrentDirectory(){
	char* holdDirctoryPathbuffer;
	try{
	holdDirctoryPathbuffer= "NULL";
	if( ( holdDirctoryPathbuffer = _getcwd(NULL, false)) != NULL ){
		// TO-DO: print success
	}else{
		// TO-DO: print error 
		free(holdDirctoryPathbuffer);
		throw "Unable To Find Path --- TBD";
	}
	}
	catch(char *strg){
	LOG4CPLUS_WARN(FileFunction_cpp, strg);
					}
	return holdDirctoryPathbuffer;
}

	/////////////////////////////////////////////////////////////////////////////////
	//getExecutablePath()
	string getExecutablePath() {
	TCHAR tCharBuffer[StandardBuffer];
	char  charBuffer[StandardBuffer];
	memset(charBuffer,NULL,StandardBuffer);
	GetModuleFileName( NULL, tCharBuffer, StandardBuffer );
	for(int i=false; tCharBuffer[i]!=false; i++) {
	charBuffer[i]=tCharBuffer[i];
	}
	string::size_type pos = string( charBuffer ).find_last_of( "\\/" );
	return string( charBuffer ).substr( 0, pos);
}	
	////////////////////////////////////////////////////////////////////////////////
	//runFirewallCommand()
	int runFirewallCommand(char *firewallCommad){
	char firewallCommandBuff[StandardBuffer];
	int returnValue;
	memset(firewallCommandBuff,0,sizeof(firewallCommandBuff));
	strcpy(firewallCommandBuff,FirewallDirectory);
	strcat(firewallCommandBuff,"\\");
	strcat(firewallCommandBuff,FirewallExecutable);
	strcat(firewallCommandBuff," ");
	strcat(firewallCommandBuff,firewallCommad);
	try{
	returnValue=system(firewallCommandBuff);
	}catch(...){LOG4CPLUS_FATAL(FileFunction_cpp,"runFirewallCommand(), fails, Unable to run firewallcommand");
				int returnValue=UnSuccessfulReturnValue;
				}
	try{
	if(firewallCommad!=NULL)
	free(firewallCommad);
	}catch(...){ LOG4CPLUS_ERROR(FileFunction_cpp,"Deleting Pointer- Problem"); }
	return returnValue;
	}
	//////////////////////////////////////////////////////////////////////////////////
	//runDeviceCommand()
	int runDeviceCommand(char *tempDeviceCommandBuff){
	char deviceCommandBuff[StandardBuffer];
	int returnValue=true;
	memset(deviceCommandBuff,0,sizeof(deviceCommandBuff));
	strcpy(deviceCommandBuff,tempDeviceCommandBuff);

	if( strcmp(deviceCommandBuff,"BLOCKUSB") == 0 ){
	//char *cmd=BlockUsbRegistryUsbCommand;
	memset(deviceCommandBuff,0,sizeof(deviceCommandBuff));
	strcpy(deviceCommandBuff,BlockUsbRegistryUsbCommand);
		// /*std::string puttyAvilabilityResult=exec(BlockUsbRegistryUsbCommand);
		// if (puttyAvilabilityResult.compare("\0")==0){
		// cout << "FailURE- BLOCKUSB" << endl;
		// }else{
		// returnValue=false;
		// cout << "HEY: SUCCESS- BLOCKUSB" << endl;
		// }
	}else if( strcmp(deviceCommandBuff,"UNBLOCKUSB") == 0 ){
	memset(deviceCommandBuff,0,sizeof(deviceCommandBuff));
	strcpy(deviceCommandBuff,UnBlockUsbRegistryUsbCommand);
		// /*std::string puttyAvilabilityResult = exec(UnBlockUsbRegistryUsbCommand);
		// if (puttyAvilabilityResult.compare("\0")==0){
		// cout << "FailURE- UNBLOCKUSB" << endl;
		// }else{
		// returnValue=false;
		// cout << "HEY: SUCCESS- UNBLOCKUSB" << endl;
		// }
	
	}else if( strcmp(deviceCommandBuff,"BLOCKCDROM") == 0 ){
	memset(deviceCommandBuff,0,sizeof(deviceCommandBuff));
	strcpy(deviceCommandBuff,BLOCKCDROM);
	
	}else if( strcmp(deviceCommandBuff,"UNBLOCKCDROM") == 0 ){
	memset(deviceCommandBuff,0,sizeof(deviceCommandBuff));
	strcpy(deviceCommandBuff,UNBLOCKCDROM);
	}
	
	try{
	returnValue=system(deviceCommandBuff);
	cout << "Received Device Commad is:::::::: "  <<  returnValue << endl;	
	//returnValue=system(deviceCommandBuff);
	}catch(...){LOG4CPLUS_FATAL(FileFunction_cpp,"runDeviceCommand(), fails, to run device commands");
				int returnValue=UnSuccessfulReturnValue;
				}
	try{
	if(tempDeviceCommandBuff!=NULL)
	free(tempDeviceCommandBuff);
	}catch(...){ LOG4CPLUS_ERROR(FileFunction_cpp,"Deleting Pointer- Problem"); }
	return returnValue;
	}

	/////////////////////////////////////////////////////////////////////////////////////
	//firewallCommandsTesting()
	int firewallCommandsTesting(std::string pointerToReceivedBuff){	

	try{
	int returnValue=UnSuccessfulReturnValue;
	char tempFirewallCommandBuff[StandardBuffer];
	receivedBuffer = pointerToReceivedBuff.c_str();
	
	curr = (commandHandler *)malloc(sizeof(commandHandler));	
	strcpy(curr->command,receivedBuffer);
	curr->next = NULL;
	if(head==NULL){
	head=curr;
	monitoring=curr;
	}else{
	monitoring->next=curr;
	monitoring=curr;
	}

	memset(tempFirewallCommandBuff,0,sizeof(tempFirewallCommandBuff));
	sprintf(tempFirewallCommandBuff,"%s",receivedBuffer);
	for(int i=0; tempFirewallCommandBuff[i]!='\0' ;i++)
	tempFirewallCommandBuff[i]=tempFirewallCommandBuff[i+1];
	int length=strlen(tempFirewallCommandBuff);
	tempFirewallCommandBuff[length-1]='\0';
	
	//runFirewallCommand
	returnValue=runFirewallCommand(tempFirewallCommandBuff);
	//monitoring=NULL; curr=NULL;//WRONG
	return returnValue;
	}catch(...){LOG4CPLUS_FATAL(FileFunction_cpp,"firewallCommandsTesting(), fails, May be no permission to write to file at this directory");
				int returnValue=UnSuccessfulReturnValue;
				//monitoring=NULL; curr=NULL;//WRONG
				return returnValue;
				}
	}
	// ///////////////////////////////////////////////////////////////////////////////////////
	// //deviceCommandsTesting()
// /*	int deviceCommandsTesting(std::string pointerToReceivedBuff){	

	// int returnValue;
	// char DeviceCommandFileNameBuff[StandardBuffer];
	// char tempDeviceCommandBuff[StandardBuffer];
	// memset(DeviceCommandFileNameBuff,'\0',sizeof(DeviceCommandFileNameBuff));
	// strcpy(DeviceCommandFileNameBuff,ConfigDirectory);
	// strcat(DeviceCommandFileNameBuff,"\\temp");
	// strcat(DeviceCommandFileNameBuff,DeviceRulesFile);
	// receivedBuffer = pointerToReceivedBuff.c_str();
	// FILE *filePointer = fopen(DeviceCommandFileNameBuff, "a");
		// if(filePointer==NULL){
		// LOG4CPLUS_FATAL(FileFunction_cpp,"deviceCommandsTesting(), fails, Unable to open a source file");
		// returnValue=UnSuccessfulReturnValue;

		// return returnValue;
		// }
	// fprintf(filePointer, "%s\n", receivedBuffer);
	// fclose(filePointer);

	// memset(tempDeviceCommandBuff,0,sizeof(tempDeviceCommandBuff));
	// sprintf(tempDeviceCommandBuff,"%s",receivedBuffer);
	// for(int i=false; tempDeviceCommandBuff[i]!='\0' ;i++)
	// tempDeviceCommandBuff[i]=tempDeviceCommandBuff[i+1];
	// int length=strlen(tempDeviceCommandBuff);
	// tempDeviceCommandBuff[length-1]='\0';
	
	// //runDeviceCommand
	// returnValue=runDeviceCommand(tempDeviceCommandBuff);

	// return returnValue;
// }	
	int deviceCommandsTesting(std::string pointerToReceivedBuff){	
	try{
	int returnValue=UnSuccessfulReturnValue;
	char tempDeviceCommandBuff[StandardBuffer];
	receivedBuffer = pointerToReceivedBuff.c_str();
	
	curr = (commandHandler *)malloc(sizeof(commandHandler));	
	strcpy(curr->command,receivedBuffer);
	curr->next = NULL;
	if(head==NULL){
	head=curr;
	monitoring=curr;
	}else{
	monitoring->next=curr;
	monitoring=curr;
	}

	memset(tempDeviceCommandBuff,0,sizeof(tempDeviceCommandBuff));
	sprintf(tempDeviceCommandBuff,"%s",receivedBuffer);
	for(int i=0; tempDeviceCommandBuff[i]!='\0' ;i++)
	tempDeviceCommandBuff[i]=tempDeviceCommandBuff[i+1];
	int length=strlen(tempDeviceCommandBuff);
	tempDeviceCommandBuff[length-1]='\0';
	// /*int length=strlen(tempDeviceCommandBuff);
	// tempDeviceCommandBuff[length]='\0';
	
	//runFirewallCommand
	returnValue=runDeviceCommand(tempDeviceCommandBuff);
	//monitoring=NULL; curr=NULL;//WRONG
	return returnValue;
	}catch(...){LOG4CPLUS_FATAL(FileFunction_cpp,"firewallCommandsTesting(), fails, May be no permission to write to file at this directory");
				int returnValue=UnSuccessfulReturnValue;

				return returnValue;
				}
	}
// char *cmd=BlockUsbRegistryUsbCommand;
// std::string puttyAvilabilityResult=exec(cmd);
// if (puttyAvilabilityResult.compare("\0")==0){
		// cout << "Unable to find Putty Avilability, No file will be process" << endl;
		// }else{
		// cout << "HEY: " << puttyAvilabilityResult << endl;
		// cout << "Unable to find Putty Avilability, No fffffffffffile will be process" << endl;
		// }
// ///////////////////////////////////////////////////////////////////////////////////////
// /*
// bool appendCommandToFile(char *pointerToFileName){
	
	// int status=true;
	// char sourceFileNameBuffer[StandardBuffer];
	// char destFileNameBuffer[StandardBuffer];
	// char charFromFile;
	// char tempCommandBuffer[StandardBuffer];
	// memset(sourceFileNameBuffer,'\0',sizeof(sourceFileNameBuffer));
	// strcpy(sourceFileNameBuffer,ConfigDirectory);
	// strcat(sourceFileNameBuffer,"\\temp");
	// strcat(sourceFileNameBuffer,pointerToFileName);
	// FILE *sourceFile = fopen ( sourceFileNameBuffer, "r" );
	// if(sourceFile==NULL){
		// //printf("CommandsToFile.cpp cannot open %s",sourceFile);
		// LOG4CPLUS_FATAL(FileFunction_cpp,"appendCommandToFile(), fails, Unable to open a source file");
		// status=false;
	// }

	// memset(destFileNameBuffer,'0',sizeof(destFileNameBuffer));
	// strcpy(destFileNameBuffer,ConfigDirectory);
	// strcat(destFileNameBuffer,"\\");
	// strcat(destFileNameBuffer,pointerToFileName);
	// //printf("CommandsToFile.cpp file to be open:%s\n",destFileNameBuffer);
	// FILE *destFile = fopen ( destFileNameBuffer, "a" );
	// if(destFile==NULL){
		// //printf("CommandsToFile.cpp cannot open %s",destFile);
		// LOG4CPLUS_FATAL(FileFunction_cpp,"appendCommandToFile(), fails, Unable to open a destination file");
		// status=false;
	// }

	// if( sourceFile!=NULL && destFile!=NULL ){
		// while((charFromFile=getc(sourceFile))!=EOF)
			// putc(charFromFile,destFile); 
	// }

	// if(sourceFile!=NULL)
		// fclose(sourceFile);

	// if(destFile!=NULL)
		// fclose(destFile);

	// memset(tempCommandBuffer,'0',sizeof(tempCommandBuffer));
	// strcpy(tempCommandBuffer,"DEL ");
	// strcat(tempCommandBuffer,ConfigDirectory);
	// strcat(tempCommandBuffer,"\\temp");
	// strcat(tempCommandBuffer,pointerToFileName);
	// try{
	// system(tempCommandBuffer);
	// }catch(...){ LOG4CPLUS_FATAL(FileFunction_cpp,"appendCommandToFile(), fails, May be no permission to DELETE file at this directory"); }

	// return status;
// }

//////////////////////////////////////////////////////////////////////////////////////////////
	//writeCommandsTOFile()
	int writeCommandsTOFile(char *fileNamePointer, int type){

	char tempCommandBuffer[StandardBuffer];
	int returnStatus=true;
	static bool firewallInitialEntry=false;
	static bool deviceInitialEntry=false;
	extern char FireWallRulesFile[StandardBuffer];
	extern char DeviceRulesFile[StandardBuffer];

	if( (firewallInitialEntry==false && type ==false) || (deviceInitialEntry==false && type ==true) ){
	
			if(type==false)
			firewallInitialEntry=true;
			if(type==true)
			deviceInitialEntry=true;
			
		memset(tempCommandBuffer,'0',sizeof(tempCommandBuffer));
		strcpy(tempCommandBuffer,"DEL ");
		strcat(tempCommandBuffer,ConfigDirectory);
		strcat(tempCommandBuffer,"\\");
		strcat(tempCommandBuffer,fileNamePointer);
		try{
		system(tempCommandBuffer);
		}catch(...){ LOG4CPLUS_FATAL(FileFunction_cpp,"writeCommandsTOFile(), fails, May be no permission to DELETE file at this directory"); 
		try{
		if(fileNamePointer!=NULL)
		free(fileNamePointer);
		}catch(...){ LOG4CPLUS_ERROR(FileFunction_cpp,"Deleting Pointer- Problem"); }
		returnStatus=false;
		return returnStatus;}
		
		memset(tempCommandBuffer,'0',sizeof(tempCommandBuffer));
		strcpy(tempCommandBuffer,ConfigDirectory);
		strcat(tempCommandBuffer,"\\");
		strcat(tempCommandBuffer,fileNamePointer);

		FILE *filePointer = fopen ( tempCommandBuffer, "w" );
			if(filePointer==NULL){
			//printf("CommandsToFile.cpp cannot open %s",destFile);
			LOG4CPLUS_FATAL(FileFunction_cpp,"writeCommandsTOFile(), fails, Unable to open a destination file");
			returnStatus=false;
			try{
			if(fileNamePointer!=NULL)
			free(fileNamePointer);
			}catch(...){ LOG4CPLUS_ERROR(FileFunction_cpp,"Deleting Pointer- Problem"); }
			return returnStatus;
			}
		
			tempCommandHandler=head;
			while(tempCommandHandler!=NULL)
				{
				try{
				fprintf(filePointer,"%s\n",tempCommandHandler->command);
				}catch(...){ LOG4CPLUS_FATAL(FileFunction_cpp,"writeCommandsTOFile(), fails, May be no permission to write in to firewall file"); returnStatus=false; 
				try{
				if(fileNamePointer!=NULL)
				free(fileNamePointer);
				}catch(...) { LOG4CPLUS_ERROR(FileFunction_cpp,"Deleting Pointer- Problem");}
				return returnStatus; }
				tempCommandHandler=tempCommandHandler->next;
				}
				if(filePointer!=NULL)
				fclose(filePointer);
				
	}else{
	
		memset(tempCommandBuffer,'0',sizeof(tempCommandBuffer));
		strcpy(tempCommandBuffer,ConfigDirectory);
		strcat(tempCommandBuffer,"\\");
		strcat(tempCommandBuffer,fileNamePointer);
		FILE *filePointer = fopen ( tempCommandBuffer, "a" );
		if(filePointer==NULL){
			LOG4CPLUS_FATAL(FileFunction_cpp,"writeCommandsTOFile(), fails, Unable to open a destination file for appanding commands");
			returnStatus==false;
			try{
			if(fileNamePointer!=NULL)
			free(fileNamePointer);
			}catch(...){ LOG4CPLUS_ERROR(FileFunction_cpp,"Deleting Pointer- Problem"); }
			return returnStatus;
			}
		
			tempCommandHandler=head;
			while(tempCommandHandler!=NULL)
				{
				fprintf(filePointer,"%s\n",tempCommandHandler->command);
				tempCommandHandler=tempCommandHandler->next;
				}
				if(filePointer!=NULL)
				fclose(filePointer);
	
	}
		try{
		if(fileNamePointer!=NULL)
		free(fileNamePointer);
		}catch(...){ LOG4CPLUS_ERROR(FileFunction_cpp,"Deleting Pointer- Problem"); }
		tempCommandHandler=NULL;
	return returnStatus;
	
}
*/

#include "stdafx.h"
#include <stdio.h>
#include <direct.h>
#include <windows.h>
#include "Structures.h"
#include "commandLinkedList.h"
extern char ConfigDirectory[StandardBuffer];

extern char FireWallRulesFile[StandardBuffer];
extern char DeviceRulesFile[StandardBuffer];

extern int	UnSuccessfulReturnValue;

//bool appendCommandToFile(char *pointerToFileName);
using namespace std;
Logger FileFunction_cpp =  Logger::getInstance("FileFunction.cpp");
extern commandHandler *head;


///////////////////////////////////////////////////////////////////////////
char * getCurrentDirectory(){
	char* holdDirctoryPathbuffer;
	try{
	holdDirctoryPathbuffer= "NULL";
	if( ( holdDirctoryPathbuffer = _getcwd(NULL, false)) != NULL ){
		// TO-DO: print success
	}else{
		// TO-DO: print error 
		free(holdDirctoryPathbuffer);
		throw "Unable To Find Path --- TBD";
	}
	}
	catch(char *strg){
	LOG4CPLUS_WARN(FileFunction_cpp, strg);
					}
	return holdDirctoryPathbuffer;
}

	/////////////////////////////////////////////////////////////////////////////////
	//getExecutablePath()
	string getExecutablePath() {
	TCHAR tCharBuffer[StandardBuffer];
	char  charBuffer[StandardBuffer];
	memset(charBuffer,NULL,StandardBuffer);
	GetModuleFileName( NULL, tCharBuffer, StandardBuffer );
	for(int i=false; tCharBuffer[i]!=false; i++) {
	charBuffer[i]=tCharBuffer[i];
	}
	string::size_type pos = string( charBuffer ).find_last_of( "\\/" );
	return string( charBuffer ).substr( 0, pos);
}	
	////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////
	//writeCommandsTOFile()
	int writeCommandsTOFile(char *fileNamePointer, int type){
	commandHandler *tempCommandHandler=NULL; //commandLinkedList.h
	char tempCommandBuffer[StandardBuffer];
	int returnStatus=true;
	static bool firewallInitialEntry=false;
	static bool deviceInitialEntry=false;
	extern char FireWallRulesFile[StandardBuffer];
	extern char DeviceRulesFile[StandardBuffer];

	if( (firewallInitialEntry==false && type ==false) || (deviceInitialEntry==false && type ==true) ){
	
			if(type==false)
			firewallInitialEntry=true;
			if(type==true)
			deviceInitialEntry=true;
			
		memset(tempCommandBuffer,'0',sizeof(tempCommandBuffer));
		strcpy(tempCommandBuffer,"DEL ");
		strcat(tempCommandBuffer,ConfigDirectory);
		strcat(tempCommandBuffer,"\\");
		strcat(tempCommandBuffer,fileNamePointer);
		try{
		system(tempCommandBuffer);
		}catch(...){ LOG4CPLUS_FATAL(FileFunction_cpp,"writeCommandsTOFile(), fails, May be no permission to DELETE file at this directory"); 
		try{
		if(fileNamePointer!=NULL)
		free(fileNamePointer);
		}catch(...){ /*LOG4CPLUS_ERROR(FileFunction_cpp,"Deleting Pointer- Problem"); */}
		returnStatus=false;
		return returnStatus;}
		
		memset(tempCommandBuffer,'0',sizeof(tempCommandBuffer));
		strcpy(tempCommandBuffer,ConfigDirectory);
		strcat(tempCommandBuffer,"\\");
		strcat(tempCommandBuffer,fileNamePointer);

		FILE *filePointer = fopen ( tempCommandBuffer, "w" );
			if(filePointer==NULL){
			//printf("CommandsToFile.cpp cannot open %s",destFile);
			LOG4CPLUS_FATAL(FileFunction_cpp,"writeCommandsTOFile(), fails, Unable to open a destination file");
			returnStatus=false;
			try{
			if(fileNamePointer!=NULL)
			free(fileNamePointer);
			}catch(...){ /*LOG4CPLUS_ERROR(FileFunction_cpp,"Deleting Pointer- Problem");*/ }
			return returnStatus;
			}
		
			tempCommandHandler=head;
			while(tempCommandHandler!=NULL)
				{
				try{
				fprintf(filePointer,"%s\n",tempCommandHandler->command);
				}catch(...){ LOG4CPLUS_FATAL(FileFunction_cpp,"writeCommandsTOFile(), fails, May be no permission to write in to firewall file"); returnStatus=false; 
				try{
				if(fileNamePointer!=NULL)
				free(fileNamePointer);
				}catch(...) { /*LOG4CPLUS_ERROR(FileFunction_cpp,"Deleting Pointer- Problem");*/}
				return returnStatus; }
				tempCommandHandler=tempCommandHandler->next;
				}
				if(filePointer!=NULL)
				fclose(filePointer);
				
	}else{
	
		memset(tempCommandBuffer,'0',sizeof(tempCommandBuffer));
		strcpy(tempCommandBuffer,ConfigDirectory);
		strcat(tempCommandBuffer,"\\");
		strcat(tempCommandBuffer,fileNamePointer);
		FILE *filePointer = fopen ( tempCommandBuffer, "a" );
		if(filePointer==NULL){
			LOG4CPLUS_FATAL(FileFunction_cpp,"writeCommandsTOFile(), fails, Unable to open a destination file for appanding commands");
			returnStatus==false;
			try{
			if(fileNamePointer!=NULL)
			free(fileNamePointer);
			}catch(...){ /*LOG4CPLUS_ERROR(FileFunction_cpp,"Deleting Pointer- Problem");*/ }
			return returnStatus;
			}
		
			tempCommandHandler=head;
			while(tempCommandHandler!=NULL)
				{
				fprintf(filePointer,"%s\n",tempCommandHandler->command);
				tempCommandHandler=tempCommandHandler->next;
				}
				if(filePointer!=NULL)
				fclose(filePointer);
	
	}
		try{
		if(fileNamePointer!=NULL)
		free(fileNamePointer);
		}catch(...){/* LOG4CPLUS_ERROR(FileFunction_cpp,"Deleting Pointer- Problem");*/ }
		tempCommandHandler=NULL;
	return returnStatus;
	
}