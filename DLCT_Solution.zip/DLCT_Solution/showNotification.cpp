#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <cctype>
#include <string>
#include <windows.h>
#include <process.h>
#include <ctime>

#define Buff 100 
//int count_notify = 0;
//double notify_time = 0.0;
using namespace std;
Logger ShowNotification_cpp = Logger::getInstance("ShowNotification.cpp");

void notifyCommandFunc(void *notifyParam) // notify thread -----------------------------------------------
{
	LOG4CPLUS_INFO(ShowNotification_cpp, "inside notifyCommandFunc Thread.!!");
	char *notifyStr = (char *)(notifyParam);
	system(notifyStr);
}

void getLocalTime(void * last_line_para)//getlocat time thread intialized ---------------------------------
{
	LOG4CPLUS_INFO(ShowNotification_cpp, "Enter inside getLocalTime Thread...!!");

	SYSTEMTIME lt;
	string &last_line = *(static_cast<string * >(last_line_para));
	//============================string to char conversion===================================
	char timeStamp[Buff];
	string  last_line_time = last_line.substr(11, 19); // assign time stamp value..

		int TempNumOne = last_line_time.size();


		for (int a = 0; a <= TempNumOne; a++)
		{
			timeStamp[a] = last_line_time[a];
			//cout <<a << "-" <<timeStamp[a] << "  ,"; Sleep(2000);
		}

	
	GetLocalTime(&lt);
	char localTime[Buff]; //store local time value
	sprintf_s(localTime, "%04d.%02d.%02d %02d:%02d:%02d", lt.wYear, lt.wMonth, lt.wDay, lt.wHour, lt.wMinute, lt.wSecond);

	cout << "\n\nlocalTime: " << localTime << endl;
	cout << "\ntimeStamp: " << timeStamp << endl;

	char int_timeStamp[7];


	char int_localTime[7] = { localTime[11], localTime[12], localTime[14], localTime[15], localTime[17], localTime[18], '\0' };

	if (timeStamp[0] != '-' && timeStamp[1] != '-')
	{
		int_timeStamp[0] = timeStamp[11];
		int_timeStamp[1] = timeStamp[12];
		int_timeStamp[2] = timeStamp[14];
		int_timeStamp[3] = timeStamp[15];
		int_timeStamp[4] = timeStamp[17];
		int_timeStamp[5] = timeStamp[18];

		int_timeStamp[6] = '\0';
	}

	else
	{
		cout << "\n DLCT log file end....!";
	}


	int localValue = atoi(int_localTime);
	int stampValue = atoi(int_timeStamp);


	cout << "\nlocalValue : " << localValue;
	cout << "\nstamplValue: " << stampValue;

	cout << "\n\n";
	//system("pause");

	clock_t start, end;
	
	start = clock();  // store processore time 

	if (strcmp(localTime, timeStamp) == 0 || (localValue >= stampValue && localValue <= stampValue + 3))
	{
		//count_notify++;
		
		LOG4CPLUS_INFO(ShowNotification_cpp, "See the notification right buttom of the taskbar.");
		//cout << "\nstring compare same ";

		char notifyCommand[] = "C:\\Progra~1\\DLCT\\notifu\\notifu.exe /d 3000 /i %SYSTEMROOT%\system32\shell32.dll,43 /m \"Warning: Access restricted by DLCT admin...!!!\"  /t warn";

		HANDLE notifyHnd;

			notifyHnd = (HANDLE)_beginthread(notifyCommandFunc, 0, &notifyCommand);
			WaitForSingleObject(notifyHnd, INFINITE);
	
	}
	else
	{
		Sleep(1000);
		
		LOG4CPLUS_WARN(ShowNotification_cpp, "Time compare between system time and log file time stamp NOT same, SO no notification....!");
	}

}//getLocat time thread finishied ------------------------------------------------------

void ShowNotification(char fileCopy[260])
{
	string line;
	string last_line;

	char fileTemp[Buff] = "C:\\Windows\\security\\logs\\";

	LOG4CPLUS_INFO(ShowNotification_cpp, "inside ShowNotification().");

	strcat(fileTemp, fileCopy);

	ifstream myfile(fileTemp);
	if (myfile.is_open())
	{
		while (getline(myfile, line)) {
			bool is_empty = true;
			for (int i = 0; i < line.size(); i++) {
				char ch = line[i];
				is_empty = is_empty && isspace(ch);
			}
			if (!is_empty) {
				last_line = line;
			}
		}
		myfile.close();
	}
	else {
		//cout << "Unable to open file";
		LOG4CPLUS_ERROR(ShowNotification_cpp, "unable to open last line of log file.");
	}

	LOG4CPLUS_INFO(ShowNotification_cpp, "getLocalTime thread going to be called ....!!");

	//int i = 0;
	HANDLE hnd;
	//while (i < 10)
	//{
	hnd = (HANDLE)_beginthread(getLocalTime, 0, &last_line);
	WaitForSingleObject(hnd, INFINITE);
	//i++;

	LOG4CPLUS_INFO(ShowNotification_cpp, "getLocalTime THREAD finished");

}