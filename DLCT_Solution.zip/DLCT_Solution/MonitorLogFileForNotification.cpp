#include "stdafx.h"
#include <Windows.h>

extern char LogsDirectory[StandardBuffer];
void RefreshDirectory(LPTSTR);
void RefreshTree(LPTSTR);
void MonitorProcess();
void ProcessMonitoring();;
void WatchDirectory(LPTSTR);
extern char NotificationDirectory[StandardBuffer];
extern char NotificationExecutable[StandardBuffer];
extern char NotificationSignal[StandardBuffer];
char notificationCommand[StandardBuffer];
static SYSTEMTIME previousTime;//time
SYSTEMTIME currentTime;//time
TCHAR *wArr ;
DWORD dwWaitStatus;
HANDLE dwChangeHandles[2];
TCHAR lpDrive[4];
Logger MonitorLogFileForNotification_cpp =  Logger::getInstance("MonitorLogFileForNotification.cpp");
	//MonitorFileChange()
	void MonitorFileChange(void *dummy){
	char creatDir[StandardBuffer];
	char dirPath[StandardBuffer];

	memset(dirPath, false, sizeof(dirPath));
	strcpy(dirPath,LogsDirectory);
	strcat(dirPath,"\\Arc");	
	memset(creatDir,false,sizeof(creatDir));
	sprintf(creatDir,"mkdir %s" ,dirPath);
	//printf("Final Command is:%s\n",creatDir);
	int checkReturn=system(creatDir);
	//printf("Return value is:%d\n",checkReturn);
	char message[30]="\"Network Access Restricted\"";
	memset(notificationCommand, false, sizeof(notificationCommand));
	sprintf(notificationCommand,"%s\\%s /d 9000 /i " ,NotificationDirectory,NotificationExecutable);
	strcat(notificationCommand,"\%SYSTEMROOT%\system32\shell32.dll /m ");
	strcat(notificationCommand,message);
	size_t size = strlen(dirPath);
	size=size+1;
	wArr = new TCHAR[size];
	for (size_t i = 0; i < size; ++i)
    wArr[i] = dirPath[i];
	//wcout << " CHECK:" << wArr << endl;
	if(strcmp(NotificationSignal,"on")==0)
	{
	printf("Signal is ON\n");//logger can be done here
	WatchDirectory(wArr);
	}else{printf("Signal is OFF\n");}//logger can be done here
	}//MonitorFileChange()

	void WatchDirectory(LPTSTR lpDir){

	TCHAR lpFile[_MAX_FNAME];
	TCHAR lpExt[_MAX_EXT];
	_tsplitpath_s(lpDir, lpDrive, 4, NULL, 0, lpFile, _MAX_FNAME, lpExt, _MAX_EXT);

	lpDrive[2] = (TCHAR)'\\';
	lpDrive[3] = (TCHAR)'\0';

	// Watch the directory for file creation and deletion. 
	dwChangeHandles[0] = FindFirstChangeNotification(
		lpDir,                         // directory to watch 
		FALSE,                         // do not watch subtree 
		FILE_NOTIFY_CHANGE_LAST_WRITE); // watch file name changes 

	if (dwChangeHandles[0] == INVALID_HANDLE_VALUE)
	{
		printf("\n ERROR: FindFirstChangeNotification function failed.\n");
		ExitProcess(GetLastError());
	}

	// Watch the subtree for directory creation and deletion. 

	dwChangeHandles[1] = FindFirstChangeNotification(
		lpDrive,                       // directory to watch 
		TRUE,                          // watch the subtree 
		FILE_NOTIFY_CHANGE_DIR_NAME);  // watch dir name changes 

	if (dwChangeHandles[1] == INVALID_HANDLE_VALUE)
	{
		printf("\n ERROR: FindFirstChangeNotification function failed.\n");
		ExitProcess(GetLastError());
	}


	// Make a final validation check on our handles.

	if ((dwChangeHandles[0] == NULL) || (dwChangeHandles[1] == NULL))
	{
		printf("\n ERROR: Unexpected NULL from FindFirstChangeNotification.\n");
		ExitProcess(GetLastError());
	}

	// Change notification is set. Now wait on both notification 
	// handles and refresh accordingly. 
	GetSystemTime(&previousTime);//time
	MonitorProcess();
	}//WatchDirectory()

	//===============================================================================================
	//ProcessMonitoring()
	void ProcessMonitoring(){
	LOG4CPLUS_INFO(MonitorLogFileForNotification_cpp, "Notification Monitoring Thread STARTED...");
	while (TRUE){
		// Wait for notification.

		//////LOG4CPLUS_INFO(MonitorLogFileForNotification_cpp, "Waiting for notification...");
		dwWaitStatus = WaitForMultipleObjects(2, dwChangeHandles,
			FALSE, INFINITE);
			
		GetSystemTime(&currentTime);//time

		switch (dwWaitStatus)
		{
		case WAIT_OBJECT_0:

			// A file was created, renamed, or deleted in the directory.
			// Refresh this directory and restart the notification.

			RefreshDirectory(wArr);
			if (FindNextChangeNotification(dwChangeHandles[0]) == FALSE)
			{
				printf("\n ERROR: FindNextChangeNotification function failed.\n");
				ExitProcess(GetLastError());
			}
			break;

		case WAIT_OBJECT_0 + 1:

			// A directory was created, renamed, or deleted.
			// Refresh the tree and restart the notification.

			RefreshTree(lpDrive);
			if (FindNextChangeNotification(dwChangeHandles[1]) == FALSE)
			{
				printf("\n ERROR: FindNextChangeNotification function failed.\n");
				ExitProcess(GetLastError());
			}
			break;

		case WAIT_TIMEOUT:

			// A timeout occurred, this would happen if some value other 
			// than INFINITE is used in the Wait call and no changes occur.
			// In a single-threaded environment you might not want an
			// INFINITE wait.

			printf("\nNo changes in the timeout period.\n");
			break;

		default:
			printf("\n ERROR: Unhandled dwWaitStatus.\n");
			ExitProcess(GetLastError());
			break;
		}

		//Sleep(threadWait); //kula add
	}//while
	}//ProcessMonitoring()
	
	//===================================================================================================
	//MonitorProcess()
	void MonitorProcess(){
	try{
	LOG4CPLUS_INFO(MonitorLogFileForNotification_cpp, "ProcessMonitoring(), Going to be called...");
	ProcessMonitoring();
	}catch(...){LOG4CPLUS_INFO(MonitorLogFileForNotification_cpp, "ProcessMonitoring(), Caught Exceptions, Restarted process()");
	MonitorProcess();
	}
	}//MonitorProcess()


	//===================================================================================================
	//str_t.wHour,str_t.wMinute,str_t.wSecond
	//RefreshDirectory()
	void RefreshDirectory(LPTSTR lpDir){
	// This is where you might place code to refresh your
	// directory listing, but not the subtree because it
	// would not be necessary.
		/*printf("Year:%d\tMonth:%d\tDate:%d\tHour:%d\tMin:%d\tSecond:% d\t , Second:% d\t"
	,currentTime.wYear,currentTime.wMonth,currentTime.wDay
	,currentTime.wHour,currentTime.wMinute,currentTime.wSecond,currentTime.wSecond+10);
	printf("Year PREvious :%d\tMonth:%d\tDate:%d\tHour:%d\tMin:%d\tSecond:% d\t , Second:% d\t"
	,previousTime.wYear,previousTime.wMonth,previousTime.wDay
	,previousTime.wHour,previousTime.wMinute,previousTime.wSecond,previousTime.wSecond+10);*/
	if(currentTime.wHour!=previousTime.wHour || currentTime.wMinute>=previousTime.wMinute+1  || currentTime.wSecond >=(previousTime.wSecond+10))
	system(notificationCommand);

	previousTime.wHour=currentTime.wHour;
	previousTime.wMinute=currentTime.wMinute;
	previousTime.wSecond=currentTime.wSecond;
	
	_tprintf(TEXT("Directory (%s) changed.\n"), lpDir);
	}//RefreshDirectory

	//===================================================================================================
	//RefreshTree()
	void RefreshTree(LPTSTR lpDrive){
	// This is where you might place code to refresh your
	// directory listing, including the subtree.

	///_tprintf(TEXT("Directory tree (%s) changed.\n"), lpDrive);// Was Uncommented by anil
	}
