/*
Modified by Kulamani_Sethi
date: 15sept, 2017
Task: Reducing orginal DLCT log file by ~90%
Summery: Copy whole log file to another location and filter out all repeting ICMP records with a temp file.
move this temp file to server as erlier file FTPing process.
copyright ceturylink.

*/
#include "stdafx.h" 
#include <string.h>
#include <string>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <map>

char logBuffFinalCopy[StandardBuffer];
extern char search_data_cFileName[StandardBuffer];
extern char clientIdBuff[StandardBuffer];
extern char archiveDirBuff[StandardBuffer];
extern char clientIdLogBuff[StandardBuffer];
void logFileCompression(char *logfilename);
void tokenFilter(char *str, char *logfilename);
void eraseTime(char *str);
void removeDuplicateRecord(char *logfilename);
using namespace std;

/*------------------call-1 LogFileCompression()------------------------------------------------*/
void logFileCompression(char *logfilename)  //logfilename: c:\windows\security\logs\12345-dlct.log
{
	char *fileString; //catch whole file content 
	long bufsize;
	FILE *fp;

	fp = fopen(logfilename, "r");
	if (fp != NULL)
	{
		if (fseek(fp, 0L, SEEK_END) == 0)
		{
			bufsize = ftell(fp);
			if (bufsize == -1) { /* Error */ }

			fileString = (char *)malloc(sizeof(char) * (bufsize + 1));
			if (fileString == NULL) { fputs("Memory error", stderr); exit(2); }
			//store whole log file to a char* and bring over memory.

			if (fseek(fp, 0L, SEEK_SET) != 0) { /* Handle error here */ }

			/* Read the entire file into memory. */
			size_t newLen = fread(fileString, sizeof(char), bufsize, fp);


			if (newLen == 0)
				fputs("Error reading file", stderr);
			else
				fileString[newLen] = '\0'; /* Just to be safe. */
		}
		fclose(fp);
	}


	char firstLineOfLog[] = "--- begin ---"; //ignore first line (--- begin ---);
	char *temp = fileString + strlen(firstLineOfLog);
	//fileString= fileString+ strlen(firstLineOfLog);

	tokenFilter(temp, logfilename); //line by line create token
	removeDuplicateRecord(logfilename);// remove all duplicate from log file
	//cout<<fileString;
	free(fileString); //relese memory from file pointer
}


void tokenFilter(char *str, char *logfilename)
{
	ofstream out(logfilename, ios::out); //change file name;
	const char *delm = "\n";

	char* token = strtok(str, delm);
	while (token != NULL) //create a each line as a token.
	{
		eraseTime(token);
		out << token;
		//cout<<token; 
		token = strtok(NULL, delm);
	}
	out.close();
}

void eraseTime(char *str)
{
	/*
	erase second part of timestamp (mm:sec:msec)
	*/
	int beg = 21, end = 34; //(21-34) time slice should be removed
	while (str[end])//shift copy backward still reach '\0' chara
	{
		str[beg] = str[end];//copy char by char 
		beg++; end++;
	}
	str[beg] = '\n'; str[++beg] = '\0';

}


/*remove duplicate from file nif any.
Here, i am using STL map for this task.
*/
void removeDuplicateRecord(char* logfilename)
{
	try{
		fstream myfile;
		myfile.open(logfilename, ios::in);
		fstream outfile;

		//add*

		memset(logBuffFinalCopy, false, sizeof(logBuffFinalCopy));
		strcat(logBuffFinalCopy, archiveDirBuff);
		strcat(logBuffFinalCopy, "\\");
		strcat(logBuffFinalCopy, clientIdLogBuff);  //duplog 123-aa.log
		
		//outfile.open("out_dlct_final.log",ios::out|ios::app); //append
		outfile.open(logBuffFinalCopy, ios::out); //over write
		map<string, int> mymap;
		string cur;
		while (getline(myfile, cur)){
			if (mymap[cur] == NULL){
				mymap[cur] = 1;
				outfile.write(cur.c_str(), cur.length());
				outfile.put('\n');
			}
			else
				mymap[cur]++;
		}
		outfile.close();
		myfile.close();
	}
	catch (ios_base::failure& e)
	{
		cerr << e.what() << endl;
	}
//	char delFile[] = "del out_dlct.log"; //delete temp log file.
//	system(delFile);
}


