//
// sproxy.exe generated file
// do not modify this file
//
// Created: 02/17/2014@14:23:40
//

#pragma once


#if !defined(_WIN32_WINDOWS) && !defined(_WIN32_WINNT) && !defined(_WIN32_WCE)
#pragma message("warning: defining _WIN32_WINDOWS = 0x0410")
#define _WIN32_WINDOWS 0x0410
#endif

#include <atlsoap.h>

namespace services
{

struct processDataResponse
{
	BSTR ___return;
};

struct processSubsequent
{
	BSTR request;
};

struct processInitial
{
	BSTR request;
};

struct processData
{
	BSTR request;
};

struct processSubsequentResponse
{
	BSTR ___return;
};

struct processPulseResponse
{
	BSTR ___return;
};

struct processPulse
{
	BSTR request;
};

struct processInitialResponse
{
	BSTR ___return;
};

template <typename TClient = CSoapSocketClientT<> >
class CservicesT : 
	public TClient, 
	public CSoapRootHandler
{
protected:

	const _soapmap ** GetFunctionMap();
	const _soapmap ** GetHeaderMap();
	void * GetHeaderValue();
	const wchar_t * GetNamespaceUri();
	const char * GetServiceName();
	const char * GetNamespaceUriA();
	HRESULT CallFunction(
		void *pvParam, 
		const wchar_t *wszLocalName, int cchLocalName,
		size_t nItem);
	HRESULT GetClientReader(ISAXXMLReader **ppReader);

public:

	HRESULT __stdcall QueryInterface(REFIID riid, void **ppv)
	{
		if (ppv == NULL)
		{
			return E_POINTER;
		}

		*ppv = NULL;

		if (InlineIsEqualGUID(riid, IID_IUnknown) ||
			InlineIsEqualGUID(riid, IID_ISAXContentHandler))
		{
			*ppv = static_cast<ISAXContentHandler *>(this);
			return S_OK;
		}

		return E_NOINTERFACE;
	}

	ULONG __stdcall AddRef()
	{
		return 1;
	}

	ULONG __stdcall Release()
	{
		return 1;
	}

	CservicesT(ISAXXMLReader *pReader = NULL)
		:TClient(_T("http://10.140.3.63:8080/DLCT/services/VCRClientService"))
	{
		SetClient(true);
		SetReader(pReader);
	}
	
	~CservicesT()
	{
		Uninitialize();
	}
	
	void Uninitialize()
	{
		UninitializeSOAP();
	}	

	HRESULT _processSubsequent(
		processSubsequent _processSubsequent0, 
		processSubsequentResponse* _processSubsequentResponse
	);

	HRESULT _processInitial(
		processInitial _processInitial1, 
		processInitialResponse* _processInitialResponse
	);

	HRESULT _processPulse(
		processPulse _processPulse2, 
		processPulseResponse* _processPulseResponse
	);

	HRESULT _processData(
		processData _processData3, 
		processDataResponse* _processDataResponse
	);
};

typedef CservicesT<> Cservices;

__if_not_exists(__processDataResponse_entries)
{
extern __declspec(selectany) const _soapmapentry __processDataResponse_entries[] =
{
	{ 
		0x11515F60, 
		"return", 
		L"return", 
		sizeof("return")-1, 
		SOAPTYPE_STRING, 
		SOAPFLAG_FIELD | SOAPFLAG_NULLABLE, 
		offsetof(processDataResponse, ___return),
		NULL, 
		NULL, 
		-1 
	},
	{ 0x00000000 }
};

extern __declspec(selectany) const _soapmap __processDataResponse_map =
{
	0x1C18FAE8,
	"processDataResponse",
	L"processDataResponse",
	sizeof("processDataResponse")-1,
	sizeof("processDataResponse")-1,
	SOAPMAP_STRUCT,
	__processDataResponse_entries,
	sizeof(processDataResponse),
	1,
	-1,
	SOAPFLAG_NONE,
	0x05276BEB,
	"http://localhost/VCRClientService",
	L"http://localhost/VCRClientService",
	sizeof("http://localhost/VCRClientService")-1
};
}

__if_not_exists(__processSubsequent_entries)
{
extern __declspec(selectany) const _soapmapentry __processSubsequent_entries[] =
{
	{ 
		0x3B46CBA9, 
		"request", 
		L"request", 
		sizeof("request")-1, 
		SOAPTYPE_STRING, 
		SOAPFLAG_FIELD | SOAPFLAG_NULLABLE, 
		offsetof(processSubsequent, request),
		NULL, 
		NULL, 
		-1 
	},
	{ 0x00000000 }
};

extern __declspec(selectany) const _soapmap __processSubsequent_map =
{
	0x2104F64E,
	"processSubsequent",
	L"processSubsequent",
	sizeof("processSubsequent")-1,
	sizeof("processSubsequent")-1,
	SOAPMAP_STRUCT,
	__processSubsequent_entries,
	sizeof(processSubsequent),
	1,
	-1,
	SOAPFLAG_NONE,
	0x05276BEB,
	"http://localhost/VCRClientService",
	L"http://localhost/VCRClientService",
	sizeof("http://localhost/VCRClientService")-1
};
}

__if_not_exists(__processInitial_entries)
{
extern __declspec(selectany) const _soapmapentry __processInitial_entries[] =
{
	{ 
		0x3B46CBA9, 
		"request", 
		L"request", 
		sizeof("request")-1, 
		SOAPTYPE_STRING, 
		SOAPFLAG_FIELD | SOAPFLAG_NULLABLE, 
		offsetof(processInitial, request),
		NULL, 
		NULL, 
		-1 
	},
	{ 0x00000000 }
};

extern __declspec(selectany) const _soapmap __processInitial_map =
{
	0x1A0FEA49,
	"processInitial",
	L"processInitial",
	sizeof("processInitial")-1,
	sizeof("processInitial")-1,
	SOAPMAP_STRUCT,
	__processInitial_entries,
	sizeof(processInitial),
	1,
	-1,
	SOAPFLAG_NONE,
	0x05276BEB,
	"http://localhost/VCRClientService",
	L"http://localhost/VCRClientService",
	sizeof("http://localhost/VCRClientService")-1
};
}

__if_not_exists(__processData_entries)
{
extern __declspec(selectany) const _soapmapentry __processData_entries[] =
{
	{ 
		0x3B46CBA9, 
		"request", 
		L"request", 
		sizeof("request")-1, 
		SOAPTYPE_STRING, 
		SOAPFLAG_FIELD | SOAPFLAG_NULLABLE, 
		offsetof(processData, request),
		NULL, 
		NULL, 
		-1 
	},
	{ 0x00000000 }
};

extern __declspec(selectany) const _soapmap __processData_map =
{
	0x77F16FB9,
	"processData",
	L"processData",
	sizeof("processData")-1,
	sizeof("processData")-1,
	SOAPMAP_STRUCT,
	__processData_entries,
	sizeof(processData),
	1,
	-1,
	SOAPFLAG_NONE,
	0x05276BEB,
	"http://localhost/VCRClientService",
	L"http://localhost/VCRClientService",
	sizeof("http://localhost/VCRClientService")-1
};
}

__if_not_exists(__processSubsequentResponse_entries)
{
extern __declspec(selectany) const _soapmapentry __processSubsequentResponse_entries[] =
{
	{ 
		0x11515F60, 
		"return", 
		L"return", 
		sizeof("return")-1, 
		SOAPTYPE_STRING, 
		SOAPFLAG_FIELD | SOAPFLAG_NULLABLE, 
		offsetof(processSubsequentResponse, ___return),
		NULL, 
		NULL, 
		-1 
	},
	{ 0x00000000 }
};

extern __declspec(selectany) const _soapmap __processSubsequentResponse_map =
{
	0x17C0467D,
	"processSubsequentResponse",
	L"processSubsequentResponse",
	sizeof("processSubsequentResponse")-1,
	sizeof("processSubsequentResponse")-1,
	SOAPMAP_STRUCT,
	__processSubsequentResponse_entries,
	sizeof(processSubsequentResponse),
	1,
	-1,
	SOAPFLAG_NONE,
	0x05276BEB,
	"http://localhost/VCRClientService",
	L"http://localhost/VCRClientService",
	sizeof("http://localhost/VCRClientService")-1
};
}

__if_not_exists(__processPulseResponse_entries)
{
extern __declspec(selectany) const _soapmapentry __processPulseResponse_entries[] =
{
	{ 
		0x11515F60, 
		"return", 
		L"return", 
		sizeof("return")-1, 
		SOAPTYPE_STRING, 
		SOAPFLAG_FIELD | SOAPFLAG_NULLABLE, 
		offsetof(processPulseResponse, ___return),
		NULL, 
		NULL, 
		-1 
	},
	{ 0x00000000 }
};

extern __declspec(selectany) const _soapmap __processPulseResponse_map =
{
	0x3644EF57,
	"processPulseResponse",
	L"processPulseResponse",
	sizeof("processPulseResponse")-1,
	sizeof("processPulseResponse")-1,
	SOAPMAP_STRUCT,
	__processPulseResponse_entries,
	sizeof(processPulseResponse),
	1,
	-1,
	SOAPFLAG_NONE,
	0x05276BEB,
	"http://localhost/VCRClientService",
	L"http://localhost/VCRClientService",
	sizeof("http://localhost/VCRClientService")-1
};
}

__if_not_exists(__processPulse_entries)
{
extern __declspec(selectany) const _soapmapentry __processPulse_entries[] =
{
	{ 
		0x3B46CBA9, 
		"request", 
		L"request", 
		sizeof("request")-1, 
		SOAPTYPE_STRING, 
		SOAPFLAG_FIELD | SOAPFLAG_NULLABLE, 
		offsetof(processPulse, request),
		NULL, 
		NULL, 
		-1 
	},
	{ 0x00000000 }
};

extern __declspec(selectany) const _soapmap __processPulse_map =
{
	0x77036528,
	"processPulse",
	L"processPulse",
	sizeof("processPulse")-1,
	sizeof("processPulse")-1,
	SOAPMAP_STRUCT,
	__processPulse_entries,
	sizeof(processPulse),
	1,
	-1,
	SOAPFLAG_NONE,
	0x05276BEB,
	"http://localhost/VCRClientService",
	L"http://localhost/VCRClientService",
	sizeof("http://localhost/VCRClientService")-1
};
}

__if_not_exists(__processInitialResponse_entries)
{
extern __declspec(selectany) const _soapmapentry __processInitialResponse_entries[] =
{
	{ 
		0x11515F60, 
		"return", 
		L"return", 
		sizeof("return")-1, 
		SOAPTYPE_STRING, 
		SOAPFLAG_FIELD | SOAPFLAG_NULLABLE, 
		offsetof(processInitialResponse, ___return),
		NULL, 
		NULL, 
		-1 
	},
	{ 0x00000000 }
};

extern __declspec(selectany) const _soapmap __processInitialResponse_map =
{
	0xD0110578,
	"processInitialResponse",
	L"processInitialResponse",
	sizeof("processInitialResponse")-1,
	sizeof("processInitialResponse")-1,
	SOAPMAP_STRUCT,
	__processInitialResponse_entries,
	sizeof(processInitialResponse),
	1,
	-1,
	SOAPFLAG_NONE,
	0x05276BEB,
	"http://localhost/VCRClientService",
	L"http://localhost/VCRClientService",
	sizeof("http://localhost/VCRClientService")-1
};
}

struct __Cservices__processSubsequent_struct
{
	processSubsequent _processSubsequent0;
	processSubsequentResponse _processSubsequentResponse;
};

extern __declspec(selectany) const _soapmapentry __Cservices__processSubsequent_entries[] =
{

	{
		0x2104F64E, 
		"processSubsequent", 
		L"processSubsequent", 
		sizeof("processSubsequent")-1, 
		SOAPTYPE_UNK, 
		SOAPFLAG_NONE | SOAPFLAG_IN | SOAPFLAG_PID | SOAPFLAG_DOCUMENT | SOAPFLAG_LITERAL,
		offsetof(__Cservices__processSubsequent_struct, _processSubsequent0),
		NULL,
		&__processSubsequent_map,
		-1,
	},
	{
		0x17C0467D, 
		"processSubsequentResponse", 
		L"processSubsequentResponse", 
		sizeof("processSubsequentResponse")-1, 
		SOAPTYPE_UNK, 
		SOAPFLAG_NONE | SOAPFLAG_OUT | SOAPFLAG_PID | SOAPFLAG_DOCUMENT | SOAPFLAG_LITERAL,
		offsetof(__Cservices__processSubsequent_struct, _processSubsequentResponse),
		NULL,
		&__processSubsequentResponse_map,
		-1,
	},
	{ 0x00000000 }
};

extern __declspec(selectany) const _soapmap __Cservices__processSubsequent_map =
{
	0x17C0467D,
	"processSubsequent",
	L"processSubsequentResponse",
	sizeof("processSubsequent")-1,
	sizeof("processSubsequentResponse")-1,
	SOAPMAP_FUNC,
	__Cservices__processSubsequent_entries,
	sizeof(__Cservices__processSubsequent_struct),
	1,
	-1,
	SOAPFLAG_NONE | SOAPFLAG_PID | SOAPFLAG_DOCUMENT | SOAPFLAG_LITERAL,
	0x05276BEB,
	"http://localhost/VCRClientService",
	L"http://localhost/VCRClientService",
	sizeof("http://localhost/VCRClientService")-1
};


struct __Cservices__processInitial_struct
{
	processInitial _processInitial1;
	processInitialResponse _processInitialResponse;
};

extern __declspec(selectany) const _soapmapentry __Cservices__processInitial_entries[] =
{

	{
		0x1A0FEA49, 
		"processInitial", 
		L"processInitial", 
		sizeof("processInitial")-1, 
		SOAPTYPE_UNK, 
		SOAPFLAG_NONE | SOAPFLAG_IN | SOAPFLAG_PID | SOAPFLAG_DOCUMENT | SOAPFLAG_LITERAL,
		offsetof(__Cservices__processInitial_struct, _processInitial1),
		NULL,
		&__processInitial_map,
		-1,
	},
	{
		0xD0110578, 
		"processInitialResponse", 
		L"processInitialResponse", 
		sizeof("processInitialResponse")-1, 
		SOAPTYPE_UNK, 
		SOAPFLAG_NONE | SOAPFLAG_OUT | SOAPFLAG_PID | SOAPFLAG_DOCUMENT | SOAPFLAG_LITERAL,
		offsetof(__Cservices__processInitial_struct, _processInitialResponse),
		NULL,
		&__processInitialResponse_map,
		-1,
	},
	{ 0x00000000 }
};

extern __declspec(selectany) const _soapmap __Cservices__processInitial_map =
{
	0xD0110578,
	"processInitial",
	L"processInitialResponse",
	sizeof("processInitial")-1,
	sizeof("processInitialResponse")-1,
	SOAPMAP_FUNC,
	__Cservices__processInitial_entries,
	sizeof(__Cservices__processInitial_struct),
	1,
	-1,
	SOAPFLAG_NONE | SOAPFLAG_PID | SOAPFLAG_DOCUMENT | SOAPFLAG_LITERAL,
	0x05276BEB,
	"http://localhost/VCRClientService",
	L"http://localhost/VCRClientService",
	sizeof("http://localhost/VCRClientService")-1
};


struct __Cservices__processPulse_struct
{
	processPulse _processPulse2;
	processPulseResponse _processPulseResponse;
};

extern __declspec(selectany) const _soapmapentry __Cservices__processPulse_entries[] =
{

	{
		0x77036528, 
		"processPulse", 
		L"processPulse", 
		sizeof("processPulse")-1, 
		SOAPTYPE_UNK, 
		SOAPFLAG_NONE | SOAPFLAG_IN | SOAPFLAG_PID | SOAPFLAG_DOCUMENT | SOAPFLAG_LITERAL,
		offsetof(__Cservices__processPulse_struct, _processPulse2),
		NULL,
		&__processPulse_map,
		-1,
	},
	{
		0x3644EF57, 
		"processPulseResponse", 
		L"processPulseResponse", 
		sizeof("processPulseResponse")-1, 
		SOAPTYPE_UNK, 
		SOAPFLAG_NONE | SOAPFLAG_OUT | SOAPFLAG_PID | SOAPFLAG_DOCUMENT | SOAPFLAG_LITERAL,
		offsetof(__Cservices__processPulse_struct, _processPulseResponse),
		NULL,
		&__processPulseResponse_map,
		-1,
	},
	{ 0x00000000 }
};

extern __declspec(selectany) const _soapmap __Cservices__processPulse_map =
{
	0x3644EF57,
	"processPulse",
	L"processPulseResponse",
	sizeof("processPulse")-1,
	sizeof("processPulseResponse")-1,
	SOAPMAP_FUNC,
	__Cservices__processPulse_entries,
	sizeof(__Cservices__processPulse_struct),
	1,
	-1,
	SOAPFLAG_NONE | SOAPFLAG_PID | SOAPFLAG_DOCUMENT | SOAPFLAG_LITERAL,
	0x05276BEB,
	"http://localhost/VCRClientService",
	L"http://localhost/VCRClientService",
	sizeof("http://localhost/VCRClientService")-1
};


struct __Cservices__processData_struct
{
	processData _processData3;
	processDataResponse _processDataResponse;
};

extern __declspec(selectany) const _soapmapentry __Cservices__processData_entries[] =
{

	{
		0x77F16FB9, 
		"processData", 
		L"processData", 
		sizeof("processData")-1, 
		SOAPTYPE_UNK, 
		SOAPFLAG_NONE | SOAPFLAG_IN | SOAPFLAG_PID | SOAPFLAG_DOCUMENT | SOAPFLAG_LITERAL,
		offsetof(__Cservices__processData_struct, _processData3),
		NULL,
		&__processData_map,
		-1,
	},
	{
		0x1C18FAE8, 
		"processDataResponse", 
		L"processDataResponse", 
		sizeof("processDataResponse")-1, 
		SOAPTYPE_UNK, 
		SOAPFLAG_NONE | SOAPFLAG_OUT | SOAPFLAG_PID | SOAPFLAG_DOCUMENT | SOAPFLAG_LITERAL,
		offsetof(__Cservices__processData_struct, _processDataResponse),
		NULL,
		&__processDataResponse_map,
		-1,
	},
	{ 0x00000000 }
};

extern __declspec(selectany) const _soapmap __Cservices__processData_map =
{
	0x1C18FAE8,
	"processData",
	L"processDataResponse",
	sizeof("processData")-1,
	sizeof("processDataResponse")-1,
	SOAPMAP_FUNC,
	__Cservices__processData_entries,
	sizeof(__Cservices__processData_struct),
	1,
	-1,
	SOAPFLAG_NONE | SOAPFLAG_PID | SOAPFLAG_DOCUMENT | SOAPFLAG_LITERAL,
	0x05276BEB,
	"http://localhost/VCRClientService",
	L"http://localhost/VCRClientService",
	sizeof("http://localhost/VCRClientService")-1
};

extern __declspec(selectany) const _soapmap * __Cservices_funcs[] =
{
	&__Cservices__processSubsequent_map,
	&__Cservices__processInitial_map,
	&__Cservices__processPulse_map,
	&__Cservices__processData_map,
	NULL
};

template <typename TClient>
inline HRESULT CservicesT<TClient>::_processSubsequent(
		processSubsequent _processSubsequent0, 
		processSubsequentResponse* _processSubsequentResponse
	)
{
    if ( _processSubsequentResponse == NULL )
		return E_POINTER;

	HRESULT __atlsoap_hr = InitializeSOAP(NULL);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_INITIALIZE_ERROR);
		return __atlsoap_hr;
	}
	
	CleanupClient();

	CComPtr<IStream> __atlsoap_spReadStream;
	__Cservices__processSubsequent_struct __params;
	memset(&__params, 0x00, sizeof(__params));
	__params._processSubsequent0 = _processSubsequent0;

	__atlsoap_hr = SetClientStruct(&__params, 0);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_OUTOFMEMORY);
		goto __skip_cleanup;
	}
	
	__atlsoap_hr = GenerateResponse(GetWriteStream());
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_GENERATE_ERROR);
		goto __skip_cleanup;
	}
	
	__atlsoap_hr = SendRequest(_T("SOAPAction: \"\"\r\n"));
	if (FAILED(__atlsoap_hr))
	{
		goto __skip_cleanup;
	}
	__atlsoap_hr = GetReadStream(&__atlsoap_spReadStream);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_READ_ERROR);
		goto __skip_cleanup;
	}
	
	// cleanup any in/out-params and out-headers from previous calls
	Cleanup();
	__atlsoap_hr = BeginParse(__atlsoap_spReadStream);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_PARSE_ERROR);
		goto __cleanup;
	}

	*_processSubsequentResponse = __params._processSubsequentResponse;
	goto __skip_cleanup;
	
__cleanup:
	Cleanup();
__skip_cleanup:
	ResetClientState(true);
	memset(&__params, 0x00, sizeof(__params));
	return __atlsoap_hr;
}

template <typename TClient>
inline HRESULT CservicesT<TClient>::_processInitial(
		processInitial _processInitial1, 
		processInitialResponse* _processInitialResponse
	)
{
    if ( _processInitialResponse == NULL )
		return E_POINTER;

	HRESULT __atlsoap_hr = InitializeSOAP(NULL);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_INITIALIZE_ERROR);
		return __atlsoap_hr;
	}
	
	CleanupClient();

	CComPtr<IStream> __atlsoap_spReadStream;
	__Cservices__processInitial_struct __params;
	memset(&__params, 0x00, sizeof(__params));
	__params._processInitial1 = _processInitial1;

	__atlsoap_hr = SetClientStruct(&__params, 1);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_OUTOFMEMORY);
		goto __skip_cleanup;
	}
	
	__atlsoap_hr = GenerateResponse(GetWriteStream());
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_GENERATE_ERROR);
		goto __skip_cleanup;
	}
	
	__atlsoap_hr = SendRequest(_T("SOAPAction: \"\"\r\n"));
	if (FAILED(__atlsoap_hr))
	{
		goto __skip_cleanup;
	}
	__atlsoap_hr = GetReadStream(&__atlsoap_spReadStream);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_READ_ERROR);
		goto __skip_cleanup;
	}
	
	// cleanup any in/out-params and out-headers from previous calls
	Cleanup();
	__atlsoap_hr = BeginParse(__atlsoap_spReadStream);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_PARSE_ERROR);
		goto __cleanup;
	}

	*_processInitialResponse = __params._processInitialResponse;
	goto __skip_cleanup;
	
__cleanup:
	Cleanup();
__skip_cleanup:
	ResetClientState(true);
	memset(&__params, 0x00, sizeof(__params));
	return __atlsoap_hr;
}

template <typename TClient>
inline HRESULT CservicesT<TClient>::_processPulse(
		processPulse _processPulse2, 
		processPulseResponse* _processPulseResponse
	)
{
    if ( _processPulseResponse == NULL )
		return E_POINTER;

	HRESULT __atlsoap_hr = InitializeSOAP(NULL);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_INITIALIZE_ERROR);
		return __atlsoap_hr;
	}
	
	CleanupClient();

	CComPtr<IStream> __atlsoap_spReadStream;
	__Cservices__processPulse_struct __params;
	memset(&__params, 0x00, sizeof(__params));
	__params._processPulse2 = _processPulse2;

	__atlsoap_hr = SetClientStruct(&__params, 2);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_OUTOFMEMORY);
		goto __skip_cleanup;
	}
	
	__atlsoap_hr = GenerateResponse(GetWriteStream());
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_GENERATE_ERROR);
		goto __skip_cleanup;
	}
	
	__atlsoap_hr = SendRequest(_T("SOAPAction: \"\"\r\n"));
	if (FAILED(__atlsoap_hr))
	{
		goto __skip_cleanup;
	}
	__atlsoap_hr = GetReadStream(&__atlsoap_spReadStream);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_READ_ERROR);
		goto __skip_cleanup;
	}
	
	// cleanup any in/out-params and out-headers from previous calls
	Cleanup();
	__atlsoap_hr = BeginParse(__atlsoap_spReadStream);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_PARSE_ERROR);
		goto __cleanup;
	}

	*_processPulseResponse = __params._processPulseResponse;
	goto __skip_cleanup;
	
__cleanup:
	Cleanup();
__skip_cleanup:
	ResetClientState(true);
	memset(&__params, 0x00, sizeof(__params));
	return __atlsoap_hr;
}

template <typename TClient>
inline HRESULT CservicesT<TClient>::_processData(
		processData _processData3, 
		processDataResponse* _processDataResponse
	)
{
    if ( _processDataResponse == NULL )
		return E_POINTER;

	HRESULT __atlsoap_hr = InitializeSOAP(NULL);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_INITIALIZE_ERROR);
		return __atlsoap_hr;
	}
	
	CleanupClient();

	CComPtr<IStream> __atlsoap_spReadStream;
	__Cservices__processData_struct __params;
	memset(&__params, 0x00, sizeof(__params));
	__params._processData3 = _processData3;

	__atlsoap_hr = SetClientStruct(&__params, 3);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_OUTOFMEMORY);
		goto __skip_cleanup;
	}
	
	__atlsoap_hr = GenerateResponse(GetWriteStream());
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_GENERATE_ERROR);
		goto __skip_cleanup;
	}
	
	__atlsoap_hr = SendRequest(_T("SOAPAction: \"\"\r\n"));
	if (FAILED(__atlsoap_hr))
	{
		goto __skip_cleanup;
	}
	__atlsoap_hr = GetReadStream(&__atlsoap_spReadStream);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_READ_ERROR);
		goto __skip_cleanup;
	}
	
	// cleanup any in/out-params and out-headers from previous calls
	Cleanup();
	__atlsoap_hr = BeginParse(__atlsoap_spReadStream);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_PARSE_ERROR);
		goto __cleanup;
	}

	*_processDataResponse = __params._processDataResponse;
	goto __skip_cleanup;
	
__cleanup:
	Cleanup();
__skip_cleanup:
	ResetClientState(true);
	memset(&__params, 0x00, sizeof(__params));
	return __atlsoap_hr;
}

template <typename TClient>
ATL_NOINLINE inline const _soapmap ** CservicesT<TClient>::GetFunctionMap()
{
	return __Cservices_funcs;
}

template <typename TClient>
ATL_NOINLINE inline const _soapmap ** CservicesT<TClient>::GetHeaderMap()
{
	static const _soapmapentry __Cservices__processSubsequent_atlsoapheader_entries[] =
	{
		{ 0x00000000 }
	};

	static const _soapmap __Cservices__processSubsequent_atlsoapheader_map = 
	{
		0x17C0467D,
		"processSubsequent",
		L"processSubsequentResponse",
		sizeof("processSubsequent")-1,
		sizeof("processSubsequentResponse")-1,
		SOAPMAP_HEADER,
		__Cservices__processSubsequent_atlsoapheader_entries,
		0,
		0,
		-1,
		SOAPFLAG_NONE | SOAPFLAG_PID | SOAPFLAG_DOCUMENT | SOAPFLAG_LITERAL,
		0x05276BEB,
		"http://localhost/VCRClientService",
		L"http://localhost/VCRClientService",
		sizeof("http://localhost/VCRClientService")-1
	};

	static const _soapmapentry __Cservices__processInitial_atlsoapheader_entries[] =
	{
		{ 0x00000000 }
	};

	static const _soapmap __Cservices__processInitial_atlsoapheader_map = 
	{
		0xD0110578,
		"processInitial",
		L"processInitialResponse",
		sizeof("processInitial")-1,
		sizeof("processInitialResponse")-1,
		SOAPMAP_HEADER,
		__Cservices__processInitial_atlsoapheader_entries,
		0,
		0,
		-1,
		SOAPFLAG_NONE | SOAPFLAG_PID | SOAPFLAG_DOCUMENT | SOAPFLAG_LITERAL,
		0x05276BEB,
		"http://localhost/VCRClientService",
		L"http://localhost/VCRClientService",
		sizeof("http://localhost/VCRClientService")-1
	};

	static const _soapmapentry __Cservices__processPulse_atlsoapheader_entries[] =
	{
		{ 0x00000000 }
	};

	static const _soapmap __Cservices__processPulse_atlsoapheader_map = 
	{
		0x3644EF57,
		"processPulse",
		L"processPulseResponse",
		sizeof("processPulse")-1,
		sizeof("processPulseResponse")-1,
		SOAPMAP_HEADER,
		__Cservices__processPulse_atlsoapheader_entries,
		0,
		0,
		-1,
		SOAPFLAG_NONE | SOAPFLAG_PID | SOAPFLAG_DOCUMENT | SOAPFLAG_LITERAL,
		0x05276BEB,
		"http://localhost/VCRClientService",
		L"http://localhost/VCRClientService",
		sizeof("http://localhost/VCRClientService")-1
	};

	static const _soapmapentry __Cservices__processData_atlsoapheader_entries[] =
	{
		{ 0x00000000 }
	};

	static const _soapmap __Cservices__processData_atlsoapheader_map = 
	{
		0x1C18FAE8,
		"processData",
		L"processDataResponse",
		sizeof("processData")-1,
		sizeof("processDataResponse")-1,
		SOAPMAP_HEADER,
		__Cservices__processData_atlsoapheader_entries,
		0,
		0,
		-1,
		SOAPFLAG_NONE | SOAPFLAG_PID | SOAPFLAG_DOCUMENT | SOAPFLAG_LITERAL,
		0x05276BEB,
		"http://localhost/VCRClientService",
		L"http://localhost/VCRClientService",
		sizeof("http://localhost/VCRClientService")-1
	};


	static const _soapmap * __Cservices_headers[] =
	{
		&__Cservices__processSubsequent_atlsoapheader_map,
		&__Cservices__processInitial_atlsoapheader_map,
		&__Cservices__processPulse_atlsoapheader_map,
		&__Cservices__processData_atlsoapheader_map,
		NULL
	};
	
	return __Cservices_headers;
}

template <typename TClient>
ATL_NOINLINE inline void * CservicesT<TClient>::GetHeaderValue()
{
	return this;
}

template <typename TClient>
ATL_NOINLINE inline const wchar_t * CservicesT<TClient>::GetNamespaceUri()
{
	return L"http://localhost/VCRClientService";
}

template <typename TClient>
ATL_NOINLINE inline const char * CservicesT<TClient>::GetServiceName()
{
	return NULL;
}

template <typename TClient>
ATL_NOINLINE inline const char * CservicesT<TClient>::GetNamespaceUriA()
{
	return "http://localhost/VCRClientService";
}

template <typename TClient>
ATL_NOINLINE inline HRESULT CservicesT<TClient>::CallFunction(
	void *, 
	const wchar_t *, int,
	size_t)
{
	return E_NOTIMPL;
}

template <typename TClient>
ATL_NOINLINE inline HRESULT CservicesT<TClient>::GetClientReader(ISAXXMLReader **ppReader)
{
	if (ppReader == NULL)
	{
		return E_INVALIDARG;
	}
	
	CComPtr<ISAXXMLReader> spReader = GetReader();
	if (spReader.p != NULL)
	{
		*ppReader = spReader.Detach();
		return S_OK;
	}
	return TClient::GetClientReader(ppReader);
}

} // namespace services

template<>
inline HRESULT AtlCleanupValue<services::processDataResponse>(services::processDataResponse *pVal)
{
	pVal;
	AtlCleanupValue(&pVal->___return);
	return S_OK;
}

template<>
inline HRESULT AtlCleanupValueEx<services::processDataResponse>(services::processDataResponse *pVal, IAtlMemMgr *pMemMgr)
{
	pVal;
	pMemMgr;
	
	AtlCleanupValueEx(&pVal->___return, pMemMgr);
	return S_OK;
}

template<>
inline HRESULT AtlCleanupValue<services::processSubsequent>(services::processSubsequent *pVal)
{
	pVal;
	AtlCleanupValue(&pVal->request);
	return S_OK;
}

template<>
inline HRESULT AtlCleanupValueEx<services::processSubsequent>(services::processSubsequent *pVal, IAtlMemMgr *pMemMgr)
{
	pVal;
	pMemMgr;
	
	AtlCleanupValueEx(&pVal->request, pMemMgr);
	return S_OK;
}

template<>
inline HRESULT AtlCleanupValue<services::processInitial>(services::processInitial *pVal)
{
	pVal;
	AtlCleanupValue(&pVal->request);
	return S_OK;
}

template<>
inline HRESULT AtlCleanupValueEx<services::processInitial>(services::processInitial *pVal, IAtlMemMgr *pMemMgr)
{
	pVal;
	pMemMgr;
	
	AtlCleanupValueEx(&pVal->request, pMemMgr);
	return S_OK;
}

template<>
inline HRESULT AtlCleanupValue<services::processData>(services::processData *pVal)
{
	pVal;
	AtlCleanupValue(&pVal->request);
	return S_OK;
}

template<>
inline HRESULT AtlCleanupValueEx<services::processData>(services::processData *pVal, IAtlMemMgr *pMemMgr)
{
	pVal;
	pMemMgr;
	
	AtlCleanupValueEx(&pVal->request, pMemMgr);
	return S_OK;
}

template<>
inline HRESULT AtlCleanupValue<services::processSubsequentResponse>(services::processSubsequentResponse *pVal)
{
	pVal;
	AtlCleanupValue(&pVal->___return);
	return S_OK;
}

template<>
inline HRESULT AtlCleanupValueEx<services::processSubsequentResponse>(services::processSubsequentResponse *pVal, IAtlMemMgr *pMemMgr)
{
	pVal;
	pMemMgr;
	
	AtlCleanupValueEx(&pVal->___return, pMemMgr);
	return S_OK;
}

template<>
inline HRESULT AtlCleanupValue<services::processPulseResponse>(services::processPulseResponse *pVal)
{
	pVal;
	AtlCleanupValue(&pVal->___return);
	return S_OK;
}

template<>
inline HRESULT AtlCleanupValueEx<services::processPulseResponse>(services::processPulseResponse *pVal, IAtlMemMgr *pMemMgr)
{
	pVal;
	pMemMgr;
	
	AtlCleanupValueEx(&pVal->___return, pMemMgr);
	return S_OK;
}

template<>
inline HRESULT AtlCleanupValue<services::processPulse>(services::processPulse *pVal)
{
	pVal;
	AtlCleanupValue(&pVal->request);
	return S_OK;
}

template<>
inline HRESULT AtlCleanupValueEx<services::processPulse>(services::processPulse *pVal, IAtlMemMgr *pMemMgr)
{
	pVal;
	pMemMgr;
	
	AtlCleanupValueEx(&pVal->request, pMemMgr);
	return S_OK;
}

template<>
inline HRESULT AtlCleanupValue<services::processInitialResponse>(services::processInitialResponse *pVal)
{
	pVal;
	AtlCleanupValue(&pVal->___return);
	return S_OK;
}

template<>
inline HRESULT AtlCleanupValueEx<services::processInitialResponse>(services::processInitialResponse *pVal, IAtlMemMgr *pMemMgr)
{
	pVal;
	pMemMgr;
	
	AtlCleanupValueEx(&pVal->___return, pMemMgr);
	return S_OK;
}
