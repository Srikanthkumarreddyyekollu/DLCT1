#include "stdafx.h"
#include "cJSON.h"
#include "Structures.h"
registerResponseObjStucture registerResponseObjStuctureObj;
using namespace std;

	//getCommandsObject()
	commandStructure getCommandsObject(char *pointerToReceivedBuff){
	commandStructure commandStructuresObj;
	char *out;
	cJSON *json;
	json=cJSON_Parse(pointerToReceivedBuff);
	if (!json) {printf("Error before: [%s]\n",cJSON_GetErrorPtr());}
	else
	{

		cJSON * arr = cJSON_GetObjectItem(json, "deviceCommands");
		if(arr != NULL)
		{

			for(int loopCount = 0; loopCount < cJSON_GetArraySize(arr); loopCount++)
			{
				cJSON * item = cJSON_GetArrayItem(arr, loopCount);
				char *deviceCommand= item->valuestring;
				commandStructuresObj.deviceCommand[loopCount]= (char*) malloc((int)(strlen(deviceCommand)+1) * sizeof(char));
				strcpy(commandStructuresObj.deviceCommand[loopCount],deviceCommand);
				commandStructuresObj.deviceCommand[loopCount+1]= (char*) malloc((int)(strlen(deviceCommand)+1) * sizeof(char));
				strcpy(commandStructuresObj.deviceCommand[loopCount+1],"NULL");
			}
		}

		//for object array of firewall command
		arr = cJSON_GetObjectItem(json, "firewallCommands");
		if(arr != NULL)
		{
			// this->data.clear();
			for(int loopCount = false; loopCount < cJSON_GetArraySize(arr); loopCount++)
			{
				cJSON * item = cJSON_GetArrayItem(arr, loopCount);
				char *firewallCommands= item->valuestring;
				commandStructuresObj.firewallCommand[loopCount]= (char*) malloc( (int)(strlen(firewallCommands)+true) * sizeof(char));
				strcpy(commandStructuresObj.firewallCommand[loopCount],firewallCommands);
				commandStructuresObj.firewallCommand[loopCount+true]= (char*) malloc((int)(strlen(firewallCommands)+true)* sizeof(char));
				strcpy(commandStructuresObj.firewallCommand[loopCount+true],"NULL");
			}
		}
		int requestID = cJSON_GetObjectItem(json,"requestID")->valueint;
		commandStructuresObj.requestId=requestID;

	}
	if(pointerToReceivedBuff!=NULL)
	free(pointerToReceivedBuff);
	return commandStructuresObj;
	}//getCommandsObject()
	
	//================================================================================================
	char* getSubsequentRequestJSON(subSequentRequestJsonStucture subSequentRequestJsonStuctureObj){
	cJSON *root;
	char *out;
	root=cJSON_CreateObject();
	cJSON_AddStringToObject(root,"status",		subSequentRequestJsonStuctureObj.status);
	cJSON_AddNumberToObject(root,"subActivityId",		subSequentRequestJsonStuctureObj.subActivityId);
	cJSON_AddStringToObject(root,"checksum",		subSequentRequestJsonStuctureObj.checksum);
	out=cJSON_Print(root);	cJSON_Delete(root);//	printf("%s\n",out);	//free(out);
	return out;
	}//getSubsequentRequestJSON()

	//===============================================================================================
	//getSubsequentRequestObject()
	subSequentRequestObjStucture getSubsequentRequestObject(char *pointerToReceivedBuff){

	char *out;
	cJSON *json;
	json=cJSON_Parse(pointerToReceivedBuff);
	if (!json) {printf("Error before: [%s]\n",cJSON_GetErrorPtr());}
	else
	{
		subSequentRequestObjStucture subSequentRequestObjStuctureObj;
		char *status = cJSON_GetObjectItem(json,"status")->valuestring;
		int SubActivityId = cJSON_GetObjectItem(json, "SubActivityId")->valueint;
		char *checkSum = cJSON_GetObjectItem(json, "checkSum")->valuestring;
		subSequentRequestObjStuctureObj.status=status;
		subSequentRequestObjStuctureObj.subActivityId=SubActivityId;
		subSequentRequestObjStuctureObj.checksum=checkSum;
		
		if(pointerToReceivedBuff!=NULL)
		free(pointerToReceivedBuff);
		return subSequentRequestObjStuctureObj;
	}//else
	}//getSubsequentRequestObject()

	
	registerResponseObjStucture getRegisterResponseObject(char * pointerToReceivedBuff){
	char *out;
	cJSON *json;
	try{
	json=cJSON_Parse(pointerToReceivedBuff);
	if (!json) {printf("Error before: [%s]\n",cJSON_GetErrorPtr());}
	else
	{	
		registerResponseObjStuctureObj.clientID = cJSON_GetObjectItem(json,"clientId")->valueint;
		cJSON * array = cJSON_GetObjectItem(json,"cryptKey");
		if(array != NULL){
		// this->data.clear();
		for(int j = 0; j < cJSON_GetArraySize(array); j++){
			int item = cJSON_GetArrayItem(array, j)->valueint;
			signed char temCharBuffer = char (item);
			const byte tempByteBuffer=  byte(temCharBuffer);
			registerResponseObjStuctureObj.signKey[j] = tempByteBuffer;
			registerResponseObjStuctureObj.signKey[j + true] = '\0';
			}

		}
		
		array = cJSON_GetObjectItem(json,"signKey");
		if(array != NULL){
		// this->data.clear();
		for(int j = 0; j < cJSON_GetArraySize(array); j++){
			int item = cJSON_GetArrayItem(array, j)->valueint;
			signed char temCharBuffer = char (item);
			const byte tempByteBuffer=  byte(temCharBuffer);
			registerResponseObjStuctureObj.cryptKey[j] = tempByteBuffer;
			registerResponseObjStuctureObj.cryptKey[j + true] = '\0';
			}
		}
		//registerResponseObjStuctureObj.signKey = cJSON_GetObjectItem(json, "signKey")->valuestring;
		//registerResponseObjStuctureObj.cryptKey = cJSON_GetObjectItem(json, "cryptKey")->valuestring;
		registerResponseObjStuctureObj.ftpUsername = cJSON_GetObjectItem(json, "ftpUserName")->valuestring;
		registerResponseObjStuctureObj.ftpPassword = cJSON_GetObjectItem(json, "ftpPassword")->valuestring;
		registerResponseObjStuctureObj.ftpUrl = cJSON_GetObjectItem(json, "ftpURL")->valuestring;
		registerResponseObjStuctureObj.ftpPath = cJSON_GetObjectItem(json, "ftpPath")->valuestring;
		registerResponseObjStuctureObj.ftpInterval = cJSON_GetObjectItem(json, "ftpInterval")->valueint;
		registerResponseObjStuctureObj.contentRetrievalInterval = cJSON_GetObjectItem(json, "contentRetrievalInterval")->valueint;

		if(pointerToReceivedBuff!=NULL)
		free(pointerToReceivedBuff);

		return registerResponseObjStuctureObj;
	}//else
	
	}catch(...){throw;}

	}//getRegisterResponseObject()

	//=======================================================================================================
	//getRegisterResponseJSON()
	char* getRegisterResponseJSON(registerResponseJsonStucture registerResponseJsonStuctureObj){

	cJSON *root;
	char *out;
	root=cJSON_CreateObject();
	cJSON_AddNumberToObject(root,"clientId",		registerResponseJsonStuctureObj.clientId);
	cJSON_AddStringToObject(root,"cryptkey",		registerResponseJsonStuctureObj.cryptkey);
	cJSON_AddStringToObject(root,"signkey",		registerResponseJsonStuctureObj.signkey);
	out=cJSON_Print(root);	cJSON_Delete(root);//	printf("%s\n",out);	//free(out);
	return out;
	}//getRegisterResponseJSON()

	//========================================================================================================
	//getRulesObject()
	rulesObjStucture getRulesObject(char * pointerToReceivedBuff){
	char *out;
	cJSON *json;
	json=cJSON_Parse(pointerToReceivedBuff);
	if (!json) {printf("Error before: [%s]\n",cJSON_GetErrorPtr());}
	else
	{
		rulesObjStucture rulesObjStuctureObj;
		char *rule1 = cJSON_GetObjectItem(json, "rule1")->valuestring;
		char *rule2 = cJSON_GetObjectItem(json, "rule2")->valuestring;
		char *rule3 = cJSON_GetObjectItem(json, "rule3")->valuestring;
		rulesObjStuctureObj.rule1=rule1;
		rulesObjStuctureObj.rule2=rule2;
		rulesObjStuctureObj.rule3=rule3;

		if(pointerToReceivedBuff!=NULL)
		free(pointerToReceivedBuff);
		return rulesObjStuctureObj;

	}//else
	}//getRulesObject()
	//============================================================================
	//getRegisterRequestJSON()
	char* getRegisterRequestJSON(registerRequestJsonStructure registerRequestJsonStructureObj){

	cJSON *root;
	char *out;
	root=cJSON_CreateObject();
	cJSON_AddStringToObject(root,"machineName",		registerRequestJsonStructureObj.machineName);
	cJSON_AddStringToObject(root,"ipAddress",		registerRequestJsonStructureObj.ipAddress);
	cJSON_AddStringToObject(root,"cuid",		registerRequestJsonStructureObj.cuid);
	out=cJSON_Print(root);	cJSON_Delete(root);//	printf("%s\n",out);	//free(out);
	return out;
	}//getRegisterRequestJSON()

	//================================================================================
	//getRegisterRequestObject()
	registerRequestObjStructure getRegisterRequestObject(char *pointerToReceivedBuff){

	char *out;
	cJSON *json;
	json=cJSON_Parse(pointerToReceivedBuff);
	if (!json) {printf("Error before: [%s]\n",cJSON_GetErrorPtr());}
	else
	{
		registerRequestObjStructure registerRequestObjStructureObj;
		char *machineName = cJSON_GetObjectItem(json,"machineName")->valuestring;
		char *ipAddress = cJSON_GetObjectItem(json, "ipAddress")->valuestring;
		char *cuid = cJSON_GetObjectItem(json, "cuid")->valuestring;
		registerRequestObjStructureObj.machineName=machineName;
		registerRequestObjStructureObj.ipAddress=ipAddress;
		registerRequestObjStructureObj.cuid=cuid;

		if(pointerToReceivedBuff!=NULL)
		free(pointerToReceivedBuff);
		return registerRequestObjStructureObj;
	}
	}//getRegisterRequestObject()
	
	//======================================================================================================
	//processNetworkDataRequestJSON()
	char* processNetworkDataRequestJSON(processNetworkDataReqObjStrcture processNetworkDataReqObjStrcturePtr){

	cJSON *root;
	char *out;
	root=cJSON_CreateObject();
	cJSON_AddStringToObject(root,"clientId",		processNetworkDataReqObjStrcturePtr.clientID);
	cJSON_AddStringToObject(root,"name",		processNetworkDataReqObjStrcturePtr.fileName);
	cJSON_AddNumberToObject(root,"status",		processNetworkDataReqObjStrcturePtr.status);
	out=cJSON_Print(root);	cJSON_Delete(root);//	printf("%s\n",out);	//free(out);

	return out;
	}//processNetworkDataRequestJSON()
	
	//===========================================================================================================
	//getRetrieveContentJSON()
	char* getRetrieveContentJSON(int clientId){
	cJSON *root;
	char *out;
	root=cJSON_CreateObject();
	cJSON_AddNumberToObject(root,"clientId",		clientId);
	out=cJSON_Print(root);	cJSON_Delete(root);//	printf("%s\n",out);	//free(out);
	return out;
	}//getRetrieveContentJSON()
	//=============================================================================================================
	//getEncryptedContentJSON()
	char* getEncryptedContentJSON(char *string){
	cJSON *root;
	char *out;
	root=cJSON_CreateObject();
	cJSON_AddStringToObject(root,"code",		string);
	out=cJSON_Print(root);	cJSON_Delete(root);//	printf("%s\n",out);	//free(out);
	if(string!=NULL)
	free(string);
	return out;
	}
	
	//=============================================================================================================
	//getRetrieveContentObj()
	retrieveContentResponseStucture getRetrieveContentObj(char *pointerToReceivedBuff){
	//printf("Received string to be printed is:%s\n",pointerToReceivedBuff);
	retrieveContentResponseStucture retrieveContentResponseStuctureObj;
	char *out;
	cJSON *json;
	json=cJSON_Parse(pointerToReceivedBuff);
	if (!json) {printf("Error before: [%s]\n",cJSON_GetErrorPtr());}
	else
	{
	cJSON * arr = cJSON_GetObjectItem(json, "deviceCommands");
	if(arr != NULL){
		// this->data.clear();
		for(int j = 0; j < cJSON_GetArraySize(arr); j++){
			cJSON * item = cJSON_GetArrayItem(arr, j);
			out=cJSON_Print(item);
			retrieveContentResponseStuctureObj.deviceCommands[j]=out;
			free(out);
			// this->data.push_back(item->valueint);
			}
		}
		// // char *a="\"UNBLOCKUSB\"", *b="\"BLOCKUSB\"";
		// // retrieveContentResponseStuctureObj.deviceCommands[0]=b;
		// // retrieveContentResponseStuctureObj.deviceCommands[1]=a;
		
	arr = cJSON_GetObjectItem(json, "firewallCommands");
	if(arr != NULL)
	{
		// this->data.clear();
		for(int j = 0; j < cJSON_GetArraySize(arr); j++)
		{
			cJSON * item = cJSON_GetArrayItem(arr, j);
			out=cJSON_Print(item);
			retrieveContentResponseStuctureObj.firewallCommands[j]=out;
			free(out);
		}
	}
	char *signKey= cJSON_GetObjectItem(json, "signKey")->valuestring;
	retrieveContentResponseStuctureObj.signKey=signKey;
	
	int subActivityId= cJSON_GetObjectItem(json, "subActivityId")->valueint;
	retrieveContentResponseStuctureObj.subActivityId=subActivityId;
	
	// if(pointerToReceivedBuff!=NULL)
	// free(pointerToReceivedBuff);
	return retrieveContentResponseStuctureObj;
	}
	}//getRetrieveContentObj()

	//=============================================================================================
	//getProcessExecutionJSON()
	char* getProcessExecutionJSON(processExecutionResultObjStructure processExecutionResultObjStructureObj){

	cJSON *root;
	char *out;
	root=cJSON_CreateObject();
	cJSON_AddNumberToObject(root,"subActivityId",		processExecutionResultObjStructureObj.subActivityId);
	cJSON_AddNumberToObject(root,"checksum",		processExecutionResultObjStructureObj.checksum);
	cJSON_AddStringToObject(root,"status",	processExecutionResultObjStructureObj.status);
	out=cJSON_Print(root);	cJSON_Delete(root);//	printf("%s\n",out);	//free(out);
	return out;	
	}//getProcessExecutionJSON()

	//=====================================================================================
	//processNetworkDataResponseObject()
	processNetworkDataResObjStrcture processNetworkDataResponseObject(char *responseCharPtr){

	char *out;
	cJSON *json;
	json=cJSON_Parse(responseCharPtr);
	if (!json) {printf("Error before: [%s]\n",cJSON_GetErrorPtr());}
	else
	{
		processNetworkDataResObjStrcture processNetworkDataResObjStrctureObj;
		char *status = cJSON_GetObjectItem(json,"status")->valuestring;
		processNetworkDataResObjStrctureObj.status=status;

		if(responseCharPtr!=NULL)
		free(responseCharPtr);
		return processNetworkDataResObjStrctureObj;
	}
	}//processNetworkDataResponseObject()



